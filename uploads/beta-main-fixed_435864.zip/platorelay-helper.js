(async () => {
  if (window.__platorelayHelperRunning) return window.__platorelayHelperResult || null;
  window.__platorelayHelperRunning = true;
  const origin = 'https://auth.platorelay.com';
  const started = Date.now();
  const deadline = started + 9000;
  const resultId = '__platorelay_result';
  const write = (done, values) => {
    const result = { protocol: 'platorelay-browser-v1', done, elapsed_ms: Date.now() - started, ...(values || {}) };
    window.__platorelayHelperResult = result;
    const body = document.body || document.documentElement;
    if (body) {
      let field = document.getElementById(resultId);
      if (!field) {
        field = document.createElement('textarea');
        field.id = resultId;
        field.setAttribute('aria-label', 'PlatoRelay result');
        field.style.position = 'fixed';
        field.style.left = '0';
        field.style.top = '0';
        field.style.width = '1px';
        field.style.height = '1px';
        field.style.opacity = '0.01';
        body.appendChild(field);
      }
      field.value = JSON.stringify(result);
      field.focus();
      field.select();
      field.setSelectionRange(0, field.value.length);
    }
    return result;
  };
  const fail = (code, message, stage) => write(true, { ok: false, code, stage, message: String(message || 'PlatoRelay ไม่สำเร็จ').slice(0, 300) });
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const remaining = () => Math.max(1, deadline - Date.now());
  const hex = (buffer) => Array.from(new Uint8Array(buffer), (b) => b.toString(16).padStart(2, '0')).join('');
  const encrypt = async (text, keyText, ivText) => {
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(keyText), 'AES-CTR', false, ['encrypt']);
    const result = await crypto.subtle.encrypt({ name: 'AES-CTR', counter: new TextEncoder().encode(ivText), length: 128 }, key, new TextEncoder().encode(text));
    return hex(result);
  };
  const request = async (path, options = {}) => {
    if (Date.now() >= deadline) throw Object.assign(new Error('ครบเวลาที่กำหนด — ยังไม่ได้คีย์'), { code: 'PLATORELAY_TIMEOUT' });
    const response = await fetch(origin + '/api/session/' + path, {
      method: options.method || 'GET',
      headers: { Accept: 'application/json', 'X-Client-Name': 'platoboost webclient', 'X-Client-Version': '8.2.3', ...(options.body ? { 'Content-Type': 'application/json' } : {}) },
      body: options.body || undefined,
      credentials: 'omit',
      cache: 'no-store',
      signal: AbortSignal.timeout(Math.max(250, Math.min(3000, remaining())))
    });
    const text = await response.text();
    let body;
    try { body = JSON.parse(text); } catch { body = text; }
    return { http: response.status, body, retryAfter: response.headers.get('retry-after') };
  };
  const dataOf = (reply) => {
    if (!reply || reply.http < 200 || reply.http >= 300 || !reply.body || reply.body.success !== true || !reply.body.data || typeof reply.body.data !== 'object') {
      const message = reply && reply.body && reply.body.message ? reply.body.message : 'PlatoRelay ตอบกลับไม่สำเร็จ';
      const error = new Error(message);
      error.code = reply && reply.body && reply.body.code ? reply.body.code : 'PLATORELAY_UPSTREAM_ERROR';
      error.payload = reply && reply.body;
      error.retryAfter = reply && reply.retryAfter;
      throw error;
    }
    return reply.body.data;
  };
  const keyOf = (data) => {
    const key = data && typeof data.key === 'string' ? data.key.trim() : '';
    return key && !/^(?:KEY_NOT_FOUND|null|undefined)$/i.test(key) ? key : null;
  };
  const ticketOf = (raw) => {
    try {
      const url = new URL(raw, location.href);
      if (url.origin === origin) {
        const parts = url.pathname.split('/').filter(Boolean);
        const ticket = url.searchParams.get('d') || (parts.length === 1 && parts[0] !== 'a' ? parts[0] : null);
        if (ticket && /^[A-Za-z0-9_-]{32,4096}$/.test(ticket)) return { ticket, hash: url.searchParams.get('hash') || null, url: url.href };
      }
      const encoded = url.searchParams.get('r');
      if (encoded) {
        let value = encoded.replace(/-/g, '+').replace(/_/g, '/');
        while (value.length % 4) value += '=';
        const decoded = atob(value);
        return ticketOf(decoded);
      }
    } catch {}
    return null;
  };
  const currentOf = () => ticketOf(location.href);
  const makeMeta = async (ticket) => {
    const plugins = Array.from(navigator.plugins || []).map((p) => ({ name: p.name, filename: p.filename, description: p.description }));
    const mimeTypes = Array.from(navigator.mimeTypes || []).map((m) => ({ type: m.type, description: m.description, suffixes: m.suffixes }));
    const info = [
      { name: 'screen', data: { width: screen.width, height: screen.height, availWidth: screen.availWidth, availHeight: screen.availHeight, colorDepth: screen.colorDepth, pixelDepth: screen.pixelDepth, orientation: screen.orientation ? { type: screen.orientation.type, angle: screen.orientation.angle } : { type: 'empty', angle: 0 } } },
      { name: 'navigator', data: { userAgent: navigator.userAgent, platform: navigator.platform || 'empty', maxTouchPoints: navigator.maxTouchPoints || 0, plugins: { length: plugins.length, item: plugins }, mimeTypes: { length: mimeTypes.length, item: mimeTypes } } },
      { name: 'performance', data: Date.now() },
      { name: 'history', data: { length: history.length } },
      { name: 'webdriver', webdriver: navigator.webdriver || false },
      { name: 'connection', data: navigator.connection ? { effectiveType: navigator.connection.effectiveType || 'empty', downlink: navigator.connection.downlink || 0, rtt: navigator.connection.rtt || 0, saveData: navigator.connection.saveData || false } : { effectiveType: 'empty', downlink: 0, rtt: 0, saveData: false } }
    ];
    return encrypt(JSON.stringify({ browserInfo: info }), ticket.slice(0, 16), ticket.slice(16, 32));
  };
  const makeStream = async (ticket) => {
    const now = Date.now();
    const click = now - 180;
    const events = [
      { event: 1, data: { x: 450, y: 350, target: 'BUTTON', time: click } },
      { event: 1, data: { x: 450, y: 350, target: 'BUTTON', time: click } },
      { event: 0, data: { x: 452, y: 348, target: 'BUTTON', time: click - 80 } },
      { event: 5, data: { time: now, length: 0 } }
    ];
    return encrypt(JSON.stringify({ events }), ticket.slice(1, 17), ticket.slice(17, 33));
  };
  const step = async (current, metadata) => {
    const service = metadata.activeRevenueProfile && metadata.activeRevenueProfile.service;
    if (!Number.isInteger(service) || service < 0 || service > 100) throw Object.assign(new Error('ต้นทางไม่ระบุบริการ checkpoint ที่รองรับ'), { code: 'PLATORELAY_UNSUPPORTED_PROFILE' });
    if (metadata.enableEventTracker === true || metadata.activeTaskProfile) throw Object.assign(new Error('ต้นทางมีขั้นตอนเพิ่มเติมที่ยังไม่รองรับ แต่ไม่ได้ระบุว่าต้องล็อกอิน'), { code: 'PLATORELAY_ADDITIONAL_STEP_REQUIRED' });
    const query = new URLSearchParams({ ticket: current.ticket, service: String(service) });
    if (current.hash) query.set('hash', current.hash);
    const [meta, stream] = await Promise.all([makeMeta(current.ticket), makeStream(current.ticket)]);
    const body = JSON.stringify({ captcha: null, meta, stream, resolved: true });
    return request('step?' + query.toString(), { method: 'PUT', body });
  };
  const isWaitError = (error) => /wait|too[ ._-]?fast|timer|retry/i.test(String(error && error.message || '') + ' ' + String(error && error.code || ''));
  const waitMsFrom = (error, fallback) => {
    const retryAfter = Number(error && error.retryAfter);
    if (Number.isFinite(retryAfter) && retryAfter > 0) return Math.min(2500, Math.max(100, retryAfter * 1000));
    const text = String(error && error.message || '') + ' ' + String(error && error.payload && error.payload.message || '');
    const match = text.match(/(\d+(?:\.\d+)?)\s*(milliseconds?|ms|seconds?|secs?|s)\b/i);
    if (match) {
      const amount = Number(match[1]);
      const unit = match[2].toLowerCase();
      const ms = unit === 'ms' || unit.startsWith('millisecond') ? amount : amount * 1000;
      if (Number.isFinite(ms) && ms > 0) return Math.min(2500, Math.max(100, ms));
    }
    return Math.min(2500, Math.max(100, fallback));
  };
  const stepData = async (current, metadata) => {
    let reply = await step(current, metadata);
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        return dataOf(reply);
      } catch (error) {
        if (!isWaitError(error) || attempt === 3) throw error;
        const delay = waitMsFrom(error, Math.min(4000, 1000 * Math.pow(2, attempt)));
        await sleep(Math.min(delay, remaining()));
        reply = await step(current, metadata);
      }
    }
    return dataOf(reply);
  };
  try {
    let current = currentOf();
    if (!current) throw Object.assign(new Error('ไม่พบ ticket ในลิงก์ต้นทาง'), { code: 'PLATORELAY_INVALID_URL' });
    write(false, { stage: 'running', ticket: current.ticket });
    const seen = new Set();
    let metadata = null;
    for (let hop = 0; hop < 5; hop++) {
      if (seen.has(current.ticket + ':' + (current.hash || ''))) throw Object.assign(new Error('ต้นทางส่ง checkpoint เดิมซ้ำ'), { code: 'PLATORELAY_LOOP' });
      seen.add(current.ticket + ':' + (current.hash || ''));
      if (hop === 0) {
        const replies = await Promise.all([
          request('status?ticket=' + encodeURIComponent(current.ticket)),
          request('metadata?ticket=' + encodeURIComponent(current.ticket))
        ]);
        const status = dataOf(replies[0]);
        const initialKey = keyOf(status);
        if (initialKey) return write(true, { ok: true, key: initialKey, hop, via: 'platorelay-browser-api' });
        metadata = dataOf(replies[1]);
      }
      const stepResult = await stepData(current, metadata);
      const stepKey = keyOf(stepResult);
      if (stepKey) return write(true, { ok: true, key: stepKey, hop, via: 'platorelay-browser-api' });
      if (stepResult.url && stepResult.url !== 'about:blank') {
        const next = ticketOf(stepResult.url);
        if (!next) throw Object.assign(new Error('ต้นทางส่งด่านโฆษณาที่ไม่มี checkpoint ฝังไว้'), { code: 'PLATORELAY_AD_STEP_REQUIRED' });
        try { history.pushState({}, '', next.url); } catch {}
        current = next;
        continue;
      }
      const after = dataOf(await request('status?ticket=' + encodeURIComponent(current.ticket)));
      const finalKey = keyOf(after);
      if (finalKey) return write(true, { ok: true, key: finalKey, hop, via: 'platorelay-browser-api' });
      throw Object.assign(new Error('ต้นทางยังไม่ออกคีย์'), { code: 'PLATORELAY_KEY_NOT_READY' });
    }
    throw Object.assign(new Error('ครบจำนวน checkpoint ที่ตรวจได้แล้ว'), { code: 'PLATORELAY_CHECKPOINT_LIMIT' });
  } catch (error) {
    return fail(error.code || 'PLATORELAY_BROWSER_ERROR', error.message, 'failed');
  }
})();
