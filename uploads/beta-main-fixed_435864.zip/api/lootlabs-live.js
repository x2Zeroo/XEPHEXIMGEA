'use strict';

const { gateWatcher, snapshotChallenge, findCheckboxes, dataOf, GATE_HOST_RE, WIDGET_ORIGIN } = require('./lootlabs-captcha');

function lootInPage(options) {
  const marker = '__unwrapLootProtocolV3';
  const samePage = (a, b) => {
    try {
      const x = new URL(a);
      const y = new URL(b);
      return x.origin === y.origin && x.pathname.replace(/\/+$/, '') === y.pathname.replace(/\/+$/, '') && x.search === y.search;
    } catch { return false; }
  };
  const sourceUrl = location.href;
  if (!options.sources.some((url) => samePage(sourceUrl, url))) {
    const out = { protocol: 'lootlabs-live-v1', phase: 'wrong_source', source_url: sourceUrl };
    return options.waitMode ? Promise.resolve(JSON.stringify(out)) : out;
  }

  let controller = window[marker];
  if (!controller || !samePage(controller.sourceUrl, sourceUrl)) {
    if (controller && typeof controller.stop === 'function') controller.stop();
    const state = {
      protocol: 'lootlabs-live-v1',
      phase: 'loading',
      source_url: sourceUrl,
      page_session: '',
      human_verified: false,
      has_captcha_frame: false,
      is_txt: false,
      destination: null,
      paste: null,
      title: null,
      evidence: null,
      task_urls: [],
      human_task_ids: [],
      error: null,
      started_at: null
    };
    const tasks = new Map();
    const sockets = new Set();
    const requests = new AbortController();
    const createdAt = Date.now();
    const waiters = new Set();
    let timer = null;
    let stopped = false;
    let config = null;
    let configStarted = false;
    let humanOpenedAt = 0;
    let frameSeenAt = 0;

    const notify = () => {
      for (const fn of waiters) fn();
    };
    const validHost = (host) => typeof host === 'string' &&
      /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i.test(host) &&
      !/(?:^|\.)(?:localhost|local|internal|test|invalid)$/i.test(host);
    const decode = (value) => {
      if (typeof value !== 'string' || value.length > 16384) return null;
      value = value.replace(/^r:/, '').trim();
      if (/^https?:\/\//i.test(value)) return value;
      try {
        const raw = atob(value.replace(/-/g, '+').replace(/_/g, '/'));
        if (raw.length <= 5) return null;
        const bytes = Uint8Array.from(raw.slice(5), (c, i) => c.charCodeAt(0) ^ raw.charCodeAt(i % 5));
        return new TextDecoder('utf-8', { fatal: true }).decode(bytes).trim();
      } catch { return null; }
    };
    const destination = (value, vars) => {
      const decoded = decode(value);
      if (!decoded) return null;
      if (/^https?:\/\/\S+$/i.test(decoded)) {
        try {
          const u = new URL(decoded);
          if (u.username || u.password || options.sources.some((source) => samePage(source, u.href))) return null;
          if (/(?:^|\.)(?:lootlabs\.gg|loot-links?\.com|lootlinks\.co|loot-link\.net|lootdest\.(?:com|org|info)|loot-reward\.com|unlockr\.app|nerventualken\.com|onsultingco\.com|enaightdecipie\.com)$/i.test(u.hostname)) return null;
          if (u.searchParams.has('gsid') && u.searchParams.has('gsc')) return null;
          if (state.task_urls.some((url) => {
            try { const ad = new URL(url); return ad.origin === u.origin && ad.pathname === u.pathname; } catch { return false; }
          })) return null;
          return { url: u.href, paste: null };
        } catch { return null; }
      }
      if (state.is_txt && decoded !== 'Refresh Page') {
        const initialPub = vars && vars.PUBLISHER_LINK ? decode(vars.PUBLISHER_LINK) : null;
        if (decoded !== initialPub && decoded.length > 0) {
          return { url: null, paste: decoded };
        }
      }
      return null;
    };
    function stop() {
      if (stopped) return;
      stopped = true;
      clearInterval(timer);
      requests.abort();
      for (const socket of sockets) {
        try { socket.close(); } catch {}
      }
      sockets.clear();
      window.removeEventListener('pagehide', stop);
      notify();
    }
    function finish(raw, evidence, vars) {
      if (!state.human_verified || stopped) return false;
      const resolved = destination(raw, vars);
      if (!resolved) return false;
      state.destination = resolved.url || resolved.paste;
      state.paste = resolved.paste;
      state.evidence = evidence;
      state.phase = 'done';
      state.error = null;
      stop();
      return true;
    }
    function fail(message) {
      state.phase = 'protocol_error';
      state.error = message;
      stop();
    }
    function getVars() {
      const vars = typeof p === 'object' && p ? p : null;
      const pageSession = typeof document.session === 'string' ? document.session : '';
      if (!vars || !pageSession || !vars.KEY || !vars.TID) return null;
      state.page_session = pageSession;
      state.is_txt = String(vars.IS_TXT) === '1' || vars.IS_TXT === true;
      if (typeof vars.PUBLISHER_TITLE === 'string' && vars.PUBLISHER_TITLE) state.title = vars.PUBLISHER_TITLE;
      return vars;
    }
    function readTasks() {
      for (const element of document.querySelectorAll('.task, [data-task-id]')) {
        const match = String(element.className || '').split(/\s+/).map((name) => /^(\d+)_(\d+)_(\d+)$/.exec(name)).find(Boolean);
        const uid = match ? match[2] : element.getAttribute('data-urid');
        const cat = match ? match[1] : element.getAttribute('data-task-id');
        if (!/^\d{1,30}$/.test(uid || '') || !/^\d{1,4}$/.test(cat || '') || (tasks.size >= 12 && !tasks.has(uid))) continue;
        let task = tasks.get(uid);
        if (!task) {
          task = {
            uid,
            cat,
            connected: false,
            wsOpen: false,
            completedRequest: false,
            lastR: null,
            socketUrl: null,
            socket: null,
            lastFiredAt: 0,
            fallbackReconnected: false,
            session: element.getAttribute('data-session-id') || 'undefined'
          };
          tasks.set(uid, task);
        }
        task.human = cat === '41' || /confirm you are human|verify you are human|human verification/i.test(element.textContent || '');
        task.done = element.classList.contains('done') || element.getAttribute('data-completed') === 'true';
        for (const link of element.querySelectorAll('a[href]')) {
          if (/^https?:\/\//i.test(link.href) && !state.task_urls.includes(link.href) && state.task_urls.length < 40) state.task_urls.push(link.href);
        }
      }
      const human = Array.from(tasks.values()).filter((task) => task.human);
      state.human_task_ids = human.map((task) => task.uid);
      state.human_verified = tasks.size > 0 && (!human.length || human.every((task) => task.done));
      const frame = Array.from(document.querySelectorAll('iframe')).some((element) => {
        try { const url = new URL(element.src); return url.pathname === '/captcha' && state.human_task_ids.includes(url.searchParams.get('urid')); }
        catch { return false; }
      });
      if (frame && !frameSeenAt) frameSeenAt = Date.now();
      state.has_captcha_frame = frame;
      if (!state.human_verified && human.length && Date.now() - humanOpenedAt >= 1500) {
        const task = human.find((item) => !item.done);
        const element = task && document.getElementById(task.uid);
        if (element && !frame) {
          humanOpenedAt = Date.now();
          element.click();
        }
      }
    }
    async function loadConfig(vars) {
      configStarted = true;
      if (!validHost(vars.CDN_DOMAIN)) { fail('cdn_domain_missing'); return; }
      const timeout = setTimeout(() => requests.abort(), 10000);
      try {
        const url = new URL('https://' + vars.CDN_DOMAIN + '/');
        url.search = new URLSearchParams({ tid: String(vars.TID), params_only: '1' });
        const response = await fetch(url.href, { credentials: 'omit', signal: requests.signal });
        if (!response.ok) throw new Error('params_http_' + response.status);
        let text = (await response.text()).trim().replace(/;\s*$/, '');
        if (text.startsWith('(') && text.endsWith(')')) text = '[' + text.slice(1, -1) + ']';
        const values = JSON.parse(text);
        if (!Array.isArray(values)) throw new Error('params_format_changed');
        const domains = [values[9], values[10], values[11]].filter(validHost);
        if (!domains.length || !validHost(values[29])) throw new Error('protocol_domains_missing');
        config = { domains: Array.from(new Set(domains)), sync: values[29] };
      } catch (error) {
        if (!stopped) fail(error.name === 'AbortError' ? 'params_timeout' : error.message);
      } finally { clearTimeout(timeout); }
      if (!stopped) check();
    }
    function completeTask(task, socketUrl, vars, force = false) {
      if (stopped || !state.human_verified) return;
      if (task.completedRequest && !force) return;
      task.completedRequest = true;
      task.lastFiredAt = Date.now();
      const start = new URL(socketUrl);
      start.protocol = 'https:';
      start.pathname = '/st';
      start.search = new URLSearchParams({ uid: task.uid, cat: task.cat });
      const complete = new URL('https://' + config.sync + '/td');
      complete.search = new URLSearchParams({ ac: 'auto_complete', urid: task.uid, cat: task.cat, tid: String(vars.TID) });
      fetch(start.href, { method: 'POST', mode: 'no-cors', credentials: 'omit', body: '', signal: requests.signal }).catch(() => {});
      fetch(complete.href, { mode: 'no-cors', credentials: 'omit', signal: requests.signal }).catch(() => {});
    }
    function connect(task, vars, attempt = 0) {
      if (stopped || !config) return;
      const domIdx = attempt % config.domains.length;
      task.connected = true;
      task.wsOpen = false;
      const shard = Number(task.uid.slice(-5)) % 3;
      const url = new URL('wss://' + shard + '.' + config.domains[domIdx] + '/c');
      url.search = new URLSearchParams({ uid: task.uid, cat: task.cat, key: String(vars.KEY), session_id: task.session, is_loot: '1', tid: String(vars.TID) });
      let socket;
      let heartbeat = null;
      let retried = false;
      const retry = () => {
        if (retried || stopped) return;
        retried = true;
        task.wsOpen = false;
        task.socket = null;
        clearInterval(heartbeat);
        sockets.delete(socket);
        try { socket.close(); } catch {}
        if (attempt < 6) setTimeout(() => connect(task, vars, attempt + 1), 120);
        else task.connected = false;
      };
      try { socket = new WebSocket(url.href); } catch { retry(); return; }
      sockets.add(socket);
      task.socket = socket;
      task.socketUrl = url.href;
      socket.addEventListener('open', () => {
        if (stopped) { socket.close(); return; }
        task.wsOpen = true;
        heartbeat = setInterval(() => { if (socket.readyState === WebSocket.OPEN) socket.send('0'); }, 6000);
        if (state.human_verified) completeTask(task, url.href, vars, true);
      });
      socket.addEventListener('message', (event) => {
        if (typeof event.data !== 'string') return;
        if (event.data === 'Refresh Page') { fail('session_expired'); return; }
        if (event.data.startsWith('r:')) {
          task.lastR = event.data;
          if (!state.human_verified && task.human && destination(event.data, vars)) {
            state.human_verified = true;
          }
          if (state.human_verified) finish(event.data, 'websocket', vars);
        }
      });
      socket.addEventListener('error', retry);
      socket.addEventListener('close', () => { clearInterval(heartbeat); retry(); });
    }
    function check() {
      if (stopped) return;
      if (!samePage(location.href, sourceUrl)) { stop(); return; }
      if (Date.now() - createdAt > 900000) { fail('session_expired'); return; }
      const vars = getVars();
      if (!vars) return;
      if (!configStarted) void loadConfig(vars);
      readTasks();
      // pre-connect WS ตอน 5500ms หลังเปิดหน้า (หรือทันทีที่ผ่าน human) เพื่อไม่ให้ WS หมดอายุก่อน verify เสร็จ
      if (config && (state.human_verified || Date.now() - createdAt >= 5500)) {
        for (const task of tasks.values()) {
          if (!task.connected) connect(task, vars);
        }
      }
      if (tasks.size > 0 && !state.human_verified) state.phase = 'awaiting_human';
      if (!state.human_verified || stopped) { notify(); return; }
      if (!state.started_at) state.started_at = Date.now();
      state.phase = 'resolving';
      const publisher = typeof PUBLISHER_LINK === 'string' ? PUBLISHER_LINK : null;
      if (publisher && publisher !== vars.PUBLISHER_LINK && finish(publisher, 'publisher_state', vars)) return;
      if (Date.now() - state.started_at >= options.timeoutMs) { fail('destination_not_released'); return; }
      for (const task of tasks.values()) {
        if (task.lastR && finish(task.lastR, 'websocket_cached', vars)) return;
        if (task.wsOpen && task.socket && task.socket.readyState === WebSocket.OPEN) {
          if (!task.completedRequest) {
            completeTask(task, task.socketUrl, vars);
          } else if (Date.now() - task.lastFiredAt >= 4000 && !task.fallbackReconnected) {
            task.fallbackReconnected = true;
            try { task.socket.close(); } catch {}
          }
        }
      }
      notify();
    }
    const snapshot = () => ({ ...state, task_urls: state.task_urls.slice(), human_task_ids: state.human_task_ids.slice() });
    const wait = (mode, waitMs) => {
      check();
      const readyNow = () => state.phase === 'done' || state.phase === 'protocol_error' ||
        (mode === 'boot' && (state.human_verified || (state.has_captcha_frame && frameSeenAt && Date.now() - frameSeenAt >= 120)));
      if (!mode || readyNow()) return Promise.resolve(snapshot());
      return new Promise((resolve) => {
        let finished = false;
        const finishWait = () => {
          if (finished) return;
          finished = true;
          clearTimeout(timerId);
          waiters.delete(onTick);
          resolve(snapshot());
        };
        const onTick = () => {
          if (state.phase === 'done' || state.phase === 'protocol_error') return finishWait();
          if (mode === 'boot' && (state.human_verified || (state.has_captcha_frame && frameSeenAt && Date.now() - frameSeenAt >= 120))) return finishWait();
        };
        waiters.add(onTick);
        const timerId = setTimeout(finishWait, Math.max(200, Math.min(12000, waitMs || 3500)));
      });
    };
    window.addEventListener('pagehide', stop, { once: true });
    timer = setInterval(check, 40);
    controller = { sourceUrl, wait, stop };
    window[marker] = controller;
  }
  if (options.waitMode) {
    return controller.wait(options.waitMode, options.waitMs).then((res) => JSON.stringify(res));
  }
  return controller.read();
}

function buildLootExpression(sources, timeoutMs = 45000, waitMode = null, waitMs = 3500) {
  const options = {
    sources: sources.filter(Boolean),
    timeoutMs: Math.max(1000, Math.min(60000, timeoutMs)),
    ...(waitMode ? { waitMode, waitMs } : {})
  };
  const call = '(' + lootInPage.toString() + ')(' + JSON.stringify(options) + ')';
  return waitMode ? call : 'JSON.stringify(' + call + ')';
}

function readEvaluation(result) {
  if (!result || !result.ok) return null;
  const queue = [result.data, result.text];
  for (let i = 0; i < queue.length && i < 24; i++) {
    const value = queue[i];
    if (value && typeof value === 'object') {
      if (value.protocol === 'lootlabs-live-v1') return value;
      for (const key of ['value', 'result', 'evaluation', 'text', 'data', 'json']) if (value[key] != null) queue.push(value[key]);
    } else if (typeof value === 'string') {
      try { queue.push(JSON.parse(value)); } catch {
        const start = value.indexOf('{');
        const end = value.lastIndexOf('}');
        if (start >= 0 && end > start) {
          try { queue.push(JSON.parse(value.slice(start, end + 1))); } catch {}
        }
      }
    }
  }
  return null;
}

function findCheckboxRef(text) {
  const lines = String(text || '').split(/\r?\n/);
  for (const line of lines) {
    if (/- checkbox\b/.test(line) && !/\[(?:checked|disabled|hidden)\]|aria-disabled=true/i.test(line)) {
      const m = /\[ref=([^\]]+)\]/.exec(line);
      if (m) return m[1];
    }
  }
  return null;
}

async function solveInBrowser(browser, inputUrl, opts = {}) {
  const start = Date.now();
  const budgetMs = Math.max(10000, Math.min(26000, opts.budgetMs || 22000));
  const deadline = start + budgetMs;
  const done = (extra) => ({ input_url: inputUrl, elapsed_ms: Date.now() - start, ...extra });

  let sessionId;
  try {
    sessionId = (opts.sessionId || '').trim() || browser.defaultSessionId();
    browser.validateSessionId(sessionId);
  } catch (err) {
    return done({ status: 'error', code: (err && err.code) || 'SESSION_ID_REQUIRED', message: (err && err.message) || 'ต้องระบุ session_id ที่ถูกต้อง' });
  }

  const leftMs = (cap = 12000) => Math.max(500, Math.min(cap, deadline - Date.now()));
  const open = typeof browser.pasteOpenUrl === 'function'
    ? await browser.pasteOpenUrl(sessionId, inputUrl, { timeoutMs: leftMs(6000) })
    : await browser.callTool('browser_tabs', { session_id: sessionId, action: 'new', url: inputUrl }, { timeoutMs: leftMs(6000) });
  const pasteMs = open.pasteMs || (open.data && open.data.paste_ms) || (Date.now() - start);
  if (!open.ok) {
    if (open.code === 'user_in_control') {
      return done({ status: 'error', code: 'user_in_control', paste_ms: pasteMs, via: 'lootlabs-browser', message: 'เบราว์เซอร์กำลังถูกควบคุมโดยผู้ใช้ — กด Done, hand back ใน Live View แล้วลองใหม่' });
    }
    try {
      await browser.existingSession(sessionId, { timeoutMs: 4000 });
    } catch (e) {
      return done({ status: 'error', code: (e && e.code) || open.code || 'SESSION_ERROR', paste_ms: pasteMs, via: 'lootlabs-browser', message: (e && e.message) || open.message });
    }
    return done({ status: 'error', code: open.code || 'OPEN_TAB_FAILED', paste_ms: pasteMs, via: 'lootlabs-browser', message: open.message || 'วางลิงก์เข้าเซสชันเบราว์เซอร์ไม่สำเร็จ' });
  }

  let releaseSlot = typeof browser.acquireSessionSlot === 'function'
    ? browser.acquireSessionSlot(sessionId)
    : () => {};
  let tabId = (open.data && open.data.tab_id) || null;
  let shouldCloseTab = !open.singleTab && Boolean(tabId);
  const closeTab = async () => {
    releaseSlot();
    if (!shouldCloseTab || !tabId) return;
    shouldCloseTab = false;
    await browser.callTool('browser_tabs', { session_id: sessionId, action: 'close', tab_id: tabId }, { timeoutMs: 2500 }).catch(() => {});
  };

  try {
    const sources = [inputUrl];
    const evalPhase = async (waitMode, waitMs) => {
      const evalOpts = {
        world: 'main',
        await_promise: true,
        max_chars: 12000,
        timeoutMs: Math.max(1500, Math.min(waitMs + 3000, deadline - Date.now()))
      };
      if (tabId) evalOpts.tab_id = tabId;
      const reply = await browser.evaluate(sessionId, buildLootExpression(sources, budgetMs, waitMode, waitMs), evalOpts);
      if (!reply.ok) {
        if (reply.code === 'user_in_control') throw Object.assign(new Error('เบราว์เซอร์กำลังถูกควบคุมโดยผู้ใช้ — กด Done, hand back ใน Live View แล้วลองใหม่'), { code: 'user_in_control' });
        return null;
      }
      if (!tabId && reply.data && reply.data.tab_id) {
        tabId = reply.data.tab_id;
      }
      return readEvaluation(reply);
    };

    const attachWatcher = async (state) => {
      for (let attempt = 0; attempt < 4; attempt++) {
        const ins = await browser.callTool('browser_inspect', { session_id: sessionId, tab_id: tabId, kind: 'frames', max_chars: 16000 }, { timeoutMs: leftMs(5000) });
        const frames = dataOf(ins);
        if (Array.isArray(frames)) {
          const src = frames.find((f) => f.depth === 0) || frames[0];
          const gate = frames.find((f) => {
            if (!src || f.parent_id !== src.frame_id) return false;
            try {
              const u = new URL(f.url);
              return u.protocol === 'https:' && GATE_HOST_RE.test(u.hostname) && u.pathname === '/captcha' &&
                (!state.human_task_ids.length || state.human_task_ids.includes(u.searchParams.get('urid')));
            } catch { return false; }
          });
          if (gate) {
            const watch = await browser.evaluate(sessionId, 'JSON.stringify((' + gateWatcher.toString() + ')())', {
              tab_id: tabId,
              frame_id: gate.frame_id,
              world: 'main',
              await_promise: true,
              max_chars: 2000,
              timeoutMs: leftMs(4000)
            });
            const val = browser.evaluationValue(watch, 'verified-continue-v1');
            if (val && (val.phase === 'waiting' || val.phase === 'continued')) return true;
          }
        }
        if (attempt < 3 && Date.now() < deadline - 3000) {
          await new Promise((r) => setTimeout(r, 180));
        }
      }
      return false;
    };

    const tryClickCheckbox = async () => {
      const snap = await browser.callTool('browser_snapshot', { session_id: sessionId, tab_id: tabId, full: true }, { timeoutMs: leftMs(4000) });
      const snapText = (snap.data && snap.data.snapshot && snap.data.snapshot.text) || snap.text || '';
      const challenge = snapshotChallenge(snapText);
      if (!challenge || !challenge.checkbox) return false;
      const cbRef = findCheckboxRef(snapText);
      if (cbRef) {
        const clk = await browser.callTool('browser_click', { session_id: sessionId, tab_id: tabId, ref: cbRef }, { timeoutMs: leftMs(3000) });
        if (clk.ok) return true;
      }
      const ins = await browser.callTool('browser_inspect', { session_id: sessionId, tab_id: tabId, kind: 'frames', max_chars: 16000 }, { timeoutMs: leftMs(4000) });
      const frames = dataOf(ins);
      if (!Array.isArray(frames)) return false;
      const gate = frames.find((f) => /\/captcha\b/.test(f.url));
      const widget = gate && frames.find((f) => f.parent_id === gate.frame_id && f.security_origin === WIDGET_ORIGIN);
      if (!widget) return false;
      const doc = await browser.callTool('browser_cdp', {
        session_id: sessionId, tab_id: tabId, frame_id: widget.frame_id,
        method: 'DOM.getDocument', params: { depth: -1, pierce: true }, max_chars: 100000
      }, { timeoutMs: leftMs(5000) });
      const nodes = findCheckboxes(dataOf(doc));
      if (nodes.length !== 1) return false;
      const focused = await browser.callTool('browser_cdp', {
        session_id: sessionId, tab_id: tabId, frame_id: widget.frame_id,
        method: 'DOM.focus', params: { backendNodeId: nodes[0].backendNodeId }, max_chars: 1000
      }, { timeoutMs: leftMs(3000) });
      if (!focused.ok) return false;
      const pressed = await browser.callTool('browser_press_key', { session_id: sessionId, tab_id: tabId, key: 'Space' }, { timeoutMs: leftMs(3000) });
      return !!pressed.ok;
    };

    let retriedCanonical = false;
    const tryFallbackCanonical = async () => {
      if (retriedCanonical) return false;
      let fallbackUrl = null;
      try {
        const parsed = new URL(inputUrl);
        if (parsed.hostname.toLowerCase() !== 'links.lootlabs.gg' && /^\/s\/?$/.test(parsed.pathname) && parsed.searchParams.get('data')) {
          fallbackUrl = 'https://links.lootlabs.gg' + parsed.pathname + parsed.search;
        }
      } catch {}
      if (!fallbackUrl) return false;
      retriedCanonical = true;
      sources.push(fallbackUrl);
      releaseSlot();
      const reOpen = typeof browser.pasteOpenUrl === 'function'
        ? await browser.pasteOpenUrl(sessionId, fallbackUrl, { timeoutMs: leftMs(5000) })
        : await browser.callTool('browser_tabs', { session_id: sessionId, action: 'new', url: fallbackUrl }, { timeoutMs: leftMs(5000) });
      releaseSlot = typeof browser.acquireSessionSlot === 'function'
        ? browser.acquireSessionSlot(sessionId)
        : () => {};
      if (!reOpen.ok) return false;
      tabId = (reOpen.data && reOpen.data.tab_id) || null;
      shouldCloseTab = !reOpen.singleTab && Boolean(tabId);
      await new Promise((r) => setTimeout(r, 220));
      return true;
    };

    const waitBootCommit = async () => {
      const bootWaitUntil = Math.min(deadline - 2000, Date.now() + 6500);
      while (st && st.phase === 'wrong_source' && Date.now() < bootWaitUntil) {
        const srcHref = String(st.source_url || '');
        if (/^(?:about:blank|chrome:\/\/newtab)/i.test(srcHref)) {
          if (open.singleTab && !shouldCloseTab) tabId = null;
          await new Promise((r) => setTimeout(r, 160));
          st = await evalPhase('boot', 3200);
          continue;
        }
        if (/^chrome-error:\/\//i.test(srcHref) && await tryFallbackCanonical()) {
          st = await evalPhase('boot', 3600);
          continue;
        }
        break;
      }
    };

    // ขั้นที่ 1: รอหน้า commit หลังวางลิงก์ + รอ tasks โผล่ + คลิก task 41 + เปิด iframe /captcha
    let st = await evalPhase('boot', 3600);
    await waitBootCommit();
    let gateAttached = false;
    let checkboxPressed = false;
    let waitAccum = 0;

    if (st && st.phase !== 'done' && !st.human_verified && st.has_captcha_frame) {
      gateAttached = await attachWatcher(st);
    }

    // ขั้นที่ 2: รอผลแบบ event-driven (รอบแรก 4.2 วิเพื่อจับ checkbox เร็วถ้ามี จากนั้นรอยาวสูงสุด 10.5 วิ)
    while (Date.now() < deadline - 1000) {
      if (st && st.phase === 'wrong_source' && /^chrome-error:\/\//i.test(String(st.source_url || '')) && await tryFallbackCanonical()) {
        st = await evalPhase('boot', 3600);
        await waitBootCommit();
        gateAttached = false;
        checkboxPressed = false;
        waitAccum = 0;
        if (st && st.phase !== 'done' && !st.human_verified && st.has_captcha_frame) {
          gateAttached = await attachWatcher(st);
        }
        continue;
      }
      if (st && st.phase === 'done' && st.destination) {
        await closeTab();
        if (st.paste && !/^https?:\/\//i.test(st.destination)) {
          return done({
            status: 'success',
            type: 'paste',
            destination: st.paste,
            paste: st.paste,
            title: st.title || null,
            is_premium_only: false,
            paste_ms: pasteMs,
            via: 'lootlabs-browser'
          });
        }
        return done({
          status: 'success',
          type: 'link',
          destination: st.destination,
          title: st.title || null,
          is_premium_only: false,
          paste_ms: pasteMs,
          via: 'lootlabs-browser'
        });
      }
      if (st && st.phase === 'protocol_error') {
        await closeTab();
        return done({ status: 'error', code: st.error || 'protocol_error', paste_ms: pasteMs, via: 'lootlabs-browser', message: 'LootLabs คืนข้อผิดพลาด: ' + (st.error || 'unknown') });
      }
      if (st && !st.human_verified && st.has_captcha_frame && !gateAttached) {
        gateAttached = await attachWatcher(st);
      }
      const targetChunk = waitAccum === 0 ? 4200 : (waitAccum < 7000 ? 3200 : 10000);
      const chunkMs = Math.min(targetChunk, Math.max(400, deadline - 1000 - Date.now()));
      if (chunkMs <= 400) break;
      st = await evalPhase('done', chunkMs);
      waitAccum += chunkMs;
      if (st && st.phase === 'done') continue;
      if (st && !st.human_verified && gateAttached && !checkboxPressed && waitAccum >= 4000 && Date.now() < deadline - 2500) {
        checkboxPressed = await tryClickCheckbox();
      }
    }

    await closeTab();
    if (st && st.phase === 'done' && st.destination) {
      return done({
        status: 'success',
        type: st.paste && !/^https?:\/\//i.test(st.destination) ? 'paste' : 'link',
        destination: st.destination,
        ...(st.paste ? { paste: st.paste } : {}),
        title: st.title || null,
        is_premium_only: false,
        paste_ms: pasteMs,
        via: 'lootlabs-browser'
      });
    }
    return done({
      status: 'error',
      code: (st && !st.human_verified) ? 'captcha_timeout' : 'destination_timeout',
      paste_ms: pasteMs,
      via: 'lootlabs-browser',
      message: (st && !st.human_verified)
        ? 'แก้ด่านยืนยันตัวตน (Turnstile) ในเบราว์เซอร์ไม่ทันเวลา'
        : 'ยังไม่ได้รับปลายทางจาก LootLabs ในเบราว์เซอร์ภายในเวลาที่กำหนด'
    });
  } catch (err) {
    await closeTab();
    return done({
      status: 'error',
      code: (err && err.code) || 'BROWSER_ERROR',
      paste_ms: pasteMs,
      via: 'lootlabs-browser',
      message: (err && err.message) || String(err)
    });
  }
}

module.exports = { buildLootExpression, readEvaluation, solveInBrowser };
