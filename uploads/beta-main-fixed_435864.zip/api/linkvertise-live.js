'use strict';

const PROTOCOL = 'linkvertise-live-v1';
const LINK_HOSTS = [
  'linkvertise.com', 'link-to.net', 'link-hub.net', 'link-target.net', 'link-center.net',
  'link-place.net', 'link-spot.net', 'direct-link.net', 'up-to-down.net', 'file-link.net', 'filemedia.net'
];

const hostIn = (host, domain) => host === domain || host.endsWith('.' + domain);
function hostOf(raw) {
  try { return new URL(raw).hostname.toLowerCase(); } catch { return ''; }
}
function isLinkvertise(raw) {
  const host = hostOf(raw);
  return !!host && LINK_HOSTS.some((domain) => hostIn(host, domain));
}
function identity(raw) {
  try {
    const parts = new URL(raw).pathname.split('/').filter(Boolean);
    const offset = parts[0] === 'access' ? 1 : 0;
    if (!parts[offset] || !parts[offset + 1]) return null;
    return parts[offset] + '/' + parts[offset + 1];
  } catch { return null; }
}
function isReady(raw) {
  try { return isLinkvertise(raw) && new URL(raw).pathname.replace(/\/+$/, '') === '/your-target'; }
  catch { return false; }
}
function sameFlow(a, b) {
  if (!a || !b || !isLinkvertise(a) || !isLinkvertise(b)) return false;
  if (isReady(a) || isReady(b)) return true;
  const left = identity(a), right = identity(b);
  return !!left && !!right && left === right;
}

// Linkvertise uses Angular handlers which do not consistently respond to a
// single accessibility click. First try fast in-page batched GraphQL (1-2s,
// zero ad clicking), then fall back to real pointer events only if needed.
async function drive(BL, sess) {
  const expected = identity(sess.input_url);
  const parts = expected ? expected.split('/') : null;
  const expression = `(async () => {
    const protocol = ${JSON.stringify(PROTOCOL)};
    const expected = ${JSON.stringify(expected)};
    const parts = ${JSON.stringify(parts)};
    const norm = (value) => String(value || '').replace(/\\s+/g, ' ').trim();

    if (parts && parts.length === 2 && location.origin === 'https://linkvertise.com' && window.__lvGqlTried !== expected) {
      try {
        const ident = { userIdAndUrl: { user_id: parts[0], url: parts[1] } };
        const Q_GET = 'query($input: PublicLinkIdentificationInput!, $origin: String){ getContent(input: $input, origin: $origin){ __typename ... on DetailPageTargetData { type url paste } ... on ContentAccessTaskSet { tasks { __typename id status ... on WaitTask { remainingWaitingTime adsTotal } ... on AdTask { adIndex adsTotal } } } } }';
        const M_DONE = 'mutation($input: PublicLinkIdentificationInput!, $task_id: String!, $task_args: TaskArgument!){ completeTask(input: $input, task_id: $task_id, task_args: $task_args){ __typename id status } }';
        const post = async (body) => {
          const r = await fetch('https://publisher.linkvertise.com/graphql', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            credentials: 'include', body: JSON.stringify(body)
          });
          return r.json();
        };
        const init = await post({ query: Q_GET, variables: { input: ident, origin: 'DETAIL_PAGE' } });
        let node = init && init.data && init.data.getContent;
        let prevTaskId = null;
        for (let i = 0; i < 8 && node && node.__typename !== 'DetailPageTargetData'; i++) {
          const task = (node.tasks || []).find((t) => t && t.__typename !== 'PremiumTask' && t.status !== 'DONE');
          if (!task || !task.id || task.id === prevTaskId) break;
          if (task.__typename === 'WaitTask' && task.remainingWaitingTime > 0) {
            if (task.remainingWaitingTime > 3) break;
            await new Promise((r) => setTimeout(r, task.remainingWaitingTime * 1000 + 120));
          }
          prevTaskId = task.id;
          const batch = await post([
            { query: M_DONE, variables: { input: ident, task_id: task.id, task_args: {} } },
            { query: Q_GET, variables: { input: ident, origin: 'DETAIL_PAGE' } }
          ]);
          node = batch && batch[1] && batch[1].data && batch[1].data.getContent;
        }
        if (node && node.__typename === 'DetailPageTargetData' && (node.url || node.paste)) {
          return JSON.stringify({
            protocol, action: 'graphql_resolved', clicked: null,
            href: location.href, ready: true,
            destination: node.url || null, paste: node.paste || null,
            adProgress: null, text: ''
          });
        }
      } catch {}
      window.__lvGqlTried = expected;
    }

    const visible = (element) => {
      if (!element) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
    };
    const fire = (element) => {
      if (!element) return false;
      const target = element.closest('button,a,[role="button"]') || element;
      try { target.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
      for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
        const EventType = type.indexOf('pointer') === 0 ? PointerEvent : MouseEvent;
        target.dispatchEvent(new EventType(type, { bubbles: true, cancelable: true, view: window }));
      }
      target.click();
      return true;
    };
    const elements = [...document.querySelectorAll('button,a,[role="button"],div,span')];
    const findText = (pattern) => elements
      .filter((element) => {
        const text = norm(element.innerText || element.textContent);
        return text.length > 0 && text.length < 180 && visible(element) && pattern.test(text);
      })
      .sort((a, b) => a.children.length - b.children.length || norm(a.innerText || a.textContent).length - norm(b.innerText || b.textContent).length)[0] || null;
    const findButton = (pattern) => elements
      .filter((element) => /^(BUTTON|A)$/.test(element.tagName) || element.getAttribute('role') === 'button')
      .filter((element) => visible(element) && pattern.test(norm(element.innerText || element.textContent)))[0] || null;
    const bodyText = norm(document.body && document.body.innerText);
    const path = location.pathname.replace(/\\/+$/, '');
    let action = null;
    let clicked = null;

    if (path === '/your-target') {
      const open = findButton(/^Open here$/i);
      if (open && fire(open)) { action = 'open_target'; clicked = norm(open.innerText); }
    } else if (path.indexOf('/access/') === 0) {
      const dialogClose = findButton(/^(Close|×|X)$/i) || findText(/^×$/);
      const adCard = findButton(/^Learn more$/i);
      const adInProgress = /\\b\\d+\\s*\\/\\s*\\d+\\b/.test(bodyText) || /google_vignette|goog_fullscreen_ad/i.test(location.hash) || !!adCard;
      const skip = findText(/^(Skip Ad|Close)$/i);
      if (dialogClose && fire(dialogClose)) {
        action = 'close_dialog'; clicked = norm(dialogClose.innerText || dialogClose.textContent);
      } else if (adInProgress && skip && fire(skip)) {
        action = 'skip_ad'; clicked = norm(skip.innerText || skip.textContent);
      } else if (adCard && Date.now() - (window.__lvAdClickAt || 0) >= 2500 && fire(adCard)) {
        window.__lvAdClickAt = Date.now();
        action = 'view_ad'; clicked = norm(adCard.innerText || adCard.textContent);
      } else {
        const continueButton = findButton(/^Continue$/i);
        const trialButton = findButton(/^Try for free\\s*·?\\s*No charge today$/i);
        const watchCard = findText(/^Watch Ads\\s+\\d+\\s+Ads?$/i) || findText(/^Watch Ads$/i);
        if (trialButton && watchCard && fire(watchCard)) {
          action = 'select_watch_ads'; clicked = norm(watchCard.innerText || watchCard.textContent);
        } else if (continueButton && fire(continueButton)) {
          action = 'continue_watch_ads'; clicked = norm(continueButton.innerText);
        } else if (watchCard && fire(watchCard)) {
          action = 'select_watch_ads'; clicked = norm(watchCard.innerText || watchCard.textContent);
        }
        // Without Watch Ads, Try for free opens a premium/login flow. Leave it
        // untouched instead of moving away from the free Linkvertise task.
      }
    } else {
      const fullscreenAd = /google_vignette|goog_fullscreen_ad/i.test(location.hash);
      const closeAd = findText(/^(Skip Ad|Close)$/i);
      if (fullscreenAd && closeAd && fire(closeAd)) {
        action = 'skip_ad'; clicked = norm(closeAd.innerText || closeAd.textContent);
      } else {
        const shortAd = findButton(/^View a short ad\\b/i);
        if (shortAd && fire(shortAd)) {
          action = 'view_short_ad'; clicked = norm(shortAd.innerText);
        } else {
          const links = [...document.querySelectorAll('a[href*="/access/"]')];
          const getAccess = links.find((link) => {
            const text = norm(link.innerText);
            return /^Get access$/i.test(text) && visible(link) && (!expected || link.href.indexOf('/access/' + expected) >= 0);
          });
          if (getAccess && fire(getAccess)) { action = 'get_access'; clicked = norm(getAccess.innerText); }
        }
      }
    }

    return JSON.stringify({
      protocol,
      action,
      clicked,
      href: location.href,
      ready: path === '/your-target',
      adProgress: (bodyText.match(/\\b\\d+\\s*\\/\\s*\\d+\\b/) || [null])[0],
      text: bodyText.slice(-1800)
    });
  })()`;
  const reply = await BL.evaluate(sess.id, expression, {
    world: 'main', tab_id: sess.mainTabId || undefined, max_chars: 5000, timeoutMs: 15000
  });
  return { reply, value: BL.evaluationValue(reply, PROTOCOL) };
}

module.exports = { LINK_HOSTS, isLinkvertise, identity, isReady, sameFlow, drive };
