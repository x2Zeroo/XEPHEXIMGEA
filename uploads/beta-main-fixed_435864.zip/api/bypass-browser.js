// ===========================================================================
// api/bypass-browser.js — ตัวเชื่อมต่อ REST API v7 ของ browser.lol
// ใช้เฉพาะ REST API v7 (https://browser.lol/en/docs/api/v7) ไม่ใช้ MCP tools
// และในโหมดแก้ลิงก์จะเรียก API ตรงของ core (bypass.js) ให้จบเร็วโดยไม่เปิดเบราว์เซอร์
// ===========================================================================

'use strict';

let BL, CORE, LOAD_ERR = null;
try {
  BL = require('./browserlol');
  CORE = require('./bypass');
} catch (e) {
  LOAD_ERR = e;
  console.error('[bypass-browser] load failed', e && e.stack || e);
}

function getQuery(req) {
  try { if (req.query && typeof req.query === 'object') return req.query; } catch {}
  try { const u = new URL(req.url, 'http://localhost'); return Object.fromEntries(u.searchParams.entries()); } catch { return {}; }
}

function readBody(req) {
  return new Promise((done) => {
    if (req.body !== undefined && req.body !== null) {
      if (typeof req.body === 'object') return done(req.body);
      try { return done(JSON.parse(req.body)); } catch { return done({}); }
    }
    let data = '';
    req.on('data', (c) => { data += c; if (data.length > 2e6) { try { req.destroy(); } catch {} } });
    req.on('end', () => { try { done(JSON.parse(data || '{}')); } catch { done({}); } });
    req.on('error', () => done({}));
  });
}

async function paramUrl(req) {
  const q = getQuery(req);
  if (q && typeof q.url === 'string' && q.url) return q.url;
  if ((req.method || 'GET').toUpperCase() === 'POST') {
    const body = await readBody(req);
    if (body && typeof body.url === 'string' && body.url) return body.url;
  }
  return null;
}

function send(res, code, obj) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(obj));
}

function hostOf(u) { try { return new URL(u).hostname; } catch { return ''; } }

function helperUrl(req) {
  if (process.env.PLATORELAY_HELPER_URL) return process.env.PLATORELAY_HELPER_URL;
  const headers = (req && req.headers) || {};
  const host = String(headers['x-forwarded-host'] || headers.host || '').split(',')[0].trim();
  if (!host || !/^[A-Za-z0-9.:[\]-]+$/.test(host)) return '';
  const forwarded = String(headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  const protocol = forwarded === 'http' || forwarded === 'https' ? forwarded : 'https';
  return protocol + '://' + host + '/platorelay-helper.js';
}

async function resolveFastDirect(inputUrl, requestedId, options = {}) {
  const start = Date.now();
  const hostname = hostOf(inputUrl);
  if (hostname === 'auth.platorelay.com') {
    return CORE.bypassPlatorelay(inputUrl, { sessionId: requestedId, reuseSession: true, budgetMs: 4000, helperUrl: options.helperUrl });
  }
  if (hostname === 'platoboost.com' || hostname.endsWith('.platoboost.com')) {
    const id = new URL(inputUrl).searchParams.get('id');
    if (!id) return { status: 'error', input_url: inputUrl, message: "ไม่พบพารามิเตอร์ 'id' ใน URL", elapsed_ms: Date.now() - start };
    const { key, elapsed_ms } = await CORE.bypassPlatoboost(id);
    return key
      ? { status: 'success', type: 'key', input_url: inputUrl, key, elapsed_ms }
      : { status: 'error', input_url: inputUrl, message: 'Bypass failed!', elapsed_ms };
  }
  if (CORE.hostIsLoot(hostname) || (typeof CORE.isLootStyleUrl === 'function' && CORE.isLootStyleUrl(inputUrl))) {
    return CORE.bypassLootlabs(inputUrl, { sessionId: requestedId, helperUrl: options.helperUrl });
  }
  if (CORE.hostIsSocial(hostname)) {
    return CORE.bypassSocial(inputUrl, 0, { sessionId: requestedId });
  }
  if (CORE.hostIsScriptPage(hostname)) {
    return CORE.bypassScriptPage(inputUrl);
  }
  return CORE.bypass(inputUrl, { sessionId: requestedId });
}

async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  const origin = req.headers && req.headers.origin;
  const host = req.headers && req.headers.host;
  let crossOrigin = req.headers && req.headers['sec-fetch-site'] === 'cross-site';
  if (origin && host) {
    try { crossOrigin = crossOrigin || new URL(origin).host !== host; } catch { crossOrigin = true; }
  }
  if (crossOrigin) return send(res, 403, { status: 'error', code: 'ORIGIN_DENIED', message: 'เรียก API จากเว็บไซต์เดียวกันเท่านั้น' });
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if ((req.method || 'GET').toUpperCase() === 'OPTIONS') { res.statusCode = 204; return res.end(); }

  try {
    const path = new URL(req.url, 'http://localhost').pathname;
    if (path === '/health' || path === '/healthz') {
      return send(res, 200, { ok: true, engine: 'api-v7' });
    }
  } catch {}

  const q = getQuery(req);
  const action = String(q.action || '').toLowerCase();

  if (action === 'warm') {
    await Promise.race([BL.preconnect(1), new Promise((r) => setTimeout(r, 350))]).catch(() => false);
    if (CORE && typeof CORE.warmConnections === 'function') CORE.warmConnections();
    return send(res, 200, { status: 'ok', engine: 'api-v7' });
  }

  if (action === 'paste' || action === 'open' || action === 'launch') {
    const body = (req.method || 'GET').toUpperCase() === 'POST' ? await readBody(req) : {};
    const targetUrl = (q && q.url) || (body && body.url) || '';
    const sid = q.session_id || q.session || q.id || (body && (body.session_id || body.session || body.id));
    if (!targetUrl) return send(res, 400, { status: 'error', message: 'ไม่พบพารามิเตอร์ url' });
    const r = await BL.pasteOpenUrl(sid, targetUrl);
    return send(res, r.ok ? 200 : 422, r.ok
      ? {
          status: 'ok',
          session_id: (sid && String(sid).trim()) || BL.defaultSessionId(),
          url: targetUrl,
          paste_ms: r.pasteMs,
          method: r.method,
          tab_id: (r.data && r.data.tab_id) || null
        }
      : { status: 'error', code: r.code, message: r.message, paste_ms: r.pasteMs });
  }

  if (action === 'images') {
    const r = await BL.v7Images();
    return send(res, r.ok ? 200 : 422, r.ok ? r.data : { status: 'error', code: r.code, message: r.message });
  }

  if (action === 'quota') {
    const r = await BL.v7Quota();
    return send(res, r.ok ? 200 : 422, r.ok ? r.data : { status: 'error', code: r.code, message: r.message });
  }

  if (action === 'status' || action === 'start') {
    const sid = q.session_id || q.session || q.id;
    try {
      const info = await BL.existingSession(sid);
      return send(res, 200, {
        status: 'ok',
        session: info.session_id,
        session_id: info.session_id,
        session_status: info.session_status,
        reused: true,
        created: false,
        browser_preserved: true,
        live_view_url: info.live_view_url,
        v7: info.v7
      });
    } catch (e) {
      const code = (e && e.code) || 'SESSION_LOOKUP_FAILED';
      const retryable = !!(e && (e.retryable || code === 'session_not_ready'));
      return send(res, retryable ? 200 : 409, retryable
        ? { status: 'pending', code, retryable: true, reused: true, created: false, message: e.message }
        : { status: 'error', code, reused: false, created: false, message: (e && e.message) || String(e) });
    }
  }

  if (action === 'create') {
    if ((req.method || 'GET').toUpperCase() !== 'POST') {
      res.setHeader('Allow', 'POST');
      return send(res, 405, { status: 'error', code: 'METHOD_NOT_ALLOWED', message: 'ใช้ POST สำหรับ create' });
    }
    const body = await readBody(req);
    const r = await BL.v7SessionCreate(body || {});
    return send(res, r.ok ? 200 : 422, r.ok ? r.data : { status: 'error', code: r.code, message: r.message });
  }

  if (action === 'remove') {
    if ((req.method || 'GET').toUpperCase() !== 'POST') {
      res.setHeader('Allow', 'POST');
      return send(res, 405, { status: 'error', code: 'METHOD_NOT_ALLOWED', message: 'ใช้ POST สำหรับ remove' });
    }
    const body = await readBody(req);
    const sid = q.session_id || q.session || q.id || (body && body.id);
    if (!sid) return send(res, 400, { status: 'error', message: 'ไม่พบ session_id' });
    const r = await BL.v7SessionRemove(sid);
    return send(res, r.ok ? 200 : 422, r.ok ? r.data : { status: 'error', code: r.code, message: r.message });
  }

  if (action === 'stop') {
    return send(res, 200, { status: 'ok', detached: true, browser_preserved: true });
  }

  // one-shot resolve: ทำงานผ่าน API โดยตรงใน ~1 วิ (ไม่ใช่เบราว์เซอร์)
  const url = await paramUrl(req);
  if (!url) return send(res, 400, { status: 'error', message: 'ไม่พบพารามิเตอร์ url' });

  const out = await resolveFastDirect(url, q.session_id || q.session || q.id, { helperUrl: helperUrl(req) });
  return send(res, out.status === 'success' ? 200 : 422, out);
}

module.exports = async (req, res) => {
  if (LOAD_ERR) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.statusCode = 500;
    return res.end(JSON.stringify({ status: 'error', message: 'โหลดโมดูลไม่ได้: ' + String(LOAD_ERR.message || LOAD_ERR).split('\n')[0].slice(0, 300) }));
  }
  try { return await handler(req, res); }
  catch (e) {
    console.error('[bypass-browser]', e && e.stack || e);
    if (!res.headersSent && !res.writableEnded) {
      return send(res, 500, { status: 'error', message: 'server: ' + ((e && e.message) || String(e)) });
    }
  }
};

module.exports.resolve = resolveFastDirect;
