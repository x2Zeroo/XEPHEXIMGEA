'use strict';

const browser = require('./browserlol');

const PLATORELAY_PROFILE_ID = process.env.PLATORELAY_PROFILE_ID || '49a719e6-f566-4873-bf83-3c141113b705';
const PLATORELAY_SESSION_ID = process.env.PLATORELAY_SESSION_ID || 'brl-v-v7-373zvyfw4gtswhvr4mtbdtethjkyaxk3u34xgxczk2izdwoqxq8ybo';
let cachedSessionId = '';
let cachedHelperUrl = '';
let cachedHelperSource = '';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const key = (name, down) => 'k' + (down ? 'd,' : 'u,') + name;

function webSocketConstructor() {
  try { return require('ws'); } catch {
    throw Object.assign(new Error('ต้องติดตั้ง ws เพื่อใช้ Browser.LOL stream API'), { code: 'WS_REQUIRED' });
  }
}

function withCode(message, code) {
  return Object.assign(new Error(message), { code });
}

// Browser.LOL ตอบ loggedIn:false เมื่อล็อกอินของเซสชันหมดอายุ — ต้องแยกจากด่านของต้นทาง
function assertSessionAlive(reply) {
  const data = reply && reply.data;
  if (data && data.loggedIn === false) {
    throw withCode('เซสชัน Browser.LOL หมดอายุการล็อกอิน — ใส่ session_id ใหม่แล้วลองอีกครั้ง', 'SESSION_LOGGED_OUT');
  }
  return reply;
}

async function waitForRunning(id, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const reply = await browser.v7SessionData(id, { timeoutMs: Math.min(5000, Math.max(500, deadline - Date.now())) });
    const row = reply.data && Array.isArray(reply.data.data) ? reply.data.data[0] : null;
    if (row && row.status === 'running') return row;
    if (row && ['error', 'deleted', 'stopping', 'suspended'].includes(row.status)) {
      throw withCode('เซสชัน Browser.LOL อยู่ในสถานะ ' + row.status, 'SESSION_NOT_RUNNING');
    }
    await sleep(100);
  }
  throw withCode('รอเซสชัน Browser.LOL พร้อมใช้งานไม่ทัน', 'SESSION_TIMEOUT');
}

async function openStream(id, timeoutMs) {
  const tokenReply = await browser.v7Request('POST', '/vm/' + encodeURIComponent(id) + '/stream-token', { purpose: 'connect' }, { timeoutMs: Math.min(8000, timeoutMs) });
  if (!tokenReply.ok || !tokenReply.data || !tokenReply.data.token) {
    throw withCode(tokenReply.message || 'ขอ stream token ไม่สำเร็จ', tokenReply.code || 'STREAM_TOKEN_FAILED');
  }
  const token = tokenReply.data.token;
  const WebSocket = webSocketConstructor();
  const url = 'wss://api.browser.lol/stream/' + encodeURIComponent(id) + '/api/websockets';
  const ws = new WebSocket(url, ['browser.v1', 'browser.token.' + token], { headers: { Origin: 'https://browser.lol' } });
  const waiters = [];
  let multipart = null;
  let ready = false;
  let closed = false;

  function finishWaiter(error, value) {
    const waiter = waiters.shift();
    if (!waiter) return;
    clearTimeout(waiter.timer);
    if (error) waiter.reject(error);
    else waiter.resolve(value);
  }

  function failWaiters(error) {
    while (waiters.length) finishWaiter(error);
  }

  function decodeText(value) {
    try { return Buffer.from(value || '', 'base64').toString('utf8'); } catch { return ''; }
  }

  ws.on('message', (data, isBinary) => {
    if (isBinary) return;
    const message = String(data);
    if (message === 'MODE websockets') ready = true;
    if (message.startsWith('KILL ')) failWaiters(withCode(message.slice(5), 'STREAM_CLOSED'));
    if (message.startsWith('clipboard,')) {
      multipart = null;
      finishWaiter(null, decodeText(message.slice(10)));
      return;
    }
    if (message.startsWith('clipboard_start,')) {
      const parts = message.split(',');
      multipart = { mime: parts[1] || 'text/plain', chunks: [] };
      return;
    }
    if (message.startsWith('clipboard_data,')) {
      if (multipart) multipart.chunks.push(Buffer.from(message.slice(15), 'base64'));
      return;
    }
    if (message === 'clipboard_finish') {
      if (multipart) {
        const value = Buffer.concat(multipart.chunks).toString('utf8');
        multipart = null;
        finishWaiter(null, value);
      }
    }
  });
  ws.on('error', (error) => failWaiters(error));
  ws.on('close', () => {
    closed = true;
    failWaiters(withCode('ช่องสตรีมถูกปิด', 'STREAM_CLOSED'));
  });

  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(withCode('เชื่อมต่อ Browser.LOL stream ไม่ทัน', 'STREAM_TIMEOUT')), Math.min(10000, timeoutMs));
    ws.on('open', () => {
      clearTimeout(timer);
      ws.send('SETTINGS,' + JSON.stringify({ manual_resolution: false, initialClientWidth: 1280, initialClientHeight: 800, scaling_dpi: 96, displayId: 'primary', audioRedundancy: true }));
      ws.send('cr');
      resolve();
    });
    ws.on('error', reject);
  });
  const readyDeadline = Date.now() + Math.min(5000, timeoutMs);
  while (!ready && Date.now() < readyDeadline && !closed) await sleep(20);
  if (!ready) {
    ws.close();
    throw withCode('Browser.LOL stream ไม่พร้อมรับอินพุต', 'STREAM_NOT_READY');
  }

  function requestClipboard(timeoutMs = 1800) {
    return new Promise((resolve, reject) => {
      const waiter = { resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        const index = waiters.indexOf(waiter);
        if (index >= 0) waiters.splice(index, 1);
        reject(withCode('อ่าน clipboard ไม่ทัน', 'CLIPBOARD_TIMEOUT'));
      }, timeoutMs);
      waiters.push(waiter);
      try { ws.send('cr'); } catch (error) {
        clearTimeout(waiter.timer);
        waiters.splice(waiters.indexOf(waiter), 1);
        reject(error);
      }
    });
  }

  return {
    ws,
    requestClipboard,
    close() { try { ws.close(); } catch {} }
  };
}

function tap(ws, name) {
  ws.send(key(name, true));
  ws.send(key(name, false));
}

function chord(ws, letter) {
  ws.send(key(65507, true));
  tap(ws, letter);
  ws.send(key(65507, false));
}

async function typeText(ws, text) {
  for (const char of text) {
    tap(ws, char.codePointAt(0));
  }
}

async function injectHelper(ws, helperUrl) {
  const expression = 'javascript:void((document.body||document.documentElement).appendChild(Object.assign(document.createElement("script"),{src:' + JSON.stringify(helperUrl) + '})))';
  chord(ws, 108);
  await sleep(50);
  await typeText(ws, expression);
  tap(ws, 65293);
}

async function readResult(stream, timeoutMs, retryInject) {
  const deadline = Date.now() + timeoutMs;
  let previous = '';
  let lastError = null;
  let retried = false;
  let sawHelper = false;
  await sleep(100);
  while (Date.now() < deadline) {
    try {
      chord(stream.ws, 99);
      await sleep(40);
      const text = await stream.requestClipboard(1800);
      if (text && text !== previous) {
        previous = text;
        try {
          const value = JSON.parse(text);
          if (value && value.protocol === 'platorelay-browser-v1') {
            sawHelper = true;
            if (value.done === true) return value;
          }
        } catch {}
      }
    } catch (error) {
      lastError = error;
    }
    if (!retried && !sawHelper && typeof retryInject === 'function') {
      retried = true;
      try { await retryInject(); } catch (error) { lastError = error; }
    }
    await sleep(100);
  }
  throw withCode(lastError ? 'อ่านผลจากแท็บไม่สำเร็จ: ' + lastError.message : 'รอผลจากแท็บ PlatoRelay ไม่ทัน', 'PLATORELAY_RESULT_TIMEOUT');
}

async function fetchHelperSource(helperUrl, timeoutMs) {
  if (cachedHelperSource && cachedHelperUrl === helperUrl) return cachedHelperSource;
  const response = await fetch(helperUrl, {
    cache: 'no-store',
    signal: AbortSignal.timeout(Math.max(1000, Math.min(8000, timeoutMs)))
  });
  if (!response.ok) throw withCode('ดาวน์โหลด PlatoRelay helper ไม่สำเร็จ (' + response.status + ')', 'HELPER_FETCH_FAILED');
  const source = await response.text();
  if (source.length > 200000 || !source.includes('platorelay-browser-v1')) {
    throw withCode('ไฟล์ PlatoRelay helper ไม่ถูกต้อง', 'HELPER_INVALID');
  }
  cachedHelperUrl = helperUrl;
  cachedHelperSource = source;
  return source;
}

async function waitForPageReady(id, timeoutMs) {
  const deadline = Date.now() + Math.min(6000, Math.max(500, timeoutMs));
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const reply = await browser.evaluate(id, `JSON.stringify({ ready: document.readyState !== 'loading' && !!document.body, origin: location.origin, href: location.href })`, {
        world: 'main', await_promise: false, max_chars: 3000,
        timeoutMs: Math.min(1200, Math.max(300, deadline - Date.now()))
      });
      assertSessionAlive(reply);
      const value = browser.evaluationValue(reply);
      if (value && value.ready === true && value.origin === 'https://auth.platorelay.com') return value;
    } catch (error) {
      if (error && error.code === 'SESSION_LOGGED_OUT') throw error;
      lastError = error;
    }
    await sleep(50);
  }
  throw withCode(lastError ? 'หน้า PlatoRelay โหลดไม่เสร็จ: ' + lastError.message : 'รอหน้า PlatoRelay โหลดไม่ทัน', 'PLATORELAY_PAGE_TIMEOUT');
}

async function readHelperResult(id, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  const expression = `(() => {
    if (window.__platorelayHelperResult && window.__platorelayHelperResult.done === true) return JSON.stringify(window.__platorelayHelperResult);
    const field = document.getElementById('__platorelay_result');
    if (!field || !field.value) return null;
    return field.value;
  })()`;
  while (Date.now() < deadline) {
    const remaining = deadline - Date.now();
    try {
      const reply = await browser.evaluate(id, expression, {
        world: 'main', await_promise: false, max_chars: 30000,
        timeoutMs: Math.min(1200, Math.max(300, remaining))
      });
      assertSessionAlive(reply);
      if (!reply.ok) throw withCode(reply.message || 'อ่านผลจากแท็บไม่สำเร็จ', reply.code || 'PLATORELAY_BROWSER_ERROR');
      const value = browser.evaluationValue(reply, 'platorelay-browser-v1');
      if (value && value.done === true) return value;
    } catch (error) {
      if (error && error.code === 'SESSION_LOGGED_OUT') throw error;
      lastError = error;
    }
    await sleep(50);
  }
  throw withCode(lastError ? 'อ่านผลจากแท็บไม่สำเร็จ: ' + lastError.message : 'รอผลจากแท็บ PlatoRelay ไม่ทัน', 'PLATORELAY_RESULT_TIMEOUT');
}

async function findRunningSession(id, timeoutMs) {
  if (!id) return null;
  browser.validateSessionId(id);
  const reply = await browser.v7SessionData(id, { timeoutMs: Math.min(2500, Math.max(500, timeoutMs)) });
  if (!reply.ok) return null;
  const row = reply.data && Array.isArray(reply.data.data) ? reply.data.data[0] : null;
  if (!row) return null;
  if (row.status === 'running') return id;
  if (row.status === 'starting') {
    await waitForRunning(id, Math.min(6000, Math.max(500, timeoutMs)));
    return id;
  }
  return null;
}

async function ensureSession(requestedId, inputUrl, options, timeoutMs) {
  const candidates = [...new Set([requestedId, cachedSessionId, PLATORELAY_SESSION_ID].filter(Boolean))];
  for (const candidate of candidates) {
    try {
      const id = await findRunningSession(candidate, timeoutMs);
      if (id) {
        cachedSessionId = id;
        return { id, created: false };
      }
    } catch (error) {
      if (requestedId === candidate && error.code === 'SESSION_ID_REQUIRED') throw error;
    }
  }
  const createOptions = {
    browser: 'chrome', url: inputUrl, country: options.country || 'us',
    profile_id: PLATORELAY_PROFILE_ID
  };
  if (options.egress) createOptions.egress = options.egress;
  const createdReply = await browser.v7SessionCreate(createOptions, { timeoutMs: Math.min(8000, timeoutMs) });
  assertSessionAlive(createdReply);
  const id = createdReply.data && createdReply.data.vmId;
  if (!createdReply.ok || !id) throw withCode(createdReply.message || 'สร้างเซสชัน Browser.LOL ไม่สำเร็จ', createdReply.code || 'SESSION_CREATE_FAILED');
  await waitForRunning(id, Math.min(10000, timeoutMs));
  cachedSessionId = id;
  return { id, created: true };
}

// หน้า PlatoRelay ที่อุ่นไว้ล่วงหน้า: เก็บ session + url ที่เปิดค้างไว้แล้ว
// เพื่อให้ตอนกดจริงเหลือแค่รัน helper ไม่ต้องรอ launch + page load อีก
const PREWARM_TTL_MS = 90000;
let prewarm = null;

function prewarmFresh(url) {
  if (!prewarm || prewarm.url !== url) return null;
  if (Date.now() - prewarm.at > PREWARM_TTL_MS) return null;
  return prewarm;
}

async function prewarmPlatorelay(inputUrl, options = {}) {
  const url = String(inputUrl || '').trim();
  if (!/^https:\/\//i.test(url)) return { ok: false, code: 'INVALID_URL' };
  const existing = prewarmFresh(url);
  if (existing) return { ok: true, reused: true, session_id: existing.sessionId };
  if (prewarm && prewarm.url === url && prewarm.promise) {
    try { await prewarm.promise; } catch {}
    const settled = prewarmFresh(url);
    if (settled) return { ok: true, reused: true, session_id: settled.sessionId };
  }
  const timeoutMs = Math.max(5000, Math.min(16000, Number(options.timeoutMs) || 12000));
  const entry = { url, at: Date.now(), sessionId: '', promise: null };
  entry.promise = (async () => {
    const session = await ensureSession(String(options.sessionId || '').trim(), url, options, timeoutMs);
    if (!session.created) {
      const launch = await browser.v7Request('POST', '/vm/launch', { workspaceId: session.id, url }, { timeoutMs: Math.min(6000, timeoutMs) });
      assertSessionAlive(launch);
      if (!launch.ok) throw withCode(launch.message || 'เปิดลิงก์ในเซสชันเดิมไม่สำเร็จ', launch.code || 'SESSION_LAUNCH_FAILED');
    }
    await waitForPageReady(session.id, Math.max(500, timeoutMs));
    entry.sessionId = session.id;
    entry.at = Date.now();
    return session.id;
  })();
  prewarm = entry;
  try {
    const id = await entry.promise;
    return { ok: true, session_id: id };
  } catch (error) {
    if (prewarm === entry) prewarm = null;
    return { ok: false, code: error.code || 'PREWARM_FAILED', message: error.message };
  }
}

async function runPlatorelayBrowser(inputUrl, options = {}) {
  const helperUrl = String(options.helperUrl || process.env.PLATORELAY_HELPER_URL || '').trim();
  if (!options.helperSource && !/^https:\/\//i.test(helperUrl)) throw withCode('ไม่ได้ตั้งค่า URL ของ PlatoRelay helper', 'HELPER_URL_REQUIRED');
  const timeoutMs = Math.max(5000, Math.min(16000, Number(options.timeoutMs) || 12000));
  const requestedId = String(options.sessionId || '').trim();
  const started = Date.now();
  const source = options.helperSource || await fetchHelperSource(helperUrl, timeoutMs);
  if (source.length > 200000 || !source.includes('platorelay-browser-v1')) throw withCode('ไฟล์ PlatoRelay helper ไม่ถูกต้อง', 'HELPER_INVALID');

  // ถ้าการอุ่นเครื่องยังไม่จบ ให้รอตัวเดิมแทนการสร้างเซสชันซ้ำ
  if (prewarm && prewarm.url === inputUrl && prewarm.promise && !prewarm.sessionId) {
    try { await prewarm.promise; } catch {}
  }
  const warm = prewarmFresh(inputUrl);
  let id;
  if (warm && warm.sessionId) {
    id = warm.sessionId;
    cachedSessionId = id;
  } else {
    const session = await ensureSession(requestedId, inputUrl, options, timeoutMs);
    id = session.id;
    if (!session.created) {
      const launch = await browser.v7Request('POST', '/vm/launch', { workspaceId: id, url: inputUrl }, { timeoutMs: Math.min(6000, timeoutMs) });
      assertSessionAlive(launch);
      if (!launch.ok) throw withCode(launch.message || 'เปิดลิงก์ในเซสชันเดิมไม่สำเร็จ', launch.code || 'SESSION_LAUNCH_FAILED');
    }
    await waitForPageReady(id, Math.max(500, timeoutMs - (Date.now() - started)));
  }

  const remaining = Math.max(500, timeoutMs - (Date.now() - started));
  const reply = await browser.evaluate(id, source, {
    world: 'main', await_promise: false, max_chars: 3000, timeoutMs: remaining
  });
  if (!reply.ok) throw withCode(reply.message || 'รัน PlatoRelay helper ในแท็บไม่สำเร็จ', reply.code || 'PLATORELAY_BROWSER_ERROR');
  const immediate = browser.evaluationValue(reply, 'platorelay-browser-v1');
  const result = immediate && immediate.done === true
    ? immediate
    : await readHelperResult(id, Math.max(500, timeoutMs - (Date.now() - started)));
  if (prewarm && prewarm.sessionId === id) prewarm = null;
  return { ...result, session_id: id, profile_id: PLATORELAY_PROFILE_ID, elapsed_ms: Date.now() - started };
}

module.exports = { runPlatorelayBrowser, prewarmPlatorelay };
