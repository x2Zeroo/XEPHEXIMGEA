'use strict';

const WIDGET_ORIGIN = 'https://challenges.cloudflare.com';
const GATE_HOST_RE = /(?:^|\.)(?:nerventualken\.com|onsultingco\.com|enaightdecipie\.com|lootlabs\.gg|lootdest\.(?:com|org|info))$/i;
const HUMAN_RE = /(?:confirm|verify) you are human|human verification|ยืนยัน[^\n]{0,16}มนุษย์/i;

function snapshotChallenge(text) {
  const lines = String(text || '').split(/\r?\n/);
  const indent = (line) => /^\s*/.exec(line)[0].length;
  const endOf = (start) => {
    let end = start + 1;
    while (end < lines.length && (!lines[end].trim() || indent(lines[end]) > indent(lines[start]))) end++;
    return end;
  };
  const gates = [];
  for (let i = 0; i < lines.length; i++) {
    if (!/^\s*- iframe\b/.test(lines[i])) continue;
    const end = endOf(i);
    const branch = lines.slice(i + 1, end).join('\n');
    if (!/\bheading\b/.test(branch) || !HUMAN_RE.test(branch)) continue;
    const widgets = [];
    for (let j = i + 1; j < end; j++) {
      if (/^\s*- iframe\b.*Cloudflare/i.test(lines[j])) {
        widgets.push(lines.slice(j + 1, Math.min(end, endOf(j))).join('\n'));
      }
    }
    if (widgets.length !== 1) continue;
    const checkbox = widgets[0].split('\n').find((line) => /- checkbox\b/.test(line) &&
      !/\[(?:checked|disabled|hidden)\]|aria-disabled=true/i.test(line));
    gates.push({ hasWidget: true, checkbox: !!checkbox, ref: /\[ref=([^\]]+)\]/.exec(lines[i])?.[1] || null });
  }
  return gates.length === 1 ? gates[0] : null;
}

function dataOf(reply) {
  if (!reply || !reply.ok) return null;
  const data = reply.data && reply.data.data;
  if (typeof data !== 'string') return data;
  try { return JSON.parse(data); } catch { return null; }
}

function gateWatcher() {
  const key = '__unwrapVerifiedContinueV1';
  if (window[key]) return window[key].read();
  const button = document.getElementById('go');
  const response = document.querySelector('input[name="cf-turnstile-response"]');
  const heading = document.querySelector('h1');
  if (!button || !response || !heading || !/confirm you are human|verify you are human/i.test(heading.textContent || '')) {
    return { protocol: 'verified-continue-v1', phase: 'unsupported' };
  }
  const state = { protocol: 'verified-continue-v1', phase: 'waiting', token_present: false };
  let stopped = false;
  let timer;
  let poll;
  const observer = new MutationObserver(check);
  function stop() {
    if (stopped) return;
    stopped = true;
    observer.disconnect();
    clearTimeout(timer);
    clearInterval(poll);
    window.removeEventListener('pagehide', stop);
  }
  function check() {
    state.token_present = response.value.length > 0;
    if (stopped || button.disabled || !state.token_present) return;
    state.phase = 'continued';
    stop();
    button.click();
  }
  window[key] = { read: () => { check(); return { ...state }; } };
  observer.observe(button, { attributes: true, attributeFilter: ['disabled'] });
  poll = setInterval(check, 40);
  window.addEventListener('pagehide', stop, { once: true });
  timer = setTimeout(() => { state.phase = 'expired'; stop(); delete window[key]; }, 45000);
  check();
  return { ...state };
}

function findCheckboxes(root) {
  const found = [];
  const queue = [root];
  for (let i = 0; i < queue.length && i < 50000; i++) {
    const node = queue[i];
    if (!node || typeof node !== 'object') continue;
    const attributes = node.attributes || [];
    if (node.nodeName === 'INPUT' && attributes.some((value, index) =>
      value === 'type' && attributes[index + 1] === 'checkbox') && !attributes.includes('disabled')) found.push(node);
    for (const key of ['root', 'children', 'shadowRoots', 'contentDocument']) {
      if (Array.isArray(node[key])) queue.push(...node[key]);
      else if (node[key]) queue.push(node[key]);
    }
  }
  return found;
}

async function driveCaptcha(browser, session, text) {
  const challenge = snapshotChallenge(text);
  if (!challenge || session.solved) return false;
  if (!Array.isArray(session.lootHumanIds) || !session.lootHumanIds.length) return true;
  const watcherFresh = session.captchaGateSetAt && Date.now() - session.captchaGateSetAt < 40000;
  if (!challenge.checkbox && watcherFresh && session.captchaSnapshotRef === challenge.ref) return true;
  const args = { session_id: session.id, tab_id: session.mainTabId };
  const call = (name, extra) => browser.callTool(name, { ...args, ...extra }, {
    timeoutMs: session.commandDeadline ? Math.max(1, Math.min(12000, session.commandDeadline - Date.now())) : 12000,
    tries: 1
  });
  const recordError = (reply) => {
    if (reply && reply.code === 'user_in_control') { session.locked = true; session.owner = 'person'; }
    else session.lastError = reply && (reply.message || reply.code) || 'อ่านเฟรม CAPTCHA ไม่สำเร็จ';
  };
  const inspected = await call('browser_inspect', { kind: 'frames', max_chars: 16000 });
  const frames = dataOf(inspected);
  if (!Array.isArray(frames)) { recordError(inspected); return true; }
  const source = frames.find((frame) => frame.depth === 0 &&
    [session.input_url, session.anchorUrl].some((url) => {
      try { return new URL(url).href === new URL(frame.url).href; } catch { return false; }
    }));
  const gates = frames.filter((frame) => {
    if (!source || frame.parent_id !== source.frame_id) return false;
    try {
      const url = new URL(frame.url);
      return url.protocol === 'https:' && GATE_HOST_RE.test(url.hostname) && url.pathname === '/captcha' &&
        session.lootHumanIds.includes(url.searchParams.get('urid'));
    } catch { return false; }
  });
  if (gates.length !== 1) return true;
  const gate = gates[0];
  if (session.captchaGateId !== gate.frame_id || !watcherFresh) {
    const watching = await call('browser_evaluate', {
      frame_id: gate.frame_id, world: 'main', await_promise: true, max_chars: 2000,
      expression: 'JSON.stringify((' + gateWatcher.toString() + ')())'
    });
    const value = browser.evaluationValue(watching, 'verified-continue-v1');
    if (!value || value.phase === 'unsupported') { recordError(watching); return true; }
    session.captchaGateId = gate.frame_id;
    session.captchaGateSetAt = Date.now();
    session.captchaSnapshotRef = challenge.ref;
    if (value.phase === 'continued') { session.lootLastProbe = 0; return true; }
  }
  if (!challenge.checkbox) return true;
  const widgets = frames.filter((frame) => frame.parent_id === gate.frame_id &&
    frame.security_origin === WIDGET_ORIGIN);
  if (widgets.length !== 1 || session.captchaPressedFrame === widgets[0].frame_id) return true;
  const frameId = widgets[0].frame_id;
  const document = await call('browser_cdp', {
    frame_id: frameId, method: 'DOM.getDocument', params: { depth: -1, pierce: true }, max_chars: 100000
  });
  const nodes = findCheckboxes(dataOf(document));
  if (nodes.length !== 1) { if (!document.ok) recordError(document); return true; }
  const focused = await call('browser_cdp', {
    frame_id: frameId, method: 'DOM.focus', params: { backendNodeId: nodes[0].backendNodeId }, max_chars: 1000
  });
  if (!focused.ok) { recordError(focused); return true; }
  session.captchaPressedFrame = frameId;
  const pressed = await call('browser_press_key', { key: 'Space' });
  if (!pressed.ok) recordError(pressed);
  session.lootLastProbe = 0;
  return true;
}

module.exports = { driveCaptcha, snapshotChallenge, findCheckboxes, gateWatcher, dataOf, GATE_HOST_RE, WIDGET_ORIGIN };
