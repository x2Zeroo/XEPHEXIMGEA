'use strict';
const crypto = require('crypto');
const http2 = require('http2');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const ALLOWED = [
  'linkvertise.com', 'direct-link.net', 'link-to.net', 'link-hub.net', 'link-target.net',
  'link-center.net', 'link-place.net', 'link-spot.net', 'up-to-down.net', 'file-link.net', 'filemedia.net'
];
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const TIMEOUT_MS = 10000;

const hostIn = (host, domain) => host === domain || host.endsWith('.' + domain);
const hostAllowed = (host) => ALLOWED.some((d) => hostIn(host, d));

function parseAllowed(raw) {
  let u;
  try {
    u = new URL(raw);
  } catch {
    return null;
  }
  if (!['http:', 'https:'].includes(u.protocol)) return null;
  if (!hostAllowed(u.hostname)) return null;
  return u;
}

function decodeDynamic(u) {
  const r = u.searchParams.get('r');
  if (!r) return null;
  try {
    let b = r.replace(/ /g, '+').replace(/-/g, '+').replace(/_/g, '/');
    while (b.length % 4) b += '=';
    const d = Buffer.from(b, 'base64').toString('utf8');
    return /^https?:\/\//i.test(d) ? d : null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Linkvertise (อัปเดต 2026)
// ---------------------------------------------------------------------------
// เมื่อก่อนดึงปลายทางจาก field `target_host` ของ query `linkByIdentifier` ได้เลย
// แต่ตอนนี้ schema เปลี่ยน: `PublicLink.target_host` คืนมาแค่ "ชื่อโฮสต์" (เช่น
// linkvertise.com) ไม่ใช่ URL ปลายทางจริง -> เป็นสาเหตุที่ได้ผลเป็น
// https://linkvertise.com
//
// ปลายทางจริงตอนนี้อยู่หลัง paywall ต้องเดินผ่าน flow:
//   query getContent(input, origin)  ->  union ContentAccessResponse
//     • DetailPageTargetData { type url paste }  = ปลายทางจริง (ปลดล็อคแล้ว)
//     • ContentAccessTaskSet { tasks[] }         = ยังมีงานค้าง (เช่น WaitTask)
//   mutation completeTask(input, task_id, task_args)  = เคลียร์ WaitTask หลังครบเวลา
// วนจน getContent คืน DetailPageTargetData แล้วอ่าน url/paste
const LV_ENDPOINT = 'https://publisher.linkvertise.com/graphql';
const LV_ORIGIN = 'https://publisher.linkvertise.com';
const LV_HEADERS = { 'Content-Type': 'application/json', 'User-Agent': UA, Origin: 'https://linkvertise.com', Referer: 'https://linkvertise.com/' };
const LV_BUDGET_MS = parseInt(process.env.LV_MAX_WAIT_MS || '4000', 10);
const LV_FAST_WAIT_MAX_SEC = Math.max(0, parseInt(process.env.LV_FAST_WAIT_MAX_SEC || '1', 10));
const LV_PROXY_ENDPOINT = process.env.LV_PROXY_URL || 'https://ixproxy.vercel.app/api/v1/proxy';
const LV_PROXY_MAX_ATTEMPTS = Math.max(1, Math.min(4, parseInt(process.env.LV_PROXY_MAX_ATTEMPTS || '3', 10)));

const LV_META = `query($input: PublicLinkIdentificationInput!){
  linkByIdentifier(linkIdentificationInput: $input){ title is_premium_only }
}`;
const LV_GET_CONTENT = `query($input: PublicLinkIdentificationInput!, $origin: String){
  getContent(input: $input, origin: $origin){
    __typename
    ... on DetailPageTargetData { type url paste }
    ... on ContentAccessTaskSet {
      tasks {
        __typename id status
        ... on WaitTask { remainingWaitingTime adsTotal }
        ... on AdTask { adIndex adsTotal }
      }
    }
  }
}`;
const LV_COMPLETE_TASK = `mutation($input: PublicLinkIdentificationInput!, $task_id: String!, $task_args: TaskArgument!){
  completeTask(input: $input, task_id: $task_id, task_args: $task_args){ __typename id status }
}`;

let lvH2Client = null;
function getLvH2Client() {
  if (lvH2Client && !lvH2Client.closed && !lvH2Client.destroyed) return lvH2Client;
  const client = http2.connect(LV_ORIGIN);
  if (typeof client.unref === 'function') client.unref();
  client.on('error', () => { if (lvH2Client === client) lvH2Client = null; });
  client.on('close', () => { if (lvH2Client === client) lvH2Client = null; });
  client.on('goaway', () => { if (lvH2Client === client) lvH2Client = null; });
  lvH2Client = client;
  return client;
}

function warmConnections() {
  try {
    const client = getLvH2Client();
    if (client && !client.closed && !client.destroyed) {
      lvH2Post({ cookie: '' }, { query: '{ __typename }' }, 1500).catch(() => {});
    }
  } catch {}
}

function lvH2Post(jar, body, timeoutMs = TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const client = getLvH2Client();
    const payload = JSON.stringify(body);
    const headers = {
      ':method': 'POST',
      ':path': '/graphql',
      'content-type': 'application/json',
      'user-agent': UA,
      'origin': 'https://linkvertise.com',
      'referer': 'https://linkvertise.com/',
      'content-length': Buffer.byteLength(payload)
    };
    if (jar && jar.cookie) headers['cookie'] = jar.cookie;
    const req = client.request(headers);
    const timer = setTimeout(() => {
      if (!settled) { settled = true; try { req.close(); } catch {} reject(new Error('HTTP/2 request timeout')); }
    }, timeoutMs);
    const chunks = [];
    req.on('response', (resHeaders) => {
      const sc = resHeaders['set-cookie'];
      const list = Array.isArray(sc) ? sc : (sc ? [sc] : []);
      if (list.length && jar) {
        const jarMap = new Map((jar.cookie || '').split('; ').filter(Boolean).map((c) => [c.split('=')[0], c]));
        for (const c of list) { const kv = String(c).split(';')[0]; jarMap.set(kv.split('=')[0], kv); }
        jar.cookie = [...jarMap.values()].join('; ');
      }
    });
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      clearTimeout(timer);
      if (settled) return;
      settled = true;
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(e); }
    });
    req.on('error', (err) => {
      clearTimeout(timer);
      if (!settled) { settled = true; reject(err); }
    });
    req.end(payload);
  });
}

function lvProxyError(message) {
  const error = new Error(message);
  error.proxyTransport = true;
  return error;
}

function lvProxyTarget(body) {
  const target = new URL(LV_ENDPOINT);
  target.searchParams.set('query', body.query);
  if (body.variables != null) target.searchParams.set('variables', JSON.stringify(body.variables));
  if (body.operationName) target.searchParams.set('operationName', body.operationName);
  return target.href;
}

// พร็อกซีที่กำหนดรับเฉพาะ GET จึงส่ง GraphQL เป็น query/variables ใน URL
// ไม่ส่ง proxy id เพื่อให้พร็อกซีสุ่ม IP ใหม่ทุกคำขอตามที่ต้องการ
async function lvProxyGqlRaw(jar, body, timeoutMs = TIMEOUT_MS) {
  if (Array.isArray(body)) {
    const results = [];
    // รักษาลำดับ mutation -> query ของ batch เดิม
    for (const item of body) results.push(await lvProxyGqlRaw(jar, item, timeoutMs));
    return results;
  }
  if (!body || typeof body.query !== 'string') throw lvProxyError('คำขอ GraphQL ของ Linkvertise ไม่ถูกต้อง');

  let lastError = null;
  // คำขอที่เครือข่าย abort ให้ลองใหม่ด้วย IP ใหม่ก่อน ไม่ต้องเริ่มงานทั้งรอบใหม่
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const proxyUrl = new URL(LV_PROXY_ENDPOINT);
      proxyUrl.searchParams.set('format', 'json');
      proxyUrl.searchParams.set('url', lvProxyTarget(body));

      const response = await fetch(proxyUrl.href, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(Math.max(1000, timeoutMs || TIMEOUT_MS))
      });
      const raw = await response.text();

      let envelope;
      try { envelope = JSON.parse(raw); } catch {
        throw lvProxyError('พร็อกซีของ Linkvertise ตอบกลับไม่ใช่ JSON');
      }
      if (!response.ok || !envelope || envelope.ok !== true) {
        throw lvProxyError((envelope && (envelope.error || envelope.message)) || ('พร็อกซีของ Linkvertise ล้มเหลว (HTTP ' + response.status + ')'));
      }

      const targetHeaders = (envelope.target && envelope.target.headers) || {};
      const setCookies = targetHeaders['set-cookie'] || targetHeaders['Set-Cookie'] || [];
      const cookieList = Array.isArray(setCookies) ? setCookies : [setCookies];
      if (cookieList.length) {
        const jarMap = new Map((jar.cookie || '').split('; ').filter(Boolean).map((c) => [c.split('=')[0], c]));
        for (const c of cookieList) {
          const kv = String(c).split(';')[0];
          jarMap.set(kv.split('=')[0], kv);
        }
        jar.cookie = [...jarMap.values()].join('; ');
      }

      const content = envelope.body && envelope.body.data;
      if (typeof content !== 'string') throw lvProxyError('พร็อกซีไม่ได้ส่งเนื้อหา GraphQL ของ Linkvertise กลับมา');
      try { return JSON.parse(content); } catch {
        throw lvProxyError('ปลายทาง Linkvertise ตอบกลับไม่ใช่ JSON');
      }
    } catch (error) {
      lastError = error && error.proxyTransport
        ? error
        : lvProxyError('เชื่อมต่อพร็อกซีของ Linkvertise ไม่สำเร็จ: ' + ((error && error.message) || String(error)));
    }
  }
  throw lastError || lvProxyError('เชื่อมต่อพร็อกซีของ Linkvertise ไม่สำเร็จ');
}

async function lvGqlRaw(jar, body, timeoutMs = TIMEOUT_MS) {
  if (jar && jar.useProxy) return lvProxyGqlRaw(jar, body, timeoutMs);
  try {
    return await lvH2Post(jar, body, timeoutMs);
  } catch {
    const res = await fetch(LV_ENDPOINT, {
      method: 'POST',
      headers: { ...LV_HEADERS, ...(jar && jar.cookie ? { Cookie: jar.cookie } : {}) },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs)
    });
    const setCookies = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    if (setCookies.length && jar) {
      const jarMap = new Map((jar.cookie || '').split('; ').filter(Boolean).map((c) => [c.split('=')[0], c]));
      for (const c of setCookies) { const kv = c.split(';')[0]; jarMap.set(kv.split('=')[0], kv); }
      jar.cookie = [...jarMap.values()].join('; ');
    }
    return res.json();
  }
}

async function lvGql(jar, body, timeoutMs) {
  const j = await lvGqlRaw(jar, body, timeoutMs);
  if (j && j.errors && j.errors.length) throw new Error(j.errors.map((e) => e.message).join(' | '));
  return j && j.data;
}

async function lvFetchMeta(ident) {
  try {
    const d = await lvGql({ cookie: '' }, { query: LV_META, variables: { input: ident } }, 1500);
    return (d && d.linkByIdentifier) || {};
  } catch {
    return {};
  }
}

function lvFail(message, waitSec) {
  const e = new Error(message);
  if (waitSec) e.waitSec = waitSec;
  return e;
}

async function lvResolveTarget(ident, budgetMs, opts = {}) {
  const t0 = Date.now();
  const jar = { cookie: '', useProxy: Boolean(opts.proxy) };
  const via = jar.useProxy ? 'linkvertise-gql-proxy' : 'linkvertise-gql-h2';
  const deadline = t0 + Math.max(1200, budgetMs);

  // รอบ 1: ยิง Batch [getContent, linkByIdentifier] พร้อมกันใน 1 HTTP/2 round trip
  const initBatch = await lvGqlRaw(jar, [
    { query: LV_GET_CONTENT, variables: { input: ident, origin: 'DETAIL_PAGE' } },
    { query: LV_META, variables: { input: ident } }
  ], Math.min(TIMEOUT_MS, budgetMs));

  let node = null;
  let meta = {};
  if (Array.isArray(initBatch)) {
    if (initBatch[0] && initBatch[0].errors && initBatch[0].errors.length) {
      throw new Error(initBatch[0].errors.map((e) => e.message).join(' | '));
    }
    node = initBatch[0] && initBatch[0].data && initBatch[0].data.getContent;
    meta = (initBatch[1] && initBatch[1].data && initBatch[1].data.linkByIdentifier) || {};
  } else {
    if (initBatch && initBatch.errors && initBatch.errors.length) {
      throw new Error(initBatch.errors.map((e) => e.message).join(' | '));
    }
    node = initBatch && initBatch.data && initBatch.data.getContent;
  }

  if (node && node.__typename === 'DetailPageTargetData') {
    if (!node.url && !node.paste) throw new Error('Linkvertise ไม่คืนปลายทาง (อาจเป็นลิงก์พรีเมียมเท่านั้น)');
    return { url: node.url || null, paste: node.paste || null, target_type: node.type || null, meta, via };
  }

  // รอบ 2: ถ้าเริ่มที่ WaitTask และมีหลาย adsTotal (>1) -> ยิงขนาน (Stream A: complete(Wait)+getContent || Stream B: probe Ad2..Ad3 IDs)
  if (node && node.__typename === 'ContentAccessTaskSet' && Array.isArray(node.tasks)) {
    const active = node.tasks.find((t) => t && t.__typename !== 'PremiumTask' && t.status !== 'DONE');
    const prem = node.tasks.find((t) => t && t.__typename === 'PremiumTask');
    if (active && active.__typename === 'WaitTask') {
      const waitSec = Math.max(0, active.remainingWaitingTime || 0);
      if (waitSec > LV_FAST_WAIT_MAX_SEC) {
        const human = waitSec >= 60 ? Math.ceil(waitSec / 60) + ' นาที' : Math.ceil(waitSec) + ' วินาที';
        throw lvFail('Linkvertise ติดคิวรอ ' + human + ' บน IP ของเซิร์ฟเวอร์ (ไม่สามารถจบใน 1 วินาทีได้โดยไม่เปลี่ยน IP)', waitSec);
      }
      // ถ้ารอ <= 1 วิ ให้รอเฉพาะช่วงสั้นๆ ที่ไม่ทำให้งบ 1 วิทะลุ หรือลองยิงทันที
      if (waitSec > 0) {
        const maxWait = Math.max(0, Math.min(waitSec * 1000, 350 - (Date.now() - t0)));
        if (maxWait > 20) await sleep(maxWait);
      }
      const hasMultiAds = (active.adsTotal || 0) > 1 && prem && /^[0-9a-f]+$/i.test(active.id) && /^[0-9a-f]+$/i.test(prem.id);
      if (hasMultiAds) {
        const startNum = BigInt('0x' + active.id);
        const diff = Number(BigInt('0x' + prem.id) - startNum);
        if (diff > 3 && diff < 300) {
          const lo = Math.max(1, Math.floor(diff * 0.42));
          const hi = Math.min(diff - 1, Math.ceil(diff * 0.86));
          const ids = [];
          for (let k = lo; k <= hi; k++) ids.push((startNum + BigInt(k)).toString(16).padStart(active.id.length, '0'));
          const streams = [
            lvGqlRaw(jar, [
              { query: LV_COMPLETE_TASK, variables: { input: ident, task_id: active.id, task_args: {} } },
              { query: LV_GET_CONTENT, variables: { input: ident, origin: 'DETAIL_PAGE' } }
            ], 2500)
          ];
          for (let i = 0; i < ids.length; i += 12) {
            const sub = ids.slice(i, i + 12);
            const fields = sub.map((id, idx) => `t${idx}: completeTask(input:$input,task_id:"${id}",task_args:{}){ id status }`).join(' ');
            streams.push(lvGqlRaw(jar, { query: `mutation($input: PublicLinkIdentificationInput!){ ${fields} }`, variables: { input: ident } }, 2500).catch(() => null));
          }
          const resList = await Promise.all(streams);
          const stepA = Array.isArray(resList[0]) && resList[0][1] && resList[0][1].data && resList[0][1].data.getContent;
          if (stepA) {
            node = stepA;
            if (node.__typename === 'DetailPageTargetData') {
              if (!node.url && !node.paste) throw new Error('Linkvertise ไม่คืนปลายทาง');
              return { url: node.url || null, paste: node.paste || null, target_type: node.type || null, meta, via };
            }
            const ad1 = (node.tasks || []).find((t) => t && t.__typename !== 'PremiumTask' && t.status !== 'DONE');
            const foundIds = [];
            for (const r of resList.slice(1)) {
              if (r && r.data) {
                for (const v of Object.values(r.data)) {
                  if (v && v.id && (!ad1 || v.id > ad1.id) && v.id < prem.id && !foundIds.includes(v.id)) {
                    foundIds.push(v.id);
                  }
                }
              }
            }
            foundIds.sort();
            const expectedMore = Math.max(1, (active.adsTotal || 3) - 1);
            const picked = foundIds.slice(0, expectedMore);
            if (ad1 && picked.length) {
              // รอบ 3: ยิงทุก AdTask แบบ Parallel HTTP/2 Streams แทนการอัดใน mutation เดียวที่เซิร์ฟเวอร์รันแบบ sequential
              const parStreams = [
                lvGqlRaw(jar, { query: LV_COMPLETE_TASK, variables: { input: ident, task_id: ad1.id, task_args: {} } }, 2500).catch(() => null)
              ];
              for (const id of picked) {
                parStreams.push(
                  lvGqlRaw(jar, {
                    query: `mutation($input: PublicLinkIdentificationInput!){ s: startTask(input:$input,task_id:"${id}",task_args:{}){ id status } c: completeTask(input:$input,task_id:"${id}",task_args:{}){ id status } }`,
                    variables: { input: ident }
                  }, 2500).catch(() => null)
                );
              }
              await Promise.all(parStreams);
              // รอบ 4: ดึงปลายทางจริงหลังทุก AdTask จบแล้ว
              const r4 = await lvGql(jar, { query: LV_GET_CONTENT, variables: { input: ident, origin: 'DETAIL_PAGE' } }, 2500);
              if (r4 && r4.getContent) node = r4.getContent;
            }
          }
        }
      }
    }
  }

  let prevTaskId = null;
  for (let i = 0; i < 8; i++) {
    if (!node) throw new Error('ไม่พบข้อมูลเนื้อหาจาก Linkvertise');

    if (node.__typename === 'DetailPageTargetData') {
      if (!node.url && !node.paste) throw new Error('Linkvertise ไม่คืนปลายทาง (อาจเป็นลิงก์พรีเมียมเท่านั้น)');
      return { url: node.url || null, paste: node.paste || null, target_type: node.type || null, meta, via };
    }

    const tasks = (node.tasks || []);
    const task = tasks.find((t) => t && t.__typename !== 'PremiumTask' && t.status !== 'DONE');
    if (!task || !task.id) throw lvFail('ลิงก์นี้มีขั้นตอนที่แกะอัตโนมัติไม่ได้ด้วย GraphQL');
    if (task.id === prevTaskId) {
      throw lvFail('Linkvertise ยังไม่ปลดล็อกงานนี้ (อาจติดเวลารอบน IP)', task.remainingWaitingTime || undefined);
    }

    if (task.__typename === 'WaitTask') {
      const waitSec = Math.max(0, task.remainingWaitingTime || 0);
      if (waitSec > LV_FAST_WAIT_MAX_SEC) {
        const human = waitSec >= 60 ? Math.ceil(waitSec / 60) + ' นาที' : Math.ceil(waitSec) + ' วินาที';
        throw lvFail('ลิงก์นี้ติดเวลารอ ~' + human + ' บน IP ของเซิร์ฟเวอร์ (เกินงบเวลา API 1 วินาที)', waitSec);
      }
      if (waitSec > 0) {
        const maxWait = Math.max(0, Math.min(waitSec * 1000, deadline - Date.now() - 250));
        if (maxWait > 20) await sleep(maxWait);
      }
    }

    prevTaskId = task.id;
    const batch = await lvGqlRaw(jar, [
      { query: LV_COMPLETE_TASK, variables: { input: ident, task_id: task.id, task_args: {} } },
      { query: LV_GET_CONTENT, variables: { input: ident, origin: 'DETAIL_PAGE' } }
    ], 2500);
    if (Array.isArray(batch) && batch.length >= 2) {
      if (batch[1] && batch[1].errors && batch[1].errors.length) {
        throw new Error(batch[1].errors.map((e) => e.message).join(' | '));
      }
      node = batch[1] && batch[1].data && batch[1].data.getContent;
    } else {
      await lvGql(jar, { query: LV_COMPLETE_TASK, variables: { input: ident, task_id: task.id, task_args: {} } }, 2500);
      const next = await lvGql(jar, { query: LV_GET_CONTENT, variables: { input: ident, origin: 'DETAIL_PAGE' } }, 2500);
      node = next && next.getContent;
    }
  }
  throw lvFail('แกะ Linkvertise ไม่สำเร็จหลังจากพยายามหลายครั้ง');
}

async function lvResolveTargetViaProxy(ident, budgetMs) {
  let lastError = null;
  for (let attempt = 0; attempt < LV_PROXY_MAX_ATTEMPTS; attempt++) {
    try {
      // สร้าง jar ใหม่ทุกรอบ เพื่อเลือก IP ใหม่เมื่อ IP ก่อนหน้าติดคิว
      return await lvResolveTarget(ident, budgetMs, { proxy: true });
    } catch (error) {
      lastError = error;
      const message = String((error && error.message) || '');
      const transientTaskState = /ยังไม่ปลดล็อกงานนี้|TaskSet Not Found|แกะ Linkvertise ไม่สำเร็จหลังจากพยายามหลายครั้ง/i.test(message);
      if (!error || (!error.waitSec && !error.proxyTransport && !transientTaskState)) throw error;
    }
  }
  throw lastError || lvFail('แกะ Linkvertise ผ่านพร็อกซีไม่สำเร็จ');
}

async function bypass(inputUrl, opts = {}) {
  const start = Date.now();
  const budget = (opts && opts.budgetMs) || LV_BUDGET_MS;
  try {
    let u = parseAllowed(inputUrl);
    if (!u) throw new Error('รองรับเฉพาะลิงก์ Linkvertise (เช่น linkvertise.com, link-hub.net, link-target.net)');

    const firstParts = u.pathname.split('/').filter(Boolean);
    if (firstParts[firstParts.length - 1] === 'dynamic') {
      const direct = decodeDynamic(u);
      if (!direct) throw new Error('ลิงก์แบบ dynamic นี้ไม่มีปลายทางใน parameter r ให้ถอดรหัส');
      return {
        status: 'success',
        type: 'link',
        input_url: inputUrl,
        destination: direct,
        title: null,
        is_premium_only: false,
        via: 'linkvertise-dynamic',
        elapsed_ms: Date.now() - start
      };
    }

    let userId = firstParts[0] === 'access' ? firstParts[1] : firstParts[0];
    let hash = firstParts[0] === 'access' ? firstParts[2] : firstParts[1];
    if (!hostIn(u.hostname, 'linkvertise.com') && (!/^\d+$/.test(String(userId || '')) || !hash)) {
      const res = await fetch(u.href, {
        method: 'GET',
        headers: { 'User-Agent': UA },
        redirect: 'manual',
        signal: AbortSignal.timeout(TIMEOUT_MS)
      });
      const loc = res.headers.get('location');
      if (loc) {
        const next = parseAllowed(new URL(loc, u).href);
        if (!next) throw new Error('ลิงก์ที่ redirect ไปไม่อยู่ในโดเมนที่รองรับ');
        u = next;
      }
      const parts = u.pathname.split('/').filter(Boolean);
      userId = parts[0] === 'access' ? parts[1] : parts[0];
      hash = parts[0] === 'access' ? parts[2] : parts[1];
    }
    if (!userId || !hash) throw new Error('รูปแบบลิงก์ไม่ถูกต้อง');

    const ident = { userIdAndUrl: { user_id: String(userId), url: String(hash) } };
    // เริ่มผ่านพร็อกซีทันที เพื่อไม่เสียเวลากับการเชื่อมต่อตรงที่อาจถูก abort
    const target = await lvResolveTargetViaProxy(ident, budget);

    const meta = (target && target.meta) || {};
    let dest = target.url || null;
    if (dest && !/^https?:\/\//i.test(dest)) dest = 'https://' + dest;

    return {
      status: 'success',
      type: dest ? 'link' : (target.paste ? 'paste' : 'link'),
      input_url: inputUrl,
      destination: dest,
      paste: target.paste || null,
      title: (meta && meta.title) || null,
      is_premium_only: Boolean(meta && meta.is_premium_only),
      via: target.via || 'linkvertise-gql-h2',
      elapsed_ms: Date.now() - start
    };
  } catch (err) {
    const out = {
      status: 'error',
      input_url: inputUrl,
      message: err.name === 'TimeoutError' ? 'หมดเวลารอการตอบกลับ' : err.message,
      elapsed_ms: Date.now() - start
    };
    if (err && err.waitSec) out.wait_seconds = err.waitSec;
    return out;
  }
}

// ---- platoboost.com key-system bypass (ported from Flask screenshots) ----

const PLATOBOOST_PROJECT = '2569';
// รอก่อนยิง PUT ยืนยัน session ของ platoboost — ปรับได้ด้วย ENV เพื่อเร่งความเร็ว (ค่าเดิม 5000ms)
const PLATOBOOST_WAIT_MS = Math.max(0, parseInt(process.env.PLATOBOOST_WAIT_MS || '0', 10));
const DISCORD_WEBHOOK_URL = ''; // FILL: ใส่ webhook ถ้าจะใช้ sendDiscordWebhook


async function sendDiscordWebhook(link) {
  if (!DISCORD_WEBHOOK_URL) return;
  const payload = {
    embeds: [{ title: 'Security Check!', description: `**Please solve the Captcha**: [Open](${link})`, color: 5763719 }]
  };
  try {
    await fetch(DISCORD_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } catch {
    // ส่ง webhook ไม่สำเร็จ ปล่อยผ่านเงียบๆ
  }
}

function getTurnstileResponse() {
  // Placeholder — ต้องแก้ตรงนี้ถ้า platoboost บังคับ Turnstile จริง
  return '';
}

function decodeLootlink(lootLink) {
  const decoded = decodeURIComponent(lootLink);
  const rParam = new URL(decoded, 'https://x').searchParams.get('r') || '';
  if (!rParam) return null;
  let padded = decodeURIComponent(rParam).replace(/-/g, '+').replace(/_/g, '/');
  while (padded.length % 4) padded += '=';
  let decodedBase64;
  try {
    decodedBase64 = Buffer.from(padded, 'base64').toString('utf8');
  } catch {
    return null;
  }
  const tk = new URL(decodedBase64, 'https://x').searchParams.get('tk');
  return tk || null;
}

async function bypassPlatoboost(id) {
  const start = Date.now();
  const api = (path) => fetch(`https://api-gateway.platoboost.com/v1/${path}`, { signal: AbortSignal.timeout(TIMEOUT_MS) });

  try {
    let res = await api(`authenticators/${PLATOBOOST_PROJECT}/${id}`);
    if (!res.ok) return { key: null, elapsed_ms: Date.now() - start };

    let data = await res.json();
    if (data.key) return { key: data.key, elapsed_ms: Date.now() - start };

    const captcha = data.captcha || '';
    res = await fetch(`https://api-gateway.platoboost.com/v1/sessions/auth/${PLATOBOOST_PROJECT}/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captcha: captcha ? getTurnstileResponse() : '', type: captcha ? 'Turnstile' : '' }),
      signal: AbortSignal.timeout(TIMEOUT_MS)
    });
    if (!res.ok) return { key: null, elapsed_ms: Date.now() - start };

    const sessionData = await res.json();
    const tk = decodeLootlink(sessionData.redirect || '');
    if (!tk) return { key: null, elapsed_ms: Date.now() - start };
    if (PLATOBOOST_WAIT_MS > 0) await sleep(Math.min(500, PLATOBOOST_WAIT_MS));

    res = await fetch(`https://api-gateway.platoboost.com/v1/sessions/auth/${PLATOBOOST_PROJECT}/${id}/${tk}`, {
      method: 'PUT',
      signal: AbortSignal.timeout(TIMEOUT_MS)
    });
    if (!res.ok) {
      await sleep(80);
      res = await fetch(`https://api-gateway.platoboost.com/v1/sessions/auth/${PLATOBOOST_PROJECT}/${id}/${tk}`, {
        method: 'PUT',
        signal: AbortSignal.timeout(TIMEOUT_MS)
      });
    }
    if (!res.ok) return { key: null, elapsed_ms: Date.now() - start };

    for (let i = 0; i < 3; i++) {
      res = await api(`authenticators/${PLATOBOOST_PROJECT}/${id}`);
      if (res.ok) {
        data = await res.json().catch(() => ({}));
        if (data && data.key) return { key: data.key, elapsed_ms: Date.now() - start };
      }
      if (i < 2) await sleep(80);
    }
    return { key: null, elapsed_ms: Date.now() - start };
  } catch {
    return { key: null, elapsed_ms: Date.now() - start };
  }
}

// ============================================================================
// auth.platorelay.com — ใช้เฉพาะ API ของต้นทางและลิงก์ checkpoint ที่ฝังมาแล้ว
// ไม่มีการตาม redirect, เปิดหน้าโฆษณา, เดา CAPTCHA หรือสลับเข้า browser autopilot
// งบเวลาครอบคลุมทุกคำขอและการอ่าน body; timeout ไม่ใช่ผลสำเร็จของการข้าม
// ============================================================================

const PLATORELAY_ORIGIN = 'https://auth.platorelay.com';
function platorelayHelperFromRequest(req) {
  if (process.env.PLATORELAY_HELPER_URL) return process.env.PLATORELAY_HELPER_URL;
  const headers = (req && req.headers) || {};
  const host = String(headers['x-forwarded-host'] || headers.host || '').split(',')[0].trim();
  if (!host || !/^[A-Za-z0-9.:[\]-]+$/.test(host)) return '';
  const forwarded = String(headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  const protocol = forwarded === 'http' || forwarded === 'https' ? forwarded : 'https';
  return protocol + '://' + host + '/platorelay-helper.js';
}
const configuredPlatorelayBudget = Number(process.env.PLATORELAY_BUDGET_MS);
const PLATORELAY_BUDGET_MS = Number.isFinite(configuredPlatorelayBudget) && configuredPlatorelayBudget > 0
  ? Math.min(9000, Math.max(250, Math.floor(configuredPlatorelayBudget)))
  : 9000;
const PLATORELAY_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36';

const isPlatorelayHost = (host) => hostIn(host, 'platorelay.com');

function platorelayHeaders(extra) {
  return {
    'User-Agent': PLATORELAY_UA,
    Accept: 'application/json',
    'Accept-Language': 'en-US,en;q=0.9',
    'X-Client-Name': 'platoboost webclient',
    'X-Client-Version': '8.2.3',
    'Sec-CH-UA': '"Chromium";v="142", "Not:A-Brand";v="24", "Google Chrome";v="142"',
    'Sec-CH-UA-Mobile': '?0',
    'Sec-CH-UA-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    ...(extra || {})
  };
}

// AES-128-CTR; key/iv เอา "ค่า char code" ขอ�� ticket ตรง ๆ (latin1) ตาม client ต้นฉบับ
function platorelayCtrHex(plainStr, keyStr, ivStr) {
  const key = Buffer.from(keyStr, 'latin1');
  const iv = Buffer.from(ivStr, 'latin1');
  if (key.length !== 16 || iv.length !== 16) return 'empty';
  const cipher = crypto.createCipheriv('aes-128-ctr', key, iv);
  return Buffer.concat([cipher.update(Buffer.from(plainStr, 'utf8')), cipher.final()]).toString('hex');
}

function platorelayBuildMeta(ticket) {
  if (!ticket || ticket.length < 32) return 'empty';
  const info = [
    { name: 'screen', data: { width: 1920, height: 1080, availWidth: 1920, availHeight: 1040, colorDepth: 24, pixelDepth: 24, orientation: { type: 'landscape-primary', angle: 0 } } },
    { name: 'navigator', data: {
        userAgent: PLATORELAY_UA, platform: 'Win32', maxTouchPoints: 0,
        plugins: { length: 5, item: [
          { name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
          { name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
          { name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
          { name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
          { name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'Portable Document Format' }
        ] },
        mimeTypes: { length: 2, item: [
          { type: 'application/pdf', description: 'Portable Document Format', suffixes: 'pdf' },
          { type: 'text/pdf', description: 'Portable Document Format', suffixes: 'pdf' }
        ] }
    } },
    { name: 'performance', data: Date.now() },
    { name: 'history', data: { length: lootRnd(1, 4) } },
    { name: 'webdriver', webdriver: false },
    { name: 'connection', data: { effectiveType: '4g', downlink: Math.round((1.5 + Math.random() * 8.5) * 10) / 10, rtt: [50, 100, 150, 200][lootRnd(0, 3)], saveData: false } }
  ];
  return platorelayCtrHex(JSON.stringify({ browserInfo: info }), ticket.slice(0, 16), ticket.slice(16, 32));
}

function platorelayError(code, message) {
  return Object.assign(new Error(message), { code });
}

const PLATORELAY_ACCOUNT_UNLOCK_CODE = 'account-unlock-required';
const PLATORELAY_ACCOUNT_UNLOCK_MESSAGE = "Please paste your Platoboost (Delta) link into your browser, wait 5 seconds, and click `Continue`. Then complete the account verification when prompted, copy the adlink you receive, and send it to the bot.";

function platorelayIsAccountUnlock(code) {
  return String(code || '').trim().toLowerCase() === PLATORELAY_ACCOUNT_UNLOCK_CODE;
}

function platorelayAccountUnlockError() {
  return platorelayError('PLATORELAY_ACCOUNT_UNLOCK_REQUIRED', PLATORELAY_ACCOUNT_UNLOCK_MESSAGE);
}

function platorelayErrorDetails(code, message, fallbackCode, fallbackMessage) {
  if (platorelayIsAccountUnlock(code)) {
    return {
      code: 'PLATORELAY_ACCOUNT_UNLOCK_REQUIRED',
      message: PLATORELAY_ACCOUNT_UNLOCK_MESSAGE,
      upstream_code: PLATORELAY_ACCOUNT_UNLOCK_CODE
    };
  }
  return { code: code || fallbackCode, message: message || fallbackMessage };
}

function platorelayResponseError(message, upstreamCode) {
  const detail = typeof message === 'string' ? message.slice(0, 240) : 'ต้นทางไม่คืนข้อมูลที่ใช้ได้';
  if (platorelayIsAccountUnlock(upstreamCode)) return platorelayAccountUnlockError();
  const code = /captcha|human/i.test(String(upstreamCode || '') + ' ' + detail) ? 'PLATORELAY_VERIFICATION_REQUIRED'
    : /outdated|client.version|(?:meta|stream).payload/i.test(detail) ? 'PLATORELAY_CLIENT_REJECTED'
    : /expired|invalid.ticket|invalid.session|session.not.found/i.test(detail) ? 'PLATORELAY_INVALID_TICKET'
    : /wait|too.fast|timer/i.test(detail) ? 'PLATORELAY_WAIT_REQUIRED'
    : 'PLATORELAY_UPSTREAM_ERROR';
  return platorelayError(code, 'PlatoRelay: ' + detail + ' — ยังไม่ได้คีย์และไม่ได้เปิดโฆษณา');
}

async function platorelayRequestInPage(request) {
  const protocol = 'platorelay-session-v1';
  const fail = (code, message) => ({ protocol, code, message });
  const page = new URL(location.href);
  const ticket = page.searchParams.get('d') || page.pathname.split('/').filter(Boolean)[0];
  if (page.origin !== 'https://auth.platorelay.com' || ticket !== request.sourceTicket) {
    return fail('PLATORELAY_TAB_CHANGED', 'แท็บเปลี่ยนจากลิงก์ต้นทางแล้ว กรุณาเปิดลิงก์เดิมในเซสชันนี้');
  }
  if (!/^(?:status|metadata|step)\?/.test(request.path)) {
    return fail('PLATORELAY_INVALID_REQUEST', 'คำขอไม่อยู่ใน API ของต้นทางที่อนุญาต');
  }
  const signal = AbortSignal.timeout(Math.max(1, Math.min(9000, request.timeoutMs)));
  try {
    const response = await fetch('/api/session/' + request.path, {
      method: request.method || 'GET',
      headers: {
        Accept: 'application/json',
        'X-Client-Name': 'platoboost webclient',
        'X-Client-Version': '8.2.3',
        ...(request.body ? { 'Content-Type': 'application/json' } : {})
      },
      body: request.body || undefined,
      credentials: 'same-origin',
      redirect: 'error',
      cache: 'no-store',
      signal
    });
    const payload = await response.json();
    return { protocol, ok: response.ok, status: response.status, payload };
  } catch (error) {
    return fail(signal.aborted ? 'PLATORELAY_TIMEOUT' : 'PLATORELAY_BROWSER_REQUEST_FAILED',
      signal.aborted ? 'ครบเวลาที่กำหนด — ยังไม่ได้คีย์' : 'คำขอจากแท็บเดิมไม่สำเร็จ กรุณาลองใหม่อีกครั้งหรือตรวจสถานะใน Live View');
  }
}

async function platorelayRequest(path, context, options = {}) {
  context.signal.throwIfAborted();
  const timeoutMs = Math.max(1, context.deadline - Date.now());
  const expression = '(' + platorelayRequestInPage.toString() + ')(' + JSON.stringify({
    path, method: options.method || 'GET', body: options.body || null,
    sourceTicket: context.sourceTicket, timeoutMs
  }) + ')';
  const reply = await context.browser.evaluate(context.sessionId, expression, {
    tab_id: context.tabId, world: 'main', max_chars: 30000,
    timeoutMs, signal: context.signal
  });
  context.signal.throwIfAborted();
  if (!reply.ok) {
    throw platorelayError(reply.code === 'user_in_control' ? 'PLATORELAY_USER_IN_CONTROL' : 'PLATORELAY_BROWSER_ERROR',
      reply.code === 'user_in_control' ? 'กด Done, hand back ใน Live View แล้วลองอีกครั้ง — ใช้ session_id เดิม' : reply.message || 'รันโค้ดในแท็บเดิมไม่สำเร็จ');
  }
  const result = context.browser.evaluationValue(reply, 'platorelay-session-v1');
  if (!result) throw platorelayError('PLATORELAY_INVALID_RESPONSE', 'ไม่พบผลจาก JavaScript ในแท็บต้นทาง');
  if (result.code) throw platorelayError(result.code, result.message);
  const payload = result.payload;
  if (!result.ok) throw platorelayResponseError(payload && payload.message || 'HTTP ' + result.status, payload && payload.code);
  if (!payload || payload.success !== true) throw platorelayResponseError(payload && payload.message, payload && payload.code);
  if (!payload.data || typeof payload.data !== 'object' || Array.isArray(payload.data)) {
    throw platorelayError('PLATORELAY_INVALID_RESPONSE', 'PlatoRelay ไม่คืนข้อมูลเซสชันที่ใช้ได้');
  }
  return payload.data;
}

async function platorelayStatus(ticket, context) {
  const data = await platorelayRequest('status?ticket=' + encodeURIComponent(ticket), context);
  const key = typeof data.key === 'string' ? data.key.trim() : '';
  return key && !/^(?:KEY_NOT_FOUND|null|undefined)$/i.test(key) ? key : null;
}

async function platorelayStep(ticket, hash, metadata, context) {
  const service = metadata.activeRevenueProfile && metadata.activeRevenueProfile.service;
  if (!Number.isInteger(service) || service < 0 || service > 100) {
    throw platorelayError('PLATORELAY_UNSUPPORTED_PROFILE', 'ต้นทางไม่ระบุบริการ checkpoint ที่รองรับ — ไม่เปิดด่านโฆษณา');
  }
  if (metadata.enableEventTracker === true || metadata.activeTaskProfile) {
    throw platorelayError('PLATORELAY_ADDITIONAL_STEP_REQUIRED', 'ต้นทางมีขั้นตอนเพิ่มเติมที่ยังไม่รองรับ แต่ไม่ได้ระบุว่าต้องล็อกอิน — ยังไม่ได้คีย์');
  }
  const query = new URLSearchParams({ ticket, service: String(service) });
  if (hash) query.set('hash', hash);
  return platorelayRequest('step?' + query.toString(), context, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', Origin: PLATORELAY_ORIGIN },
    body: JSON.stringify({
      captcha: null,
      meta: platorelayBuildMeta(ticket),
      stream: platorelayCtrHex(JSON.stringify({ events: [] }), ticket.slice(1, 17), ticket.slice(17, 33)),
      resolved: true
    })
  });
}

// ---- status + metadata ในนัดเดียว: fetch ขนานในแท็บต้นทาง ลด round-trip ไป browser.lol ----
async function platorelayBatchInPage(input) {
  const page = new URL(location.href);
  const ticket = page.searchParams.get('d') || page.pathname.split('/').filter(Boolean)[0];
  if (page.origin !== 'https://auth.platorelay.com' || ticket !== input.sourceTicket) {
    return { protocol: 'platorelay-session-v1', code: 'PLATORELAY_TAB_CHANGED', message: 'แท็บเปลี่ยนจากลิงก์ต้นทางแล้ว กรุณาเปิดลิงก์เดิมในเซสชันนี้' };
  }
  const one = async (request) => {
    if (!/^(?:status|metadata|step)\?/.test(request.path)) {
      return { ok: false, code: 'PLATORELAY_INVALID_REQUEST', message: 'คำขอไม่อยู่ใน API ของต้นทางที่อนุญาต' };
    }
    const signal = AbortSignal.timeout(Math.max(1, Math.min(9000, request.timeoutMs)));
    try {
      const response = await fetch('/api/session/' + request.path, {
        method: request.method || 'GET',
        headers: { Accept: 'application/json', 'X-Client-Name': 'platoboost webclient', 'X-Client-Version': '8.2.3' },
        credentials: 'same-origin', redirect: 'error', cache: 'no-store', signal
      });
      const payload = await response.json();
      return { ok: response.ok, status: response.status, payload };
    } catch (error) {
      return {
        ok: false,
        code: signal.aborted ? 'PLATORELAY_TIMEOUT' : 'PLATORELAY_BROWSER_REQUEST_FAILED',
        message: signal.aborted ? 'ครบเวลาที่กำหนด — ยังไม่ได้คีย์' : 'คำขอจากแท็บเดิมไม่สำเร็จ กรุณาลองใหม่อีกครั้งหรือตรวจสถานะใน Live View'
      };
    }
  };
  const results = await Promise.all((input.requests || []).map(one));
  return { protocol: 'platorelay-session-v1', batch: true, results };
}

async function platorelayBatch(requests, context) {
  context.signal.throwIfAborted();
  const timeoutMs = Math.max(1, context.deadline - Date.now());
  const expression = '(' + platorelayBatchInPage.toString() + ')(' + JSON.stringify({
    requests: requests.map((r) => ({ path: r.path, method: r.method || 'GET', timeoutMs })),
    sourceTicket: context.sourceTicket
  }) + ')';
  const reply = await context.browser.evaluate(context.sessionId, expression, {
    tab_id: context.tabId, world: 'main', max_chars: 40000, timeoutMs, signal: context.signal
  });
  context.signal.throwIfAborted();
  if (!reply.ok) {
    throw platorelayError(reply.code === 'user_in_control' ? 'PLATORELAY_USER_IN_CONTROL' : 'PLATORELAY_BROWSER_ERROR',
      reply.code === 'user_in_control' ? 'กด Done, hand back ใน Live View แล้วลองอีกครั้ง — ใช้ session_id เดิม' : reply.message || 'รันโค้ดในแท็บเดิมไม่สำเร็จ');
  }
  const out = context.browser.evaluationValue(reply, 'platorelay-session-v1');
  if (!out) throw platorelayError('PLATORELAY_INVALID_RESPONSE', 'ไม่พบผลจาก JavaScript ในแท็บต้นทาง');
  if (out.code) throw platorelayError(out.code, out.message);
  if (!Array.isArray(out.results)) throw platorelayError('PLATORELAY_INVALID_RESPONSE', 'PlatoRelay ไม่คืนผลลัพธ์แบบ batch');
  return out.results;
}

function platorelayUnwrap(result) {
  if (!result) throw platorelayError('PLATORELAY_INVALID_RESPONSE', 'ไม่พบผลจากแท็บต้นทาง');
  if (result.code) throw platorelayError(result.code, result.message);
  const payload = result.payload;
  if (!result.ok) throw platorelayResponseError(payload && payload.message || 'HTTP ' + result.status, payload && payload.code);
  if (!payload || payload.success !== true) throw platorelayResponseError(payload && payload.message, payload && payload.code);
  if (!payload.data || typeof payload.data !== 'object' || Array.isArray(payload.data)) {
    throw platorelayError('PLATORELAY_INVALID_RESPONSE', 'PlatoRelay ไม่คืนข้อมูลเซสชันที่ใช้ได้');
  }
  return payload.data;
}

function platorelayKeyFrom(data) {
  const key = typeof data.key === 'string' ? data.key.trim() : '';
  return key && !/^(?:KEY_NOT_FOUND|null|undefined)$/i.test(key) ? key : null;
}

async function platorelayStatusAndMetadata(ticket, context) {
  const [statusRes, metaRes] = await platorelayBatch([
    { path: 'status?ticket=' + encodeURIComponent(ticket) },
    { path: 'metadata?ticket=' + encodeURIComponent(ticket) }
  ], context);
  const key = platorelayKeyFrom(platorelayUnwrap(statusRes));
  if (key) return { key, metadata: null };
  return { key: null, metadata: platorelayUnwrap(metaRes) };
}

// ถอดเฉพาะ URL ที่ฝังใน r โดยไม่ร้องขอหน้าเว็บของผู้ให้บริการโฆษณา
function platorelayResolveInner(rawUrl) {
  const seen = new Set();
  let current = rawUrl;
  for (let depth = 0; depth < 5; depth++) {
    if (typeof current !== 'string' || current.length > 16384 || seen.has(current)) return null;
    seen.add(current);
    if (platorelayExtractTicket(current)) return current;
    let parsed;
    try { parsed = new URL(current); } catch { return null; }
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.port) return null;
    if (!hostAllowed(parsed.hostname) && !hostIsLoot(parsed.hostname)) return null;
    if (parsed.searchParams.getAll('r').length !== 1) return null;
    const encoded = parsed.searchParams.get('r');
    current = /^https:\/\//i.test(encoded) ? encoded : decodeDynamic(parsed);
    if (!current) return null;
  }
  return null;
}

function platorelayExtractTicket(rawUrl) {
  try {
    if (typeof rawUrl !== 'string' || rawUrl.length > 10000) return null;
    const parsed = new URL(rawUrl);
    if (parsed.origin !== PLATORELAY_ORIGIN || parsed.username || parsed.password) return null;
    if (parsed.searchParams.getAll('d').length > 1 || parsed.searchParams.getAll('hash').length > 1) return null;
    const segments = parsed.pathname.split('/').filter(Boolean);
    let ticket;
    if (segments.length <= 1 && (!segments.length || segments[0] === 'a')) {
      ticket = parsed.searchParams.get('d');
    } else if (segments.length === 1 && !parsed.searchParams.has('d')) {
      ticket = segments[0];
    }
    const hash = parsed.searchParams.get('hash');
    if (!ticket || !/^[A-Za-z0-9_-]{32,4096}$/.test(ticket)) return null;
    if (hash && (hash.length > 2048 || /[\s\u0000-\u001f]/.test(hash))) return null;
    return { ticket, hash };
  } catch {
    return null;
  }
}

async function platorelayReadCompletedKey(ticket, referer, timeoutMs = 1400) {
  try {
    const response = await fetch(PLATORELAY_ORIGIN + '/api/session/status?ticket=' + encodeURIComponent(ticket), {
      headers: platorelayHeaders({ Origin: PLATORELAY_ORIGIN, Referer: referer || PLATORELAY_ORIGIN + '/' }),
      signal: AbortSignal.timeout(Math.max(250, Math.min(2500, timeoutMs)))
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload || payload.success !== true || !payload.data) return null;
    return platorelayKeyFrom(payload.data);
  } catch {
    return null;
  }
}

// ความล้มเหลวกลุ่มนี้คือด่านที่ต้องมีแท็บจริง (ล็อกบัญชี/CAPTCHA/ด่านโฆษณา) จึงคุ้มที่จะสลับไป Browser.LOL
const PLATORELAY_BROWSER_HELP_CODES = new Set([
  'PLATORELAY_ACCOUNT_UNLOCK_REQUIRED',
  'PLATORELAY_VERIFICATION_REQUIRED',
  'PLATORELAY_AD_STEP_REQUIRED',
  'PLATORELAY_CLIENT_REJECTED',
  'PLATORELAY_WAIT_REQUIRED',
  'PLATORELAY_KEY_NOT_READY',
  'PLATORELAY_CHECKPOINT_LIMIT',
  'PLATORELAY_NETWORK_ERROR',
  'PLATORELAY_UPSTREAM_ERROR'
]);

async function bypassPlatorelay(inputUrl, options = {}) {
  const start = Date.now();
  const budgetMs = Math.min(PLATORELAY_BUDGET_MS, Math.max(1000, Number(options.budgetMs) || 5000));
  const done = (extra) => ({
    input_url: inputUrl, elapsed_ms: Date.now() - start, budget_ms: budgetMs,
    no_ads: true, retry_with_browser: false, via: 'platorelay-api', ...extra
  });
  const okKey = (key, hop) => done({
    status: 'success', type: 'key', key, title: 'Delta Android Keysystem',
    via: hop ? `platorelay:api (${hop} checkpoint)` : 'platorelay:status',
    is_premium_only: false
  });
  let current = platorelayExtractTicket(inputUrl);
  if (!current) {
    return done({
      status: 'error', code: 'PLATORELAY_INVALID_URL',
      message: 'ใช้ลิงก์ HTTPS ของ auth.platorelay.com ที่มี ticket (?d=) ถูกต้อง'
    });
  }

  const helperUrl = String(options.helperUrl || process.env.PLATORELAY_HELPER_URL || '').trim();
  const browserAllowed = (helperUrl || options.helperSource) && options.browser !== false;

  const deadline = start + budgetMs;
  const req = async (path, method, body) => {
    const left = Math.max(500, deadline - Date.now());
    const response = await fetch(PLATORELAY_ORIGIN + '/api/session/' + path, {
      method: method || 'GET',
      headers: platorelayHeaders({
        Origin: PLATORELAY_ORIGIN,
        Referer: PLATORELAY_ORIGIN + '/?d=' + encodeURIComponent(current.ticket),
        ...(body ? { 'Content-Type': 'application/json' } : {})
      }),
      body: body || undefined,
      signal: AbortSignal.timeout(left)
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload || payload.success !== true || !payload.data) {
      throw platorelayResponseError((payload && payload.message) || ('HTTP ' + response.status), payload && payload.code);
    }
    return payload.data;
  };
  const keyOf = (d) => {
    const k = typeof d.key === 'string' ? d.key.trim() : '';
    return k && !/^(?:KEY_NOT_FOUND|null|undefined)$/i.test(k) ? k : null;
  };

  try {
    const seen = new Set();
    for (let hop = 0; hop < 5; hop++) {
      const ident = current.ticket + ':' + (current.hash || '');
      if (seen.has(ident)) throw platorelayError('PLATORELAY_LOOP', 'ต้นทางส่ง checkpoint เดิมซ้ำ');
      seen.add(ident);

      const [st, meta] = await Promise.all([
        req('status?ticket=' + encodeURIComponent(current.ticket)),
        req('metadata?ticket=' + encodeURIComponent(current.ticket))
      ]);
      const k0 = keyOf(st);
      if (k0) return okKey(k0, hop);

      const service = meta.activeRevenueProfile && meta.activeRevenueProfile.service;
      if (!Number.isInteger(service) || service < 0 || service > 100) {
        throw platorelayError('PLATORELAY_UNSUPPORTED_PROFILE', 'ต้นทางไม่ระบุบริการ checkpoint ที่รองรับ');
      }
      if (meta.enableEventTracker === true || meta.activeTaskProfile) {
        throw platorelayError('PLATORELAY_VERIFICATION_REQUIRED', 'ต้นทางต้องการกิจกรรมหรือการยืนยันเพิ่มเติม (CAPTCHA)');
      }

      const q = new URLSearchParams({ ticket: current.ticket, service: String(service) });
      if (current.hash) q.set('hash', current.hash);
      const step = await req('step?' + q.toString(), 'PUT', JSON.stringify({
        captcha: null,
        meta: platorelayBuildMeta(current.ticket),
        stream: platorelayCtrHex(JSON.stringify({ events: [] }), current.ticket.slice(1, 17), current.ticket.slice(17, 33)),
        resolved: true
      }));

      const ks = keyOf(step);
      if (ks) return okKey(ks, hop);
      if (!step.url) {
        const st2 = await req('status?ticket=' + encodeURIComponent(current.ticket));
        const k1 = keyOf(st2);
        if (k1) return okKey(k1, hop);
        throw platorelayError('PLATORELAY_KEY_NOT_READY', 'ต้นทางยังไม่ออกคีย์');
      }
      const nextUrl = platorelayResolveInner(step.url);
      if (!nextUrl) {
        const st2 = await req('status?ticket=' + encodeURIComponent(current.ticket));
        const k1 = keyOf(st2);
        if (k1) return okKey(k1, hop);
        throw platorelayError('PLATORELAY_AD_STEP_REQUIRED', 'ต้นทางส่งด่านโฆษณาที่ไม่มี checkpoint ฝังไว้');
      }
      current = platorelayExtractTicket(nextUrl);
    }
    const finalSt = await req('status?ticket=' + encodeURIComponent(current.ticket));
    const kf = keyOf(finalSt);
    if (kf) return okKey(kf, 5);
    throw platorelayError('PLATORELAY_CHECKPOINT_LIMIT', 'ครบจำนวน checkpoint ที่ตรวจได้ — ยังไม่ได้คีย์');
  } catch (error) {
    const code = (error && typeof error.code === 'string') ? error.code : 'PLATORELAY_NETWORK_ERROR';
    const message = (error && error.message) || 'ติดต่อ PlatoRelay ไม่สำเร็จ';
    // ด่านที่ API ตรงข้ามไม่ได้ (ล็อกบัญชี / CAPTCHA / ด่านโฆษณา) — ให้แท็บจริงใน Browser.LOL สานต่อ
    if (browserAllowed && PLATORELAY_BROWSER_HELP_CODES.has(code)) {
      const resumeUrl = current
        ? PLATORELAY_ORIGIN + '/a?d=' + encodeURIComponent(current.ticket) + (current.hash ? '&hash=' + encodeURIComponent(current.hash) : '')
        : inputUrl;
      try {
        const result = await require('./platorelay-browser').runPlatorelayBrowser(resumeUrl, {
          sessionId: options.reuseSession === true ? options.sessionId : '',
          helperUrl,
          helperSource: options.helperSource,
          timeoutMs: options.browserTimeoutMs || 12000,
          country: options.country
        });
        if (result && result.ok && typeof result.key === 'string' && result.key.trim()) {
          return done({
            status: 'success', type: 'key', key: result.key.trim(), title: 'Delta Android Keysystem',
            via: 'platorelay:browser-api', is_premium_only: false, session_id: result.session_id,
            browser_elapsed_ms: result.elapsed_ms
          });
        }
        return done({
          status: 'error',
          ...platorelayErrorDetails(result && result.code, result && result.message, code, message),
          session_id: result && result.session_id
        });
      } catch (browserError) {
        return done({
          status: 'error',
          ...platorelayErrorDetails(browserError && browserError.code, browserError && browserError.message, code, message)
        });
      }
    }
    return done({ status: 'error', code, message });
  }
}

// ============================================================================
// LootLabs / Loot-Link / AdMaven key-system solver
// ----------------------------------------------------------------------------
// พอร์ตมาจาก shadows_v2.py (ajyats/LootLabs_Bypass) มาเป็น Node ล้วน ๆ
// ขั้นตอนจริงของ LootLabs:
//   1) GET ลิงก์ -> ดึง document.session (UUID), p['CDN_DOMAIN'|'TID'|'KEY'] และ p[...] อื่น ๆ
//   2) GET https://{cdn}/?tid={tid}&params_only=1 -> ได้ websocket_domain / tc_domain
//   3) POST https://{tc_domain}/tc พร้อม "botd" (WebGL Proof-of-Work + AES-GCM) -> รายการ task
//   4) เปิด WebSocket wss://{shard}.{ws_domain}/c?... แล้วยิง beacon auto_complete
//      -> เซิร์ฟเวอร์จะส่งข้อความ "r:<payload>" กลับมา = ปลายทางจริง (ถอดด้วย XOR)
// ลิงก์ที่มี task "Confirm you are human" (task_id 41 = Cloudflare Turnstile)
// ต้องมี captcha solver (ตั้ง env CAPMONSTER_KEY หรือ TWOCAPTCHA_KEY) ถึงจะผ่าน
// ----------------------------------------------------------------------------

const LOOT_DOMAINS = [
  'lootlabs.gg', 'loot-link.com', 'loot-links.com', 'lootlinks.co', 'loot-link.net',
  'lootdest.com', 'lootdest.org', 'lootdest.info', 'loot-reward.com'
];
const hostIsLoot = (host) => LOOT_DOMAINS.some((d) => hostIn(host, d));
function isLootStyleUrl(rawOrUrl) {
  try {
    const u = rawOrUrl instanceof URL ? rawOrUrl : new URL(String(rawOrUrl));
    if (!/^https?:$/i.test(u.protocol) || u.username || u.password) return false;
    if (hostIsLoot(u.hostname)) return true;
    return /^\/s\/?$/.test(u.pathname) && /^\?[A-Za-z0-9_-]{2,16}&data=[A-Za-z0-9%+/_=-]{24,}/.test(u.search);
  } catch {
    return false;
  }
}
const LOOT_AD_HOSTS = ['unlockr.app', 'nerventualken.com', 'onsultingco.com', 'enaightdecipie.com'];

function isLootAdUrl(raw) {
  try {
    const u = new URL(raw);
    return LOOT_AD_HOSTS.some((host) => hostIn(u.hostname, host)) ||
      (u.searchParams.has('gsid') && u.searchParams.has('gsc'));
  } catch { return true; }
}

function lootDestination(raw, taskUrls = []) {
  if (typeof raw !== 'string' || !/^https?:\/\/\S+$/i.test(raw.trim())) return null;
  try {
    const u = new URL(raw.trim());
    if (u.username || u.password || isLootAdUrl(u.href) || hostIsLoot(u.hostname)) return null;
    const isTask = taskUrls.some((value) => {
      try {
        const task = new URL(value);
        return task.origin === u.origin && task.pathname === u.pathname;
      } catch { return false; }
    });
    return isTask ? null : u.href;
  } catch { return null; }
}

function lootPayloadDestination(encoded) {
  const text = b64urlToStr(encoded);
  const direct = lootDestination(text);
  if (direct) return direct;
  let value;
  try { value = JSON.parse(text); } catch { return null; }
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const taskUrls = [value.ad_url, value.adUrl, value.offer_url, value.offerUrl].filter(Boolean);
  for (const key of ['destination', 'destinationUrl', 'destination_url', 'targetUrl', 'target_url', 'url', 'link']) {
    const target = lootDestination(value[key], taskUrls);
    if (target) return target;
  }
  return null;
}

const LOOT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36';
const TURNSTILE_KEY = '0x4AAAAAAEO6tvECK-X4VCvq';
const LOOT_TIMEOUT_MS = parseInt(process.env.LOOT_TIMEOUT_MS || '2200', 10);
const lootParamsCache = new Map();
const CAPMONSTER_KEY = process.env.CAPMONSTER_KEY || '';
const TWOCAPTCHA_KEY = process.env.TWOCAPTCHA_KEY || process.env['2CAPTCHA_KEY'] || '';
// ws preserves the Origin/Cookie headers required by some gateways; native WebSocket is the fallback.
const LOOT_WS = (() => { try { return require('ws'); } catch { return globalThis.WebSocket || null; } })();

function b64urlToStr(raw) {
  try {
    let b = decodeURIComponent(raw).replace(/ /g, '+').replace(/-/g, '+').replace(/_/g, '/');
    while (b.length % 4) b += '=';
    return Buffer.from(b, 'base64').toString('utf8');
  } catch {
    return null;
  }
}
function firstUrlFrom(decoded) {
  if (!decoded) return null;
  const m = decoded.match(/https?:\/\/[^\s"'\\<>]+/i);
  return m ? m[0] : null;
}

// --- cookie jar แบบเบา ๆ ---
function lootJar() {
  const jar = {};
  return {
    store(res) {
      const sc = res.headers && res.headers.getSetCookie ? res.headers.getSetCookie() : [];
      for (const c of sc) { const m = c.match(/^([^=]+)=([^;]*)/); if (m) jar[m[1]] = m[2]; }
    },
    header() { return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; '); }
  };
}

// --- crypto helpers (พอร์ต 1:1 จาก shadows_v2.py) ---
function lootTransformUuid(uuid) {
  const ups = (uuid.match(/[A-Z]/g) || []).slice(0, 4);
  const keyStr = ups.length ? ups.join('') : 'KEY1';
  const u = Buffer.from(uuid, 'utf8'), k = Buffer.from(keyStr, 'utf8');
  const out = Buffer.alloc(u.length);
  for (let i = 0; i < u.length; i++) out[i] = u[i] ^ k[i % k.length];
  return out.toString('base64');
}
function lootFract(r6, n1) { const n = 43758.5453 * Math.sin(12.9898 * r6 + 78.233 * n1); return n - Math.floor(n); }
function lootSolveNonce(uuid) {
  const y6 = parseInt(uuid.replace(/-/g, '').slice(0, 8), 16) / 4294967295.0;
  for (let nonce = 0; nonce < 100000; nonce++) {
    let o = lootFract(y6, nonce); o = lootFract(o, nonce + 1); o = lootFract(o, nonce + 2);
    if (o < 0.001) return nonce;
  }
  return 99999;
}
function lootMakeBotd(uuid) {
  const nonce = lootSolveNonce(uuid);
  const solveTime = Math.floor(nonce * (1.15 + Math.random() * 0.25) + (20 + Math.floor(Math.random() * 61)));
  const botd = { bot: false, timestamp: Date.now(), webGLSolution: { uuid, nonce, time: solveTime } };
  const aesKey = crypto.createHash('sha256').update(lootTransformUuid(uuid), 'utf8').digest();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', aesKey, iv);
  const ct = Buffer.concat([cipher.update(Buffer.from(JSON.stringify(botd), 'utf8')), cipher.final()]);
  botd.encrypted = Buffer.concat([iv, ct, cipher.getAuthTag()]).toString('base64');
  return JSON.stringify(botd);
}
function lootDecryptData(encoded, keyLen = 5) {
  try {
    const raw = Buffer.from(encoded, 'base64');
    const key = raw.subarray(0, keyLen), blob = raw.subarray(keyLen);
    const out = Buffer.alloc(blob.length);
    for (let i = 0; i < blob.length; i++) out[i] = blob[i] ^ key[i % keyLen];
    return out.toString('utf8').trim();
  } catch { return String(encoded).trim(); }
}
function lootParseR(message) {
  if (typeof message !== 'string' || !message.startsWith('r:')) return null;
  let p = '';
  for (const ch of message.slice(2).trim()) { const c = ch.charCodeAt(0); if (c >= 32 && c <= 126) p += ch; }
  if (p.startsWith('http://') || p.startsWith('https://')) return p;
  return lootDecryptData(p);
}

// --- html / params extraction ---
function lootCdnTid(html) {
  return {
    cdn: (html.match(/p\['CDN_DOMAIN'\]\s*=\s*'([^']*)'/) || [])[1],
    tid: (html.match(/p\['TID'\]\s*=\s*(\d+)/) || [])[1],
    key: (html.match(/p\['KEY'\]\s*=\s*"([^"]*)"/) || [])[1]
  };
}
function lootPVars(html) {
  const pv = {}; const re = /p\['(\w+)'\]\s*=\s*([^\n;]+)/g; let m;
  while ((m = re.exec(html))) {
    let v = m[2].trim().replace(/;+$/, '').trim();
    if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) v = v.slice(1, -1);
    pv[m[1]] = v;
  }
  return pv;
}
function lootParams(text) {
  text = (text || '').trim();
  let data;
  try { data = JSON.parse('[' + text.slice(1, -2) + ']'); }
  catch { data = JSON.parse('[' + text.replace(/;+$/, '').slice(1, -1) + ']'); }
  return {
    websocket_domain: data[9], websocket_backup: data[10], websocket_bckup2: data[11],
    tc_domain: data[29], allow_unlocker: data[30]
  };
}
const lootBool = (v, d = true) => v == null ? d : typeof v === 'boolean' ? v : typeof v === 'string' ? ['1', 'true'].includes(v.toLowerCase()) : !!v;
const lootRnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;

// --- Turnstile solver (optional, ต้องตั้ง env key) ---
async function lootSolveTurnstile(pageUrl, cdata, action, keys) {
  const capKey = (keys && String(keys.capmonster || '').trim()) || CAPMONSTER_KEY;
  const twoKey = (keys && String(keys.twocaptcha || '').trim()) || TWOCAPTCHA_KEY;
  if (capKey) {
    const task = { type: 'TurnstileTask', websiteURL: pageUrl, websiteKey: TURNSTILE_KEY };
    if (cdata) task.data = cdata;
    if (action) task.pageAction = action;
    const c = await (await fetch('https://api.capmonster.cloud/createTask', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clientKey: capKey, task })
    })).json();
    if (c.errorId !== 0) throw new Error(c.errorCode || 'capmonster createTask');
    for (let i = 0; i < 60; i++) {
      await new Promise((r) => setTimeout(r, 400));
      const g = await (await fetch('https://api.capmonster.cloud/getTaskResult', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clientKey: capKey, taskId: c.taskId })
      })).json();
      if (g.errorId !== 0) throw new Error(g.errorCode || 'capmonster result');
      if (g.status === 'ready') return g.solution.token;
    }
    throw new Error('capmonster timeout');
  }
  if (twoKey) {
    const qs = new URLSearchParams({ key: twoKey, method: 'turnstile', sitekey: TURNSTILE_KEY, pageurl: pageUrl, json: '1' });
    if (cdata) qs.set('data', cdata);
    if (action) qs.set('action', action);
    const inp = await (await fetch('https://2captcha.com/in.php?' + qs.toString())).json();
    if (inp.status !== 1) throw new Error('2captcha in: ' + inp.request);
    for (let i = 0; i < 60; i++) {
      await new Promise((r) => setTimeout(r, 1000));
      const out = await (await fetch(`https://2captcha.com/res.php?key=${twoKey}&action=get&id=${inp.request}&json=1`)).json();
      if (out.status === 1) return out.request;
      if (out.request !== 'CAPCHA_NOT_READY') throw new Error('2captcha res: ' + out.request);
    }
    throw new Error('2captcha timeout');
  }
  throw new Error('no captcha solver key');
}

// ใช้ Turnstile ของงานจริงในแท็บแยก แล้ว verify ด้วย cookie ของเซสชันต้นทาง
async function lootBrowserTurnstile(capUrl, urid, taskId, tid, pageOrigin, pageCookie, sessionId, budgetMs) {
  const browser = require('./browserlol');
  const sid = browser.validateSessionId(String(sessionId || browser.defaultSessionId()));
  const started = Date.now();
  let raceTabId = null;

  const cdp = (method, params, tabId, timeoutMs = 5000) => browser.mcpRequest('tools/call', {
    name: 'browser_cdp',
    arguments: {
      session_id: sid,
      ...(tabId ? { tab_id: tabId } : { target: 'browser' }),
      method,
      params,
      max_chars: 2000
    }
  }, { timeoutMs });

  try {
    const created = await cdp('Target.createTarget', { url: capUrl });
    const targetId = String(created.data?.data?.targetId || created.data?.targetId || '');
    raceTabId = targetId ? 't' + targetId.slice(0, 6).toLowerCase() : null;
    if (!raceTabId) throw new Error('เปิดแท็บ CAPTCHA ไม่สำเร็จ');

    const source = `(() => {
      const race = window.__lootRace = { started: Date.now(), tokens: [], submitted: 0, completed: 0, errors: [] };
      try {
        const original = document.querySelector('.cf-turnstile');
        original.innerHTML = '';
        const widgetId = window.turnstile.render(original, {
          sitekey: original.dataset.sitekey,
          theme: 'dark',
          action: original.dataset.action,
          cdata: original.dataset.cdata,
          execution: 'execute',
          retry: 'never',
          'refresh-expired': 'never',
          callback: (token) => {
            window.TOKEN = token;
            race.submitted = Date.now();
            race.tokens.push({ at: Date.now(), length: token.length });
          },
          'error-callback': (code) => race.errors.push(String(code))
        });
        race.widgetId = widgetId;
        window.turnstile.execute(widgetId);
        race.executed = Date.now();
      } catch (error) { race.errors.push(String(error)); }
    })();`;

    let installed = null;
    for (let attempt = 0; attempt < 4; attempt++) {
      installed = await browser.evaluate(sid, `(async () => {
        for (let i = 0; i < 60 && (!document.querySelector('.cf-turnstile') || !window.turnstile || typeof window.turnstile.render !== 'function'); i++) await new Promise((resolve) => setTimeout(resolve, 50));
        ${source}
        return true;
      })()`, { tab_id: raceTabId, max_chars: 2000, timeoutMs: 5000 });
      if (installed.ok) break;
      await sleep(150);
    }
    if (!installed || !installed.ok) throw new Error('ติดตั้ง Turnstile controller ไม่สำเร็จ');

    const waitMs = Math.max(1000, Math.min(24000, (budgetMs || 15000) - (Date.now() - started) + 1000));
    const waited = await browser.evaluate(sid, `(async () => {
      for (let i = 0; i < 220; i++) {
        if (window.TOKEN) return JSON.stringify({ token: window.TOKEN });
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      return JSON.stringify({ token: null });
    })()`, { tab_id: raceTabId, max_chars: 3000, timeoutMs: waitMs });
    const waitValue = browser.evaluationValue(waited);
    if (!waitValue || !waitValue.token) throw new Error('Turnstile ไม่คืน token ภายในเวลาที่กำหนด');

    const syncer = new URL(capUrl).host;
    const verify = await fetch('https://' + syncer + '/captcha/verify', {
      method: 'POST',
      headers: {
        'User-Agent': LOOT_UA,
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json',
        Origin: 'https://' + syncer,
        Referer: capUrl,
        Cookie: pageCookie
      },
      body: JSON.stringify({ urid: String(urid), token: waitValue.token }),
      signal: AbortSignal.timeout(5000)
    });
    if (!verify.ok) throw new Error('CAPTCHA verify HTTP ' + verify.status);
    await verify.text();

    const headers = {
      'User-Agent': LOOT_UA,
      'Accept-Language': 'en-US,en;q=0.9',
      Origin: pageOrigin,
      Referer: pageOrigin + '/',
      Cookie: pageCookie
    };
    for (const ac of ['captcha', 'auto_complete']) {
      const completeUrl = 'https://' + syncer + '/td?ac=' + ac + '&urid=' + encodeURIComponent(String(urid)) + '&=&cat=' + encodeURIComponent(String(taskId)) + '&tid=' + encodeURIComponent(String(tid));
      const response = await fetch(completeUrl, { headers, signal: AbortSignal.timeout(5000) });
      await response.text();
    }
  } finally {
    if (raceTabId) {
      await browser.callTool('browser_tabs', { session_id: sid, action: 'close', tab_id: raceTabId }, { timeoutMs: 2000, tries: 1 }).catch(() => {});
    }
  }
}

// --- ตัว solver หลัก: คืน destination (string) หรือ null ---
async function lootSolveKeySystem(url, budgetMs, opts = {}) {
  const t0 = Date.now();
  const host = new URL(url).hostname;
  const origin = `https://${host}`;
  const jar = lootJar();
  const base = { 'User-Agent': LOOT_UA, 'Accept-Language': 'en-US,en;q=0.9', Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' };

  const initial = await fetch(url, { headers: { ...base, Origin: origin, Referer: origin }, redirect: 'follow', signal: AbortSignal.timeout(TIMEOUT_MS) });
  jar.store(initial);
  const html = await initial.text();

  const sess = (html.match(/document\.session\s*=\s*'([^']+)'/) || [])[1];
  if (!sess) return { err: 'session_not_found' };

  fetch(`${origin}/verify`, {
    method: 'POST',
    headers: { ...base, 'Content-Type': 'text/plain;charset=UTF-8', Origin: origin, Cookie: jar.header() },
    body: JSON.stringify({ session: sess }),
    signal: AbortSignal.timeout(TIMEOUT_MS)
  }).catch(() => {});

  const { cdn, tid, key } = lootCdnTid(html);
  if (!cdn || !tid || !key) return { err: 'cdn_tid_key_not_found' };
  const pvars = lootPVars(html);

  let params;
  const cacheKey = cdn + ':' + tid;
  const cached = lootParamsCache.get(cacheKey);
  if (cached && cached.exp > Date.now()) {
    params = cached.val;
  } else {
    try {
      const cResp = await fetch(`https://${cdn}/?tid=${tid}&params_only=1`, { headers: { ...base, Origin: origin, Referer: origin + '/', Cookie: jar.header() }, signal: AbortSignal.timeout(2500) });
      params = lootParams(await cResp.text());
      lootParamsCache.set(cacheKey, { val: params, exp: Date.now() + 600000 });
    } catch { return { err: 'params_parse_failed' }; }
  }

  const messSession = String(lootRnd(1, 9)) + Array.from({ length: 16 }, () => lootRnd(0, 9)).join('') + String(lootRnd(0, 9));
  const TCData = {
    tid: parseInt(tid), bl: [18, 2, 33, 7, 21, 49], session: messSession, max_tasks: 1, design_id: 135,
    cur_url: url, doc_ref: '', tier_id: '0', num_of_tasks: '1', is_loot: true, rkey: key,
    cookie_id: String(lootRnd(100000000, 999999999)), botd: lootMakeBotd(sess), botds: sess,
    offer: pvars.OFFER || '0', ver: pvars.WIDGET_VERSION || 'v1', tasks_timer: pvars.TASKS_TIMER || '-1',
    test_unlocker_app: parseInt(pvars.TEST_UNLOCKER_APP ?? '-1') || -1,
    allow_unlocker: lootBool(params.allow_unlocker, true), show_unlocker: lootBool(pvars.SHOW_UNLOCKER, true),
    desktop_design: ['1', 'true'].includes(pvars.DESKTOP_DESIGN) ? 1 : 0,
    unlocker_only: parseInt(pvars.UNLOCKER_ONLY || '0') || 0, additional_info: {}, taboola_user_sync: '0'
  };

  const SYNCER = params.tc_domain || 'nerventualken.com';
  const tcResp = await fetch(`https://${SYNCER}/tc`, {
    method: 'POST',
    headers: { 'User-Agent': LOOT_UA, Accept: '*/*', 'Accept-Language': 'en-US,en;q=0.9', 'Content-Type': 'application/json', Origin: origin, Referer: origin + '/' },
    body: JSON.stringify(TCData),
    signal: AbortSignal.timeout(TIMEOUT_MS)
  });
  if (tcResp.status !== 200) return { err: 'tc_status_' + tcResp.status };
  const TCP = await tcResp.json();
  const list = (Array.isArray(TCP) ? TCP : [TCP]).filter((item) => item && typeof item === 'object');
  if (!list.length) return { err: 'tc_empty' };
  const taskUrls = list.flatMap((item) => [item.ad_url, item.adUrl, item.offer_url, item.click_url, item.action_pixel_url]).filter(Boolean);

  const captcha = list.find((i) => i.title === 'Confirm you are human' || String(i.task_id) === '41') || null;
  const wsDomain = params.websocket_domain || 'onsultingco.com';
  const browser = require('./browserlol');
  const browserSessionId = String(opts.sessionId || '').trim() || browser.defaultSessionId();
  const capKey = String((opts && opts.capmonsterKey) || '').trim() || CAPMONSTER_KEY;
  const twoKey = String((opts && opts.twocaptchaKey) || '').trim() || TWOCAPTCHA_KEY;
  const hasSolver = !!(capKey || twoKey || browserSessionId);
  if (!LOOT_WS) return { err: 'no_websocket_runtime' };

  const taskAbort = new AbortController();
  // task_clicked beacons
  list.forEach((item, idx) => fetch(`https://enaightdecipie.com/?event=task_clicked&session_id=${item.task_id}&info=${idx + 1}`, { headers: { 'User-Agent': LOOT_UA }, signal: taskAbort.signal }).catch(() => {}));

  // เปิด WS + auto_complete ให้ทุก task, อันไหนได้ r: ก่อนชนะ
  let remaining = Math.max(400, (budgetMs || LOOT_TIMEOUT_MS) - (Date.now() - t0));
  // ไม่มี solver อัตโนมัติ แต่ลิงก์มีด่าน captcha -> ถ้างงานเดียวคือ captcha คืนทันทีไม่ต้องรอ; ถ้ามีงานอื่นด้วยรอสั้น ๆ พอ (1.2 วิ)
  if (captcha && !hasSolver) {
    return { err: 'captcha_required' };
  }
  const dest = await new Promise((resolve) => {
    let settled = false;
    const sockets = [];
    const pings = new Set();
    const finish = (value) => {
      if (settled) return;
      settled = true;
      clearTimeout(deadline);
      taskAbort.abort();
      for (const ping of pings) clearInterval(ping);
      for (const socket of sockets) {
        try { typeof socket.terminate === 'function' ? socket.terminate() : socket.close(); } catch {}
      }
      resolve(value);
    };
    const deadline = setTimeout(() => finish(null), remaining);

    for (const bind of (captcha ? [captcha] : list)) {
      const urid = bind.urid, taskId = bind.task_id ?? 0;
      if (!urid) continue;
      const wsSession = bind.session_id || 'undefined';
      let shard = 0; try { shard = parseInt(String(urid).slice(-5)) % 3; } catch {}
      const wsUrl = `wss://${shard}.${wsDomain}/c?uid=${urid}&cat=${taskId}&key=${key}&session_id=${wsSession}&is_loot=1&tid=${tid}`;
      let ws;
      try {
        // WHATWG WebSocket accepts protocols, not the ws package's headers option.
        ws = LOOT_WS === globalThis.WebSocket
          ? new LOOT_WS(wsUrl)
          : new LOOT_WS(wsUrl, { headers: { 'User-Agent': LOOT_UA, Origin: origin, Cookie: jar.header() } });
      } catch { continue; }
      sockets.push(ws);
      let ping;
      const onOpen = () => {
        if (settled) { try { ws.close(); } catch {} return; }
        ping = setInterval(() => { try { ws.send('0'); } catch {} }, 10000);
        pings.add(ping);
        if (ping.unref) ping.unref();
        fetch(`https://${shard}.${wsDomain}/st?uid=${urid}&cat=${taskId}`, { method: 'POST', headers: { 'User-Agent': LOOT_UA, 'Content-Type': 'text/plain;charset=UTF-8' }, body: '', signal: taskAbort.signal }).catch(() => {});
        if (bind.action_pixel_url) fetch(bind.action_pixel_url, { headers: { 'User-Agent': LOOT_UA }, signal: taskAbort.signal }).catch(() => {});
        fetch(`https://${SYNCER}/td?ac=auto_complete&urid=${urid}&cat=${taskId}&tid=${tid}`, { headers: { 'User-Agent': LOOT_UA }, signal: taskAbort.signal }).catch(() => {});
        // ถ้าเป็น task captcha ให้ใช้ solver ที่ตั้งค่าไว้ หรือ Turnstile execute ใน Browser.LOL
        if (bind === captcha && hasSolver) {
          (async () => {
            try {
              const capUrl = bind.ad_url && String(bind.ad_url).startsWith('http') ? bind.ad_url : `https://${SYNCER}/captcha?urid=${urid}`;
              if (capKey || twoKey) {
                let capHtml = '';
                try { capHtml = await (await fetch(capUrl, { headers: { 'User-Agent': LOOT_UA, Referer: origin + '/' } })).text(); } catch {}
                const cdata = (capHtml.match(/data-cdata="([^"]*)"/) || [])[1] || null;
                const action = (capHtml.match(/data-action="([^"]*)"/) || [])[1] || null;
                const token = await lootSolveTurnstile(capUrl, cdata, action, { capmonster: capKey, twocaptcha: twoKey });
                await fetch(`https://${SYNCER}/captcha/verify`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', Origin: `https://${SYNCER}`, Referer: capUrl },
                  body: JSON.stringify({ urid: String(urid), token })
                }).catch(() => {});
                fetch(`https://${SYNCER}/td?ac=captcha&urid=${urid}&=&cat=${taskId}&tid=${tid}`, { headers: { 'User-Agent': LOOT_UA } }).catch(() => {});
              } else {
                await lootBrowserTurnstile(
                  capUrl, urid, taskId, tid, origin, jar.header(), browserSessionId,
                  Math.max(1000, (budgetMs || 15000) - (Date.now() - t0))
                );
              }
            } catch {}
          })();
        }
      };
      const onMsg = (data) => {
        let msg = data;
        if (msg instanceof Buffer || msg instanceof ArrayBuffer) { try { msg = Buffer.from(msg).toString('utf8'); } catch { return; } }
        msg = String(msg);
        if (msg === 'Refresh Page') return;
        const r = lootDestination(lootParseR(msg), taskUrls);
        if (r) { clearTimeout(deadline); clearInterval(ping); finish(r); }
      };
      // รองรับทั้ง WHATWG WebSocket (addEventListener) และ ws (.on)
      if (ws.addEventListener) {
        ws.addEventListener('open', onOpen);
        ws.addEventListener('message', (ev) => onMsg(ev.data));
        ws.addEventListener('error', () => {});
        ws.addEventListener('close', () => clearInterval(ping));
      } else {
        ws.on('open', onOpen);
        ws.on('message', onMsg);
        ws.on('error', () => {});
        ws.on('close', () => clearInterval(ping));
      }
    }
  });

  if (dest) return { dest };
  if (captcha && !hasSolver) return { err: 'captcha_required' };
  return { err: 'no_result' };
}

const lootDestinationCache = new Map();
const LOOT_DESTINATION_CACHE_MS = 60000;

function lootDestinationCacheKey(inputUrl, opts) {
  const sessionId = String((opts && opts.sessionId) || '').trim();
  return sessionId ? sessionId + '|' + inputUrl : '';
}

function readLootDestinationCache(key) {
  if (!key) return null;
  const entry = lootDestinationCache.get(key);
  if (!entry) return null;
  if (entry.expires <= Date.now()) {
    lootDestinationCache.delete(key);
    return null;
  }
  return entry.destination;
}

function writeLootDestinationCache(key, destination) {
  if (!key || !destination) return;
  if (lootDestinationCache.size >= 128) lootDestinationCache.delete(lootDestinationCache.keys().next().value);
  lootDestinationCache.set(key, { destination, expires: Date.now() + LOOT_DESTINATION_CACHE_MS });
}

async function lootResolveDestination(destination, opts, inputUrl, started, via) {
  let hostname;
  try { hostname = new URL(destination).hostname; } catch { return null; }
  let inner = null;
  try {
    if (isPlatorelayHost(hostname)) {
      inner = await bypassPlatorelay(destination, {
        sessionId: opts.sessionId,
        reuseSession: true,
        helperUrl: opts.helperUrl,
        browserTimeoutMs: opts.platorelayBrowserTimeoutMs || 22000,
        budgetMs: opts.platorelayBudgetMs || 5000,
        country: opts.country
      });
    } else if (hostIn(hostname, 'linkvertise.com') || ALLOWED.some((domain) => hostIn(hostname, domain))) {
      inner = await bypass(destination, opts);
    }
  } catch {}
  if (!inner || inner.status !== 'success') return null;
  return {
    ...inner,
    input_url: inputUrl,
    via: via + ' → ' + (inner.via || 'destination'),
    elapsed_ms: Date.now() - started
  };
}

async function bypassLootlabs(inputUrl, opts = {}) {
  const start = Date.now();
  const done = (extra) => ({ input_url: inputUrl, elapsed_ms: Date.now() - start, ...extra });
  let u;
  try { u = new URL(inputUrl); } catch { return done({ status: 'error', message: 'URL ไม่ถูกต้อง' }); }
  if (!/^https?:$/.test(u.protocol) || !isLootStyleUrl(u) || u.username || u.password) {
    return done({ status: 'error', message: 'ต้องเป็นลิงก์ HTTP/HTTPS ของ LootLabs' });
  }

  const cacheKey = lootDestinationCacheKey(inputUrl, opts);
  const finishDestination = async (destination, via, extra = {}) => {
    writeLootDestinationCache(cacheKey, destination);
    const resolved = await lootResolveDestination(destination, opts, inputUrl, start, via);
    if (resolved) return resolved;
    return done({ status: 'success', type: 'link', destination, title: null, is_premium_only: false, via, ...extra });
  };

  const cachedDestination = readLootDestinationCache(cacheKey);
  if (cachedDestination) return finishDestination(cachedDestination, 'lootlabs-cache');

  // Fast path 1: loot-reward.com ?cc= = base64(JSON ที่มีลิงก์ไฟล์) ถอดได้ตรง ๆ
  const cc = u.searchParams.get('cc');
  if (cc) {
    const dest = lootPayloadDestination(cc);
    if (dest) return finishDestination(dest, 'lootlabs-payload');
  }
  // Fast path 2: เผื่อเจ้าของลิงก์ไม่ได้เปิด encryption จริง -> ปลายทางโผล่ใน data ตรง ๆ
  const data = u.searchParams.get('data');
  if (data) {
    const dest = lootPayloadDestination(data);
    if (dest) return finishDestination(dest, 'lootlabs-payload');
  }

  let directError = null;
  try {
    const direct = await lootSolveKeySystem(u.href, (opts && opts.budgetMs) || 18000, { sessionId: opts && opts.sessionId, capmonsterKey: opts && opts.capmonsterKey, twocaptchaKey: opts && opts.twocaptchaKey });
    if (direct && direct.dest) return finishDestination(direct.dest, 'lootlabs-direct-execute');
    directError = direct && direct.err;
  } catch (error) {
    directError = (error && error.message) || String(error);
  }

  // ทางเดิมเป็นสำรองสำหรับลิงก์ชนิดอื่นหรือกรณี direct protocol ไม่สำเร็จ
  try {
    const browser = require('./browserlol');
    const { solveInBrowser } = require('./lootlabs-live');
    const out = await solveInBrowser(browser, inputUrl, {
      sessionId: opts && opts.sessionId,
      budgetMs: Math.max(3000, 27000 - (Date.now() - start))
    });
    if (out && out.status === 'success' && out.type === 'link' && out.destination) {
      return finishDestination(out.destination, 'lootlabs-browser', { direct_error: directError });
    }
    return { ...out, input_url: inputUrl, direct_error: directError, elapsed_ms: Date.now() - start };
  } catch (err) {
    return done({ status: 'error', via: 'lootlabs-browser', direct_error: directError, message: 'บายพาส LootLabs ล้มเหลว: ' + (err && err.message ? err.message : String(err)) });
  }
}

// ============================================================================
// Social-unlock lockers (กดติดตาม/subscribe แล้วค่อยปล่อยลิงก์)
// rekonise / mboost / bst.gg / booo.st / boost.ink / social-unlock / socialwolvez
// sub2get / sub2unlock (.com .net .io .me .id) / sub4unlock (.io .com)
// subfinal / unlocknow / ytsubme
// ----------------------------------------------------------------------------
// ทุกเจ้าหลักการเดียวกัน: ปลายทางถูกฝังไว้ในหน้าหรืออยู่หลัง API ของตัวเอง
// โค้ดชุดนี้ไล่เป็นชั้น ๆ
//   1) API ของเว็บนั้นตรง ๆ (rekonise, sub2unlock.com, ytsubme) — เร็วและแม่นสุด
//   2) ดูด HTML มาขุดจากจุดที่ฝังไว้: anchor ที่ซ่อน, base64 ใน attribute (boost.ink),
//      __NEXT_DATA__, flight stream ของ Next (socialwolvez/social-unlock),
//      textarea JSON (sub2unlock.id), js redirect, meta refresh
//   3) ฟอร์มแบบ CakePHP (_csrfToken + ad_form_data) -> POST /links/go แบบรอให้ครบเวลา
//   4) สุดท้ายจริง ๆ ค่อยกวาดลิงก์ในหน้าแบบเดา (ติดธง via=loose_scan ไว้ให้รู้)
// ============================================================================

const SOCIAL_DOMAINS = [
  'link-unlock.com',
  'rekonise.com', 'rkns.link',
  'mboost.me', 'boost.ink', 'bst.gg', 'bst.wtf', 'booo.st',
  'social-unlock.com', 'socialwolvez.com', 'scwz.me',
  'sub2get.com', 'sub2unlock.com', 'sub2unlock.net', 'sub2unlock.io', 'sub2unlock.me', 'sub2unlock.id',
  'sub4unlock.io', 'sub4unlock.com', 'subfinal.com', 'unlocknow.net', 'ytsubme.com'
];
const hostIsSocial = (host) => SOCIAL_DOMAINS.some((d) => hostIn(host, d));

const SOCIAL_BUDGET_MS = parseInt(process.env.SOCIAL_BUDGET_MS || '4500', 10);
const SOCIAL_FETCH_MS = parseInt(process.env.SOCIAL_FETCH_MS || '3000', 10);

// โดเมนโครงสร้างพื้นฐานที่โผล่ในทุกหน้า ไม่มีทางเป็นปลายทาง
const SOCIAL_INFRA = [
  'schema.org', 'w3.org', 'ogp.me', 'purl.org', 'xmlns.com', 'creativecommons.org', 'gmpg.org', 'wordpress.org',
  'googleapis.com', 'gstatic.com', 'googletagmanager.com', 'google-analytics.com',
  'googlesyndication.com', 'doubleclick.net', 'adservice.google.com', 'www.google.com', 'ezoic.net', 'ezoic.com',
  'jsdelivr.net', 'unpkg.com', 'cdnjs.com', 'cloudflare.com', 'cloudflareinsights.com', 'jquery.com',
  'bootstrapcdn.com', 'fontawesome.com', 'polyfill.io', 'gravatar.com', 'sentry.io', 'recaptcha.net',
  'hcaptcha.com', 'nr-data.net', 'newrelic.com', 'hotjar.com', 'clarity.ms',
  // third-party widget/SaaS ที่ฝังในหน้า แต่ "ไม��เคยเป็นปลายทาง" — กันหยิบ worker/บู๊ตสแตรป SDK
  // มาเป็นผลลัพธ์ (เช่น Chargebee โหลด .../v2/pi-worker.js, Stripe โหลด m.stripe.network ฯลฯ)
  'chargebee.com', 'stripe.com', 'stripe.network', 'paypal.com', 'paypalobjects.com',
  'braintreegateway.com', 'braintree-api.com', 'adyen.com', 'recurly.com', 'paddle.com', 'paddle.net',
  'intercom.io', 'intercomcdn.com', 'crisp.chat', 'tawk.to', 'drift.com', 'zendesk.com', 'zdassets.com',
  'livechatinc.com', 'tidio.co', 'hubspot.com', 'hs-scripts.com', 'hsforms.com', 'hsforms.net',
  'cookiebot.com', 'onetrust.com', 'cookielaw.org', 'usercentrics.eu', 'iubenda.com', 'termly.io',
  'quantcast.com', 'consensu.org', 'segment.com', 'segment.io', 'fullstory.com', 'mixpanel.com',
  'amplitude.com', 'heap.io', 'mouseflow.com', 'crazyegg.com', 'optimizely.com', 'datadoghq.com',
  'bugsnag.com', 'connect.facebook.net', 'facebook.net', 'typekit.net'
];
// อีกชั้นสำหรับโหมดเดาเท่านั้น — ปุ่ม follow/subscribe ของเว็บล็อกเกอร์ชี้ไปพวกนี้
const SOCIAL_PLATFORMS = [
  'facebook.com', 'fb.com', 'twitter.com', 'x.com', 'instagram.com', 'tiktok.com', 'youtube.com', 'youtu.be',
  'linkedin.com', 'pinterest.com', 'reddit.com', 'twitch.tv', 'telegram.me', 't.me', 'patreon.com', 'spotify.com'
];
// เว็บล็อกเกอร์เจ้าอื่นที่เรายังไม่รองรับ — ในโหมดเดาถือว่าไม่ใช่ปลายทาง
const SOCIAL_OTHER_LOCKERS = [
  'link2unlock.com', 'linkunlocker.com', 'lockr.net', 'boostylink.com', 'subforunlock.com',
  'bstshrt.com', 'bstlar.com', 'risub.com', 'linksterra.com', 'linkzy.space', 'work.ink', 'adfoc.us', 'boost.fusedgt.com'
];
const SOCIAL_ASSET_EXT = /\.(?:js|mjs|css|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|eot|map|json|xml|txt)(?:[?#]|$)/i;

function socialUnescape(s) {
  return String(s)
    .replace(/\\u002[fF]/g, '/')
    .replace(/\\u0026/g, '&')
    .replace(/\\u003[dD]/g, '=')
    .replace(/\\u003[fF]/g, '?')
    .replace(/\\\//g, '/')
    .replace(/\\"/g, '"')
    .replace(/\\'/g, "'");
}
function socialDecodeEntities(s) {
  return String(s)
    .replace(/&quot;/g, '"').replace(/&#0?34;/g, '"')
    .replace(/&#0?39;/g, "'").replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&#x2F;/gi, '/').replace(/&amp;/g, '&');
}
function socialCleanUrl(raw) {
  if (raw == null) return null;
  let s = socialDecodeEntities(socialUnescape(String(raw))).trim().replace(/^["'\s]+/, '');
  let prev;
  do { prev = s; s = s.replace(/["'\s\\<>)\]}]+$/, '').replace(/[.,;]+$/, ''); } while (s !== prev);
  if (!/^https?:\/\//i.test(s)) return null;
  try {
    const u = new URL(s);
    if (!u.hostname.includes('.')) return null;
    return u.href;
  } catch {
    return null;
  }
}
const socialHostOf = (url) => { try { return new URL(url).hostname; } catch { return ''; } };
const socialIsInfra = (url) => { const h = socialHostOf(url); return !h || SOCIAL_INFRA.some((d) => hostIn(h, d)); };
// static asset / worker / SDK bootstrap (.js/.css/.map/รูป/ฟอนต์ ฯลฯ) — ไม่ใช่ปลายทางแน่ ๆ
// กันเคส harvester หยิบไฟล์อย่าง js.chargebee.com/.../v2/pi-worker.js มาเป็น "ปลายทาง"
const socialIsAsset = (url) => SOCIAL_ASSET_EXT.test(String(url || ''));
const socialIsPlatform = (url) => { const h = socialHostOf(url); return SOCIAL_PLATFORMS.some((d) => hostIn(h, d)); };
function socialIsSameSite(url, host) {
  const h = socialHostOf(url);
  if (!h || !host) return false;
  const strip = (x) => x.replace(/^www\./, '');
  return strip(h) === strip(host) || hostIn(h, strip(host)) || hostIn(host, strip(h));
}

// ---- ตัวขุดปลายทางจาก HTML (ฟังก์ชันล้วน ๆ เทสต์แยกได้) ----

function exAnchorById(html, id) {
  const m = html.match(new RegExp('<a\\b[^>]*\\bid=["\']' + id + '["\'][^>]*>', 'i'));
  if (!m) return null;
  const href = m[0].match(/\bhref=["']([^"']+)["']/i);
  return href ? href[1] : null;
}
function exAnchorByClass(html, cls) {
  const m = html.match(new RegExp('<a\\b[^>]*\\bclass=["\'][^"\']*\\b' + cls + '\\b[^"\']*["\'][^>]*>', 'i'));
  if (!m) return null;
  const href = m[0].match(/\bhref=["']([^"']+)["']/i);
  return href ? href[1] : null;
}
// boost.ink / bst.gg / booo.st ยัด base64 ไว้ใน attribute ชื่อมั่ว ๆ บน <script>
function exBase64Attr(html) {
  const out = [];
  const re = /\s([a-zA-Z][\w-]{5,})=["']([A-Za-z0-9+/=_-]{24,})["']/g;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    if (/^(?:integrity|nonce|src|href|crossorigin|id|class|name|style|content)$/i.test(m[1])) continue;
    const url = socialCleanUrl(b64urlToStr(m[2]));
    if (url) out.push(url);
  }
  return out;
}
const SOCIAL_KEY_RE = /(unlocked_link|unlock_link|targeturl|target_url|targetUrl|destination_url|destinationUrl|destination|redirect_url|redirectUrl|original_link|original_url|long_url|longUrl|download_url|file_url|link_url|linkUrl|target|url|link)/;
function socialDeepUrls(node, acc, depth) {
  acc = acc || []; depth = depth || 0;
  if (depth > 8 || acc.length > 24 || node == null) return acc;
  if (Array.isArray(node)) { for (const n of node) socialDeepUrls(n, acc, depth + 1); return acc; }
  if (typeof node === 'object') {
    for (const k of Object.keys(node)) {
      const v = node[k];
      if (typeof v === 'string') {
        if (SOCIAL_KEY_RE.test(k)) { const u = socialCleanUrl(v); if (u) acc.push(u); }
      } else {
        socialDeepUrls(v, acc, depth + 1);
      }
    }
  }
  return acc;
}
function exNextData(html) {
  const m = html.match(/<script[^>]+id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
  if (!m) return [];
  try { return socialDeepUrls(JSON.parse(m[1])); } catch { return []; }
}
// ครอบคลุม flight stream ของ Next (self.__next_f.push), inline JSON, x-data ของ Alpine
function exJsonKeys(html) {
  const text = socialUnescape(socialDecodeEntities(html));
  const strong = [], weak = [];
  const re = new RegExp('["\']?' + SOCIAL_KEY_RE.source + '["\']?\\s*[:=]\\s*["\'](https?://[^"\'\\s\\\\]+)["\']', 'gi');
  let m;
  while ((m = re.exec(text)) && strong.length + weak.length < 24) {
    const url = socialCleanUrl(m[2]);
    if (!url) continue;
    (/^(?:target|url|link)$/i.test(m[1]) ? weak : strong).push(url);
  }
  return strong.concat(weak);
}
function exJsRedirect(html) {
  const out = [];
  const pats = [
    /window\.open\(\s*["']([^"']+)["']\s*,\s*["']_self["']\s*\)/gi,
    /location\s*\.\s*(?:replace|assign)\(\s*["']([^"']+)["']\s*\)/gi,
    /(?:window|document|top|self)\.location(?:\.href)?\s*=\s*["']([^"']+)["']/gi,
    /\blocation\.href\s*=\s*["']([^"']+)["']/gi
  ];
  for (const re of pats) {
    let m;
    while ((m = re.exec(html)) && out.length < 8) { const u = socialCleanUrl(m[1]); if (u) out.push(u); }
  }
  return out;
}
function exMetaRefresh(html) {
  const m = html.match(/<meta[^>]+http-equiv=["']?refresh["']?[^>]*content=["'][^"']*?url\s*=\s*([^"';]+)/i);
  return m ? socialCleanUrl(m[1]) : null;
}
// sub2unlock.id: <textarea name="link">{"original":"...&lnkXXXX=<base64 ของ url ที่ urlencode ไว้>"}</textarea>
function exTextareaLink(html) {
  const m = html.match(/<textarea[^>]+name=["']link["'][^>]*>([\s\S]*?)<\/textarea>/i);
  if (!m) return [];
  const out = [];
  const raw = socialDecodeEntities(m[1]).trim();
  let original = raw;
  try { const j = JSON.parse(raw); if (j && j.original) original = String(j.original); } catch {}
  const direct = socialCleanUrl(original);
  if (direct) out.push(direct);
  try {
    for (const [k, v] of new URLSearchParams(original.replace(/^[^?]*\?/, '')).entries()) {
      if (!/^lnk/i.test(k)) continue;
      let dec = b64urlToStr(v);
      if (dec && !/^https?:/i.test(dec)) { try { dec = decodeURIComponent(dec); } catch {} }
      const u = socialCleanUrl(dec);
      if (u) out.push(u);
    }
  } catch {}
  return out;
}
function exDataAttr(html) {
  const out = [];
  const re = /\bdata-(?:url|link|href|target|destination|redirect)=["']([^"']+)["']/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    const direct = socialCleanUrl(m[1]);
    if (direct) { out.push(direct); continue; }
    const dec = socialCleanUrl(b64urlToStr(m[1]));
    if (dec) out.push(dec);
  }
  return out;
}
function exTitle(html) {
  const m = html.match(/<title[^>]*>([\s\S]{0,200}?)<\/title>/i);
  if (!m) return null;
  const t = socialDecodeEntities(m[1]).replace(/\s+/g, ' ').trim();
  return t ? t.slice(0, 120) : null;
}

function harvestDestination(html, host) {
  const steps = [
    ['anchor_unlock', exAnchorById(html, 'updateHiddenUnlocks')],
    ['anchor_getlink', exAnchorByClass(html, 'get-link')],
    ['textarea_link', exTextareaLink(html)],
    ['base64_attr', exBase64Attr(html)],
    ['next_data', exNextData(html)],
    ['json_key', exJsonKeys(html)],
    ['js_redirect', exJsRedirect(html)],
    ['meta_refresh', exMetaRefresh(html)],
    ['data_attr', exDataAttr(html)]
  ];
  for (const [via, found] of steps) {
    for (const cand of (Array.isArray(found) ? found : [found])) {
      const url = socialCleanUrl(cand);
      if (!url) continue;
      if (socialIsInfra(url) || socialIsAsset(url) || socialIsSameSite(url, host)) continue;
      return { dest: url, via };
    }
  }
  return null;
}
// ชั้นสุดท้าย: กวาดท���กลิงก์ในหน้า แล้วคัดอันที่ "น่าจะ" เป็นปลายทาง
function looseScan(html, host) {
  const text = socialUnescape(socialDecodeEntities(html));
  const seen = new Set();
  const out = [];
  const re = /https?:\/\/[^\s"'`<>\\)\]]+/gi;
  let m;
  while ((m = re.exec(text)) && out.length < 5) {
    const url = socialCleanUrl(m[0]);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    if (socialIsInfra(url) || socialIsPlatform(url)) continue;
    const h = socialHostOf(url);
    if (socialIsSameSite(url, host) || hostIsSocial(h) || SOCIAL_OTHER_LOCKERS.some((d) => hostIn(h, d))) continue;
    if (SOCIAL_ASSET_EXT.test(url)) continue;
    const p = new URL(url);
    // โหมดเดาเอาเฉพาะที่พอเชื่อได้: https และต้องมี path/query (ลิงก์หน้าแรกเปล่า ๆ กับ namespace URI ตัดทิ้ง)
    if (p.protocol !== 'https:') continue;
    if ((p.pathname === '/' || p.pathname === '') && !p.search) continue;
    out.push(url);
  }
  return out;
}

// ---- network helpers ----

function socialFetch(url, opt) {
  opt = opt || {};
  let origin = '';
  try { origin = new URL(url).origin; } catch {}
  const headers = {
    'User-Agent': LOOT_UA,
    Accept: opt.json ? 'application/json, text/plain, */*' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    Referer: opt.referer || origin + '/',
    ...(opt.headers || {})
  };
  if (opt.cookie) headers.Cookie = opt.cookie;
  return fetch(url, {
    method: opt.method || 'GET',
    headers,
    body: opt.body,
    redirect: opt.redirect || 'follow',
    signal: AbortSignal.timeout(opt.timeout || SOCIAL_FETCH_MS)
  });
}
const socialBlocked = (status, html) => status === 403 && /just a moment|cf-chl|challenge-platform|cf_chl_opt/i.test(html || '');

// ---- per-site solvers ----

async function solveRekonise(u, deadline) {
  const slug = u.pathname.replace(/^\/+|\/+$/g, '').split('/')[0];
  if (!slug) throw new Error('ลิงก์ rekonise ไม่มี slug');
  const api = 'https://api.rekonise.com/social-unlocks/' + encodeURIComponent(slug);
  const common = { json: true, headers: { Origin: 'https://rekonise.com' }, referer: 'https://rekonise.com/' + slug };

  let token = null;
  let cookie = '';
  const info = await socialFetch(api + '/', common);
  if (info.status === 404) throw new Error('ไม่พบลิงก์ rekonise นี้ (อาจถูกลบไปแล้ว)');
  const sc = info.headers.getSetCookie ? info.headers.getSetCookie() : [];
  cookie = sc.map((c) => c.split(';')[0]).join('; ');
  if (info.ok) {
    const j = await info.json().catch(() => null);
    if (j) {
      token = j.unlock_token || j.token || null;
      const direct = socialCleanUrl(j.url || j.link);
      if (direct) return { dest: direct, via: 'rekonise_api', title: j.title || null };
    }
  }

  // unlock ตอบ 403 ช่วงแรกเพราะเช็คเวลา (clock skew) — รอแล้วยิงซ้ำจนหมดงบเวลา
  let lastStatus = 0;
  for (let attempt = 1; attempt <= 5; attempt++) {
    const r = await socialFetch(api + '/unlock' + (token ? '?token=' + encodeURIComponent(token) : ''), { ...common, cookie });
    lastStatus = r.status;
    if (r.ok) {
      const j = await r.json().catch(() => null);
      const dest = j && socialCleanUrl(j.url || j.link || (j.data && j.data.url));
      if (dest) return { dest, via: 'rekonise_api', title: (j && j.title) || null };
    }
    if (r.status !== 403) break;
    if (attempt >= 2 || Date.now() + 150 > deadline) break;
    await sleep(80);
  }
  throw new Error(lastStatus === 403
    ? 'rekonise ยังไม่ยอมปลดล็อก (HTTP 403) — ลิงก์นี้บังคับให้รอครบเวลาจริง ลองยิงใหม่อีกครั้งได้'
    : 'rekonise ไม่คืนปลายทาง (HTTP ' + lastStatus + ')');
}

// link-unlock.com: หน้าเว็บเป็น Next ที่ดึงข้อมูลจาก api.link-unlock.com
//   GET  /u/<slug>           -> { unlock: { title, steps: [{ id, type, ... }] } }
//   POST /u/<slug>/complete  -> { destinationUrl, adUrl, adBehavior }  (ต้องส่ง id ของ step ครบทุกอัน)
async function solveLinkUnlock(u) {
  const parts = u.pathname.replace(/^\/+|\/+$/g, '').split('/').filter(Boolean);
  const slug = parts[0] === 'u' ? parts[1] : parts[0];
  if (!slug) throw new Error('ลิงก์ link-unlock ไม่มี slug');
  const base = 'https://api.link-unlock.com/u/' + encodeURIComponent(slug);
  const common = { json: true, headers: { Origin: 'https://link-unlock.com' }, referer: 'https://link-unlock.com/' + slug };

  const info = await socialFetch(base, common);
  if (info.status === 404) throw new Error('ไม่พบลิงก์ link-unlock นี้ (อาจถูกลบไปแล้ว)');
  const meta = await info.json().catch(() => null);
  const unlock = (meta && meta.unlock) || {};
  const steps = Array.isArray(unlock.steps) ? unlock.steps.map((s) => s && s.id).filter(Boolean) : [];

  const r = await socialFetch(base + '/complete', {
    ...common,
    method: 'POST',
    headers: { ...common.headers, 'Content-Type': 'application/json' },
    body: JSON.stringify({ steps, offerSessions: {} })
  });
  const j = await r.json().catch(() => null);
  const dest = j && socialCleanUrl(j.destinationUrl || j.url);
  if (dest) return { dest, via: 'link_unlock_api', title: unlock.title || null };
  throw new Error('link-unlock ไม่คืนปลายทาง: ' + ((j && (j.error || j.message)) || 'HTTP ' + r.status));
}

async function solveSub2UnlockCom(u) {
  const slug = u.pathname.replace(/^\/+|\/+$/g, '').split('/').pop();
  if (!slug) return null;
  const r = await socialFetch('https://api.sub2unlock.com/api/sinks/' + encodeURIComponent(slug), {
    json: true, headers: { Origin: 'https://sub2unlock.com' }, referer: 'https://sub2unlock.com/' + slug
  });
  if (!r.ok) return null;
  const j = await r.json().catch(() => null);
  if (!j) return null;
  const d = j.data || j;
  const dest = socialCleanUrl(d.unlocked_link || d.unlock_link || d.url || d.link);
  return dest ? { dest, via: 'sub2unlock_api', title: d.title || null } : null;
}

async function solveYtSubMe(u) {
  const code = u.searchParams.get('urlid') || u.searchParams.get('code') || u.pathname.replace(/^\/+|\/+$/g, '').split('/').pop();
  if (!code) return null;
  const r = await socialFetch('https://www.ytsubme.com/dashboard/api/s2u_links.php?mode=s2uGetLink&code=' + encodeURIComponent(code), {
    json: true, referer: 'https://www.ytsubme.com/'
  });
  if (!r.ok) return null;
  const j = await r.json().catch(() => null);
  if (!j) return null;
  const msg = j.msg;
  if (typeof msg === 'string' && /not exist/i.test(msg)) throw new Error('ytsubme: ไม่พบลิงก์นี้');
  const dest = socialCleanUrl((msg && (msg.target || msg.url || msg.link)) || j.return_url);
  return dest ? { dest, via: 'ytsubme_api', title: (msg && msg.title) || null } : null;
}

// ฟอร์ม CakePHP ของพวก sub2unlock.net / social-unlock รุ่นเก่า -> POST /links/go
function socialFormInputs(html) {
  const out = {};
  const re = /<input\b[^>]*>/gi;
  let m;
  while ((m = re.exec(html))) {
    const name = m[0].match(/\bname=["']([^"']+)["']/i);
    const value = m[0].match(/\bvalue=["']([^"']*)["']/i);
    if (name) out[socialDecodeEntities(name[1])] = value ? socialDecodeEntities(value[1]) : '';
  }
  return out;
}
async function solveCakeForm(u, html, cookie, deadline) {
  const f = socialFormInputs(html);
  if (!f._csrfToken || f.ad_form_data == null) return null;
  const body = new URLSearchParams({
    _method: f._method || 'POST',
    _csrfToken: f._csrfToken,
    ad_form_data: f.ad_form_data,
    '_Token[fields]': f['_Token[fields]'] || '',
    '_Token[unlocked]': f['_Token[unlocked]'] || ''
  });
  // ยิงทันทีโดยไม่รอ 10 วินาที
  const r = await socialFetch(u.origin + '/links/go', {
    method: 'POST',
    json: true,
    cookie,
    referer: u.href,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest',
      Origin: u.origin
    },
    body: body.toString()
  });
  if (!r.ok) return null;
  const j = await r.json().catch(() => null);
  const dest = j && socialCleanUrl(j.url || j.link || j.redirect);
  return dest ? { dest, via: 'cake_links_go' } : null;
}

async function solveSocialPage(u, deadline) {
  const jar = lootJar();
  const res = await socialFetch(u.href, { timeout: Math.min(SOCIAL_FETCH_MS, Math.max(5000, deadline - Date.now())) });
  jar.store(res);
  const html = await res.text();
  if (socialBlocked(res.status, html)) {
    throw new Error('เว็บนี้กั้นด้วย Cloudflare challenge เลยดึงหน้าจากฝั่งเซิร์ฟเวอร์ไม่ได้ ต้องเปิดผ่านเบราว์เซอร์จริง');
  }
  const title = exTitle(html);

  const hit = harvestDestination(html, u.hostname);
  if (hit) return { ...hit, title: hit.title || title };

  const cake = await solveCakeForm(u, html, jar.header(), deadline).catch(() => null);
  if (cake) return { ...cake, title };

  // ถ้า fetch ตาม redirect แล้วหลุดออกนอกเว็บล็อกเกอร์ไปเลย นั่นคือปลายทาง
  const finalUrl = socialCleanUrl(res.url);
  if (finalUrl && !socialIsSameSite(finalUrl, u.hostname) && !hostIsSocial(socialHostOf(finalUrl))) {
    return { dest: finalUrl, via: 'redirect', title };
  }

  // หน้า error (404/410/...) อย่าเดา เพราะลิงก์ที่เหลือคือโฆษณาของเว็บเอง
  const loose = res.status < 400 ? looseScan(html, u.hostname) : [];
  if (loose.length) {
    return { dest: loose[0], via: 'loose_scan', title, note: 'เดาจากลิงก์ที่เจอในหน้า อาจไม่ใช่ปลายทางจริง' };
  }
  return null;
}

async function bypassSocial(inputUrl, depth, opts) {
  if (depth && typeof depth === 'object') { opts = depth; depth = 0; }
  depth = depth || 0;
  opts = opts || {};
  const start = Date.now();
  const deadline = start + SOCIAL_BUDGET_MS;
  const done = (extra) => ({ input_url: inputUrl, elapsed_ms: Date.now() - start, ...extra });

  let u;
  try { u = new URL(inputUrl); } catch { return done({ status: 'error', message: 'URL ไม่ถูกต้อง' }); }

  try {
    const host = u.hostname;

    // rkns.link เป็นแค่ตัวย่อของ rekonise -> ตามไปเอา slug จริงก่อน
    if (hostIn(host, 'rkns.link')) {
      const r = await socialFetch(u.href, { redirect: 'follow' });
      const next = socialCleanUrl(r.url);
      if (next && !socialIsSameSite(next, host)) {
        const inner = await bypassSocial(next, depth + 1, opts);
        return { ...inner, input_url: inputUrl };
      }
      return done({ status: 'error', message: 'ตาม rkns.link ต่อไม่ได้' });
    }

    let hit = null;
    if (hostIn(host, 'link-unlock.com')) hit = await solveLinkUnlock(u);
    else if (hostIn(host, 'rekonise.com')) hit = await solveRekonise(u, deadline);
    else if (hostIn(host, 'sub2unlock.com') || hostIn(host, 'ytsubme.com')) {
      const apiTask = (hostIn(host, 'sub2unlock.com') ? solveSub2UnlockCom(u) : solveYtSubMe(u)).catch(() => null);
      const pageTask = solveSocialPage(u, deadline).catch(() => null);
      hit = await new Promise((resolve) => {
        let pending = 2;
        let resolved = false;
        const onOne = (val) => {
          if (resolved) return;
          if (val && val.dest) { resolved = true; resolve(val); return; }
          if (--pending === 0) { resolved = true; resolve(null); }
        };
        apiTask.then(onOne);
        pageTask.then(onOne);
      });
    } else {
      hit = await solveSocialPage(u, deadline);
    }
    if (!hit || !hit.dest) {
      return done({ status: 'error', message: 'หาปลายทางในหน้านี้ไม่เจอ — เว็บอาจเปลี่ยนโครงสร้าง หรือบังคับให้��ำภารกิจจริงก่อน' });
    }

    // ปลายทางเป็นลิงก์ล็อกอีกชั้น -> แกะต่อให้ (สูงสุด 2 ชั้น)
    const dHost = socialHostOf(hit.dest);
    if (depth < 2 && dHost) {
      let inner = null;
      if (hostIsSocial(dHost)) inner = await bypassSocial(hit.dest, depth + 1, opts);
      else if (hostIsLoot(dHost)) inner = await bypassLootlabs(hit.dest, opts);
      else if (ALLOWED.some((d) => hostIn(dHost, d))) inner = await bypass(hit.dest, opts);
      if (inner && inner.status === 'success' && inner.destination) {
        return done({
          status: 'success',
          type: 'link',
          destination: inner.destination,
          title: inner.title || hit.title || null,
          is_premium_only: Boolean(inner.is_premium_only),
          via: hit.via + ' → ' + (inner.via || 'linkvertise'),
          note: hit.note || inner.note || null
        });
      }
    }

    return done({
      status: 'success',
      type: 'link',
      destination: hit.dest,
      title: hit.title || null,
      is_premium_only: false,
      via: hit.via,
      note: hit.note || null
    });
  } catch (err) {
    const raw = (err && err.message) || String(err);
    let message = raw;
    if (err && err.name === 'TimeoutError') message = 'หมดเวลารอการตอบกลับ';
    else if (/fetch failed|ENOTFOUND|EAI_AGAIN|ECONNREFUSED/i.test(raw)) {
      message = 'ต่อเว็บนี้ไม่ได้ (โดเมนอาจใช้งานไม่ได้แล้ว หรือบล็อกการเรียกจากเซิร์ฟเวอร์)';
    }
    return done({ status: 'error', message });
  }
}

// ============================================================================
// Script-host pages (เพจที่ฝังสคริปต์จริงไว้ในหน้าเอง เช่น somtank บน github.io)
// ----------------------------------------------------------------------------
// เพจพวกนี้ซ่อน "สคริปต์ของจริง" ไว้ในตัวแปร JS (เช่น const REAL_SCRIPT = `...`)
// หลัง modal ปลอมที่บังคับให้ดูคลิป/กดปลดล็อคก่อน ทั้งที่เนื้อสคริปต์ถูกฝังอยู่ใน
// HTML เรียบร้อยแล้ว ตัวแกะนี้ดูด HTML มาแล้วขุดเอา:
//   - ลิงก์ loader ปลายทางจริงใน loadstring(game:HttpGet("<URL>"))
//   - เนื้อสคริปต์เต็ม ๆ จาก template string
// ============================================================================

const SCRIPT_PAGE_HOSTS = ['github.io', 'gitlab.io', 'pages.dev', 'netlify.app', 'vercel.app', 'web.app', 'firebaseapp.com'];
const hostIsScriptPage = (host) => SCRIPT_PAGE_HOSTS.some((d) => hostIn(host, d));

function extractHttpGet(text) {
  if (!text) return null;
  // loadstring(game:HttpGet("...")) / HttpGetAsync('...')
  const m = text.match(/HttpGet(?:Async)?\s*\(\s*["'`]([^"'`]+)["'`]/i);
  if (m && /^https?:\/\//i.test(m[1])) return m[1];
  // เผื่อเก็บลิงก์ .lua ไว้ตรง ๆ
  const m2 = text.match(/["'`](https?:\/\/[^"'`\s]+\.lua)["'`]/i);
  return m2 ? m2[1] : null;
}

// สัญญาณว่าข้อความก้อนหนึ่ง "เป็นสคริปต์จริง" (กันไปหยิบ decoy/ข้อความหลอกในหน้า)
const SCRIPT_HINT = /loadstring|HttpGet(?:Async)?|getgenv|syn\.request|http_request|game:Http|script_key|_G\.|readfile|writefile|queue_on_teleport|Instance\.new/i;

// ถอด HTML entity พื้นฐาน (ใช้กับเนื้อใน <textarea>/<pre>/<code> และ attribute)
function decodeEntities(s) {
  return String(s)
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&apos;/g, "'")
    .replace(/&#x2F;/gi, '/').replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
}

// ถอด escape ของ string literal แบบ JS (\n \t \uXXXX \xXX และ line-continuation)
function decodeJsStr(body) {
  return String(body).replace(/\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|\r?\n|.)/g, (m, g) => {
    if (g[0] === 'u' || g[0] === 'x') return String.fromCharCode(parseInt(g.slice(1), 16));
    if (g === '\n' || g === '\r\n') return '';
    const map = { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', v: '\v', '0': '\0' };
    return Object.prototype.hasOwnProperty.call(map, g) ? map[g] : g;
  });
}

// ตัด indent ร่วม + ช่องว่างหัว/ท้าย ให้สคริปต���สะอาด แต่คงโครงสร้างบรรทัดเดิมไว้ครบ
function dedentScript(s) {
  const lines = String(s).replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  const indents = lines.filter((l) => l.trim()).map((l) => (l.match(/^[ \t]*/) || [''])[0].length);
  const min = indents.length ? Math.min.apply(null, indents) : 0;
  return lines.map((l) => l.slice(min)).join('\n').trim();
}

// ดึง "สคริปต์เต็ม ๆ" ที่ฝังอยู่ในหน้า — เอามาทั้งก้อน ไม่ใช่แค่ URL
// ลองหลายวิธีเรียงตามความน่าเชื่อถือ แล้วเลือกก้อนที่ "มีสัญญาณว่าเป็นสคริปต์จริง"
// (จึงข้าม decoy อย่าง <code> โชว์ข้อความหลอกที่ไม่มี loadstring ไปได้)
function extractRealScript(html) {
  if (!html) return null;
  const cands = [];
  let m;

  // 1) template string (backtick) ที่มี loadstring/HttpGet อยู่ข้างใน — เคสหลักของ somtank/REAL_SCRIPT
  const btRe = /`([^`]*(?:loadstring|HttpGet)[^`]*)`/gi;
  while ((m = btRe.exec(html))) cands.push(m[1]);

  // 2) assignment แบบ string เดี่ยว/คู่ ที่มี loadstring (ถอด escape ให้)
  m = html.match(/(?:const|let|var)\s+[A-Za-z_$][\w$]*\s*=\s*(['"])((?:\\.|(?!\1)[\s\S])*?(?:loadstring|HttpGet)(?:\\.|(?!\1)[\s\S])*?)\1/i);
  if (m) cands.push(decodeJsStr(m[2]));

  // 3) ตัวแปรที่ชื่อสื่อว่าเป็นสคริปต์/ซอร์ส/โค้ด = template string
  m = html.match(/(?:const|let|var)\s+[A-Za-z_$]*(?:SCRIPT|SOURCE|CODE|LUA)[A-Za-z_$]*\s*=\s*`([\s\S]*?)`/i);
  if (m) cands.push(m[1]);

  // 4) ซ่อนไว้ใน <textarea>/<pre>/<code> (รับเฉพาะก้อนที่หน้าตาเป็นสคริปต์จริง)
  const tagRe = /<(textarea|pre|code)\b[^>]*>([\s\S]*?)<\/\1>/gi;
  let tm;
  while ((tm = tagRe.exec(html))) {
    const txt = decodeEntities(tm[2]);
    if (SCRIPT_HINT.test(txt)) cands.push(txt);
  }

  // 5) data-* attribute ที่เก็บสคริปต์ไว้
  const dataRe = /data-(?:script|code|source|lua|payload)\s*=\s*(['"])([\s\S]*?)\1/gi;
  let dm;
  while ((dm = dataRe.exec(html))) {
    const t = decodeEntities(dm[2]);
    if (SCRIPT_HINT.test(t)) cands.push(t);
  }

  // 6) base64 ที่ถอดแล้วเป็นสคริปต์ (atob("..."))
  const b64Re = /atob\(\s*['"]([A-Za-z0-9+/=\s]{16,})['"]\s*\)/gi;
  let bm;
  while ((bm = b64Re.exec(html))) {
    try {
      const dec = Buffer.from(bm[1].replace(/\s+/g, ''), 'base64').toString('utf8');
      if (SCRIPT_HINT.test(dec)) cands.push(dec);
    } catch {
      /* ไม่ใช่ base64 ที่ถอดได้ ข้าม */
    }
  }

  // 7) เผื่อสุด: loadstring(game:HttpGet(...))() ที่ลอยอยู่ใน HTML ตรง ๆ
  m = html.match(/loadstring\s*\(\s*game:HttpGet(?:Async)?\s*\([^)]*\)\s*\)\s*\(\s*\)/i);
  if (m) cands.push(m[0]);

  // เลือกก้อนแรกที่ "เป็นสคริปต์จริง" ตามลำดับความน่าเชื่อถือ ไม่งั้นเอาก้อนยาวสุด
  const good = cands.find((s) => SCRIPT_HINT.test(s));
  const chosen = good || cands.sort((a, b) => b.length - a.length)[0] || null;
  return chosen ? dedentScript(chosen) : null;
}

async function bypassScriptPage(inputUrl) {
  const start = Date.now();
  const done = (extra) => ({ input_url: inputUrl, elapsed_ms: Date.now() - start, ...extra });
  let u;
  try { u = new URL(inputUrl); } catch { return done({ status: 'error', message: 'URL ไม่ถูกต้อง' }); }
  if (!['http:', 'https:'].includes(u.protocol)) return done({ status: 'error', message: 'รองรับเฉพาะลิงก์ http/https' });

  let html;
  try {
    const res = await fetch(u.href, { headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,*/*' }, redirect: 'follow', signal: AbortSignal.timeout(TIMEOUT_MS) });
    html = await res.text();
  } catch (err) {
    return done({ status: 'error', message: err && err.name === 'TimeoutError' ? 'หมดเวลารอการตอบกลับ' : 'ดึงหน้าเว็บไ��่สำเร็จ (โดเมนอาจใช้งานไม่ได้ หรือบล็อกการเรียกจากเซิร์ฟเวอร์)' });
  }

  const script = extractRealScript(html);
  const loader = extractHttpGet(script || html);
  const titleRaw = (html.match(/<title[^>]*>([^<]*)<\/title>/i) || [])[1];
  const title = titleRaw ? decodeEntities(titleRaw).trim() : null;

  if (!loader && !script) {
    return done({ status: 'error', message: 'ไม่พบสคริปต์หรือ loadstring ที่ฝังอยู่ในหน้านี้ (หน้านี้อาจไม่ได้ฝังสคริปต์ไว้ตรง ๆ หรือโหลดสคริปต์มาทีหลังด้วย JS)' });
  }

  // ดึงมา "ทั้งก้อน": ถ้าเจอสคริปต์เต็มให้ส่งเป็น type 'script' (คัดลอกไปรันได้เลย)
  // โดยยังแนบ URL ของ loader (.lua) มาด้วยใน destination เผื่ออยากได้เฉพาะลิงก์
  return done({
    status: 'success',
    type: script ? 'script' : 'link',
    destination: loader || null,
    script: script || null,
    title,
    is_premium_only: false,
    via: 'script-page'
  });
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const origin = req.headers && req.headers.origin;
  const host = req.headers && req.headers.host;
  let crossOrigin = req.headers && req.headers['sec-fetch-site'] === 'cross-site';
  if (origin && host) {
    try { crossOrigin = crossOrigin || new URL(origin).host !== host; } catch { crossOrigin = true; }
  }
  if (crossOrigin) return res.status(403).json({ status: 'error', code: 'ORIGIN_DENIED', message: 'เรียก API จากเว็บไซต์เดียวกันเท่านั้น' });

  if (req.query && String(req.query.action || '').toLowerCase() === 'warm') {
    warmConnections();
    try {
      await Promise.race([
        require('./browserlol').preconnect(1),
        new Promise((r) => setTimeout(r, 350))
      ]);
    } catch {}
    return res.status(200).json({ status: 'ok', warm: true });
  }

  if (req.query && String(req.query.action || '').toLowerCase() === 'prime') {
    const primeUrl = String(req.query.url || '');
    if (!/^https:\/\/auth\.platorelay\.com\//i.test(primeUrl)) {
      return res.status(400).json({ status: 'error', message: 'prime รับเฉพาะลิงก์ auth.platorelay.com' });
    }
    try {
      const out = await require('./platorelay-browser').prewarmPlatorelay(primeUrl, {
        sessionId: req.query.session_id || req.query.session,
        helperUrl: platorelayHelperFromRequest(req)
      });
      return res.status(200).json({ status: out.ok ? 'ok' : 'error', prime: true, ...out });
    } catch (error) {
      return res.status(200).json({ status: 'error', prime: true, message: (error && error.message) || 'prime ไม่สำเร็จ' });
    }
  }

  const lootlink = req.query && req.query.lootlink;
  if (typeof lootlink === 'string' && lootlink) {
    const tk = decodeLootlink(lootlink);
    return res.status(tk ? 200 : 400).json(tk ? { message: 'Lootlink decoded!', tk } : { message: 'Failed to decode lootlink!' });
  }

  const url = req.query && req.query.url;
  if (typeof url !== 'string' || !url) {
    return res.status(400).json({ status: 'error', message: 'ไม่พบพารามิเตอร์ url' });
  }

  let hostname = '';
  let u;
  try { u = new URL(url); hostname = u.hostname; } catch {}

  if (hostIn(hostname, 'platoboost.com')) {
    const id = u.searchParams.get('id');
    if (!id) return res.status(400).json({ status: 'error', input_url: url, message: "ไม่พบพารามิเตอร์ 'id' ใน URL" });
    const { key, elapsed_ms } = await bypassPlatoboost(id);
    if (key) return res.status(200).json({ status: 'success', type: 'key', input_url: url, key, elapsed_ms });
    return res.status(422).json({ status: 'error', input_url: url, message: 'Bypass failed!', elapsed_ms });
  }

  if (hostIn(hostname, 'platorelay.com')) {
    const out = await bypassPlatorelay(url, { sessionId: req.query.session_id || req.query.session, reuseSession: true, helperUrl: platorelayHelperFromRequest(req) });
    out.input_url = url;
    return res.status(out.status === 'success' ? 200 : 422).json(out);
  }

  const sessionId = req.query.session_id || req.query.session;
  const capmonsterKey = req.query.capmonster || req.query.capmonster_key || '';
  const twocaptchaKey = req.query.twocaptcha || req.query['2captcha'] || req.query.twocaptcha_key || '';

  if (hostIsLoot(hostname) || isLootStyleUrl(u)) {
    const out = await bypassLootlabs(url, { sessionId, helperUrl: platorelayHelperFromRequest(req), capmonsterKey, twocaptchaKey });
    return res.status(out.status === 'success' ? 200 : 422).json(out);
  }

  if (hostIsSocial(hostname)) {
    const out = await bypassSocial(url, 0, { sessionId });
    return res.status(out.status === 'success' ? 200 : 422).json(out);
  }

  // เพจที่ฝังสคริปต์ไว้เอง (github.io ฯลฯ) หรือ host ที่ไม่ใช่ linkvertise -> ลองแกะ script page
  const isLinkvertiseHost = ALLOWED.some((d) => hostIn(hostname, d));
  if (hostIsScriptPage(hostname) || !isLinkvertiseHost) {
    const out = await bypassScriptPage(url);
    if (out.status === 'success') return res.status(200).json(out);
    if (!isLinkvertiseHost) return res.status(422).json(out);
  }

  const out = await bypass(url, { sessionId: req.query.session_id || req.query.session });
  return res.status(out.status === 'success' ? 200 : 422).json(out);
};

module.exports.bypass = bypass;
module.exports.bypassPlatoboost = bypassPlatoboost;
module.exports.bypassPlatorelay = bypassPlatorelay;
module.exports.bypassLootlabs = bypassLootlabs;
module.exports.lootSolveKeySystem = lootSolveKeySystem;
module.exports.hostIsLoot = hostIsLoot;
module.exports.isLootStyleUrl = isLootStyleUrl;
module.exports.isLootAdUrl = isLootAdUrl;
module.exports.lootDestination = lootDestination;
module.exports.lootPayloadDestination = lootPayloadDestination;
module.exports.bypassSocial = bypassSocial;
module.exports.lvResolveTarget = lvResolveTarget;
module.exports.lvFetchMeta = lvFetchMeta;
module.exports.warmConnections = warmConnections;
module.exports.bypassScriptPage = bypassScriptPage;
module.exports.extractHttpGet = extractHttpGet;
module.exports.extractRealScript = extractRealScript;
module.exports.hostIsScriptPage = hostIsScriptPage;
module.exports.decodeLootlink = decodeLootlink;
// export ไว้ให้เทสต์ตัวขุด HTML แยกได้โดยไม่ต้องยิงเน็ต
module.exports.harvestDestination = harvestDestination;
module.exports.looseScan = looseScan;
module.exports.socialCleanUrl = socialCleanUrl;
module.exports.socialFormInputs = socialFormInputs;
module.exports.hostIsSocial = hostIsSocial;
module.exports.SOCIAL_DOMAINS = SOCIAL_DOMAINS;
