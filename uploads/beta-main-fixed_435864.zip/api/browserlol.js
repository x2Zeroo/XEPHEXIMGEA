// ===========================================================================
// api/browserlol.js — ไคลเอนต์ API ของ browser.lol (REST v7 + Streamable HTTP /mcp)
// อ้างอิง:
//   - https://browser.lol/en/docs/api/v7
//   - https://browser.lol/en/docs/mcp
// ===========================================================================

'use strict';

const http = require('http');
const https = require('https');

const DEFAULT_V7_BASE = 'https://api.browser.lol/v7';
const DEFAULT_MCP_URL = 'https://api.browser.lol/mcp';
const DEFAULT_SESSION_ID = 'brl-v-v7-1hq9hn8x5alp5z216749u01z5rvh8d7a1vaudied79ahjzdbjddxiy';
const DEFAULT_KEY = 'brl_k_en87muo3xZOYvfnApMC2km1PqWLhca98ZIleDEvRUWY2qlNxf';

function v7Base() {
  return (process.env.BROWSERLOL_API_URL || process.env.BROWSER_LOL_API_URL || DEFAULT_V7_BASE).replace(/\/+$/, '');
}

function mcpEndpoint() {
  return (process.env.BROWSERLOL_MCP_URL || process.env.BROWSER_LOL_MCP_URL || DEFAULT_MCP_URL).replace(/\/+$/, '');
}

function apiKey() {
  return process.env.BROWSERLOL_API_KEY || process.env.BROWSER_LOL_API_KEY ||
    process.env.BROWSERLOL_KEY || DEFAULT_KEY;
}

function configuredSessionId() {
  return String(process.env.BROWSERLOL_SESSION_ID || process.env.BROWSER_LOL_SESSION_ID || '').trim();
}

function defaultSessionId() {
  return configuredSessionId() || DEFAULT_SESSION_ID;
}

function sessionError(code, message) {
  return Object.assign(new Error(message), { code });
}

function validateSessionId(value) {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9_-]{1,200}$/.test(value)) {
    throw sessionError('SESSION_ID_REQUIRED', 'ต้องระบุ session_id ของ Browser.LOL ที่ถูกต้อง');
  }
  const configured = configuredSessionId();
  if (configured && value !== configured) {
    throw sessionError('SESSION_MISMATCH', 'session_id ไม่ตรงกับ BROWSERLOL_SESSION_ID ที่กำหนดไว้');
  }
  return value;
}

// สายถาวร keep-alive เพื่อไม่ต้องจับมือ TCP+TLS ใหม่ทุกคำขอ
const MAX_IDLE_SOCKET_MS = 20000;
const AGENT_OPTIONS = { keepAlive: true, keepAliveMsecs: 10000, maxSockets: 16, maxFreeSockets: 6, scheduling: 'lifo', noDelay: true };
const AGENTS = { 'https:': new https.Agent(AGENT_OPTIONS), 'http:': new http.Agent(AGENT_OPTIONS) };
for (const agent of Object.values(AGENTS)) {
  agent.on('free', (socket) => {
    socket.brlFreeAt = Date.now();
    if (typeof socket.unref === 'function') socket.unref();
  });
}

function dropStaleSockets(agent) {
  const now = Date.now();
  let fresh = 0;
  for (const list of Object.values(agent.freeSockets)) {
    for (const socket of list.slice()) {
      if (socket.destroyed) continue;
      if (now - (socket.brlFreeAt || 0) > MAX_IDLE_SOCKET_MS) socket.destroy();
      else fresh++;
    }
  }
  return fresh;
}

function v7Request(method, path, body, opts = {}) {
  const needsAuth = opts.auth !== false;
  const key = needsAuth ? apiKey() : '';
  if (needsAuth && !key) {
    return Promise.resolve({
      ok: false,
      status: 'denied',
      code: 'API_KEY_REQUIRED',
      message: 'ยังไม่ได้ตั้งค่า BROWSERLOL_API_KEY (คีย์ของ browser.lol)'
    });
  }
  const target = new URL(v7Base() + (path.startsWith('/') ? path : '/' + path));
  const agent = AGENTS[target.protocol];
  if (!agent) {
    return Promise.resolve({ ok: false, status: 'error', code: 'INVALID_URL', message: 'BROWSERLOL_API_URL ต้องเป็น http หรือ https' });
  }
  dropStaleSockets(agent);

  const payload = body != null ? JSON.stringify(body) : null;
  const timeoutMs = opts.timeoutMs || 15000;
  const ctrl = new AbortController();
  const timer = setTimeout(() => { try { ctrl.abort(); } catch {} }, timeoutMs);
  const signal = opts.signal ? AbortSignal.any([ctrl.signal, opts.signal]) : ctrl.signal;

  return new Promise((resolve) => {
    let settled = false;
    let req = null;
    const done = (val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal.removeEventListener('abort', onAbort);
      resolve(val);
    };
    const onAbort = () => {
      if (req) req.destroy();
      done({ ok: false, status: 'error', code: 'transport', transport: true, message: 'browser.lol v7 request aborted' });
    };
    if (signal.aborted) { onAbort(); return; }

    const headers = { Accept: 'application/json' };
    if (key) headers.Authorization = 'Bearer ' + key;
    if (payload != null) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(payload);
    }
    req = (target.protocol === 'http:' ? http : https).request(target, { method: method || 'GET', agent, headers });
    signal.addEventListener('abort', onAbort, { once: true });
    req.on('error', (err) => done({ ok: false, status: 'error', code: 'transport', transport: true, message: (err && err.message) || String(err) }));
    req.on('response', (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('error', (err) => done({ ok: false, status: 'error', code: 'transport', transport: true, message: (err && err.message) || String(err) }));
      res.on('end', () => {
        const httpStatus = res.statusCode || 0;
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch {}
        if (httpStatus === 401 || httpStatus === 403) {
          return done({ ok: false, status: 'denied', httpStatus, code: 'AUTH_DENIED', message: (json && json.message) || ('คีย์ browser.lol ใช้ไม่ได้ (HTTP ' + httpStatus + ')') });
        }
        if (httpStatus === 429) {
          return done({ ok: false, status: 'insecure', httpStatus, code: 'rate_limited', retryable: true, message: (json && json.message) || 'browser.lol ตอบ HTTP 429' });
        }
        if (!json || typeof json !== 'object') {
          return done({ ok: false, status: 'error', httpStatus, code: 'transport', transport: true, message: 'browser.lol v7 ตอบกลับไม่ใช่ JSON (HTTP ' + httpStatus + ')' });
        }
        if (json.status === 'ok') {
          return done({ ok: true, status: 'ok', httpStatus, data: json });
        }
        return done({
          ok: false,
          status: json.status || 'error',
          httpStatus,
          code: json.reason || json.status || 'error',
          message: json.message || 'browser.lol v7 ทำคำสั่งไม่สำเร็จ',
          data: json
        });
      });
    });
    if (payload != null) req.end(payload);
    else req.end();
  });
}

// ===========================================================================
// Streamable HTTP Browser Control API (https://api.browser.lol/mcp)
// ส่ง JSON-RPC 2.0 ผ่าน HTTPS POST พร้อม keep-alive agent
// ===========================================================================
let rpcSeq = 1;

function parseRpcBody(rawText) {
  const trimmed = String(rawText || '').trim();
  if (!trimmed) return null;
  try { return JSON.parse(trimmed); } catch {}
  // เผื่อกรณีเซิร์ฟเวอร์ตอบเป็น SSE (text/event-stream)
  const lines = trimmed.split(/\r?\n/);
  let last = null;
  for (const line of lines) {
    if (!line.startsWith('data:')) continue;
    const payload = line.slice(5).trim();
    if (!payload || payload === '[DONE]') continue;
    try { last = JSON.parse(payload); } catch {}
  }
  return last;
}

function mcpRequest(method, params, opts = {}) {
  const key = apiKey();
  if (!key) {
    return Promise.resolve({ ok: false, code: 'API_KEY_REQUIRED', message: 'ยังไม่ได้ตั้งค่า BROWSERLOL_API_KEY (คีย์ของ browser.lol)' });
  }
  let target;
  try { target = new URL(mcpEndpoint()); } catch {
    return Promise.resolve({ ok: false, code: 'INVALID_URL', message: 'BROWSERLOL_MCP_URL ไม่ถูกต้อง' });
  }
  const agent = AGENTS[target.protocol];
  if (!agent) {
    return Promise.resolve({ ok: false, code: 'INVALID_URL', message: 'BROWSERLOL_MCP_URL ต้องเป็น http หรือ https' });
  }
  dropStaleSockets(agent);

  const id = rpcSeq++;
  const payload = JSON.stringify({ jsonrpc: '2.0', id, method, params: params || {} });
  const timeoutMs = Math.max(500, opts.timeoutMs || 15000);
  const ctrl = new AbortController();
  const timer = setTimeout(() => { try { ctrl.abort(); } catch {} }, timeoutMs);
  const signal = opts.signal ? AbortSignal.any([ctrl.signal, opts.signal]) : ctrl.signal;

  return new Promise((resolve) => {
    let settled = false;
    let req = null;
    const done = (val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal.removeEventListener('abort', onAbort);
      resolve(val);
    };
    const onAbort = () => {
      if (req) req.destroy();
      done({ ok: false, code: 'transport', transport: true, message: 'browser.lol API request aborted/timeout' });
    };
    if (signal.aborted) { onAbort(); return; }

    const headers = {
      Authorization: 'Bearer ' + key,
      'Content-Type': 'application/json',
      Accept: 'application/json, text/event-stream',
      'Content-Length': Buffer.byteLength(payload)
    };
    req = (target.protocol === 'http:' ? http : https).request(target, { method: 'POST', agent, headers });
    signal.addEventListener('abort', onAbort, { once: true });
    req.on('error', (err) => done({ ok: false, code: 'transport', transport: true, message: (err && err.message) || String(err) }));
    req.on('response', (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('error', (err) => done({ ok: false, code: 'transport', transport: true, message: (err && err.message) || String(err) }));
      res.on('end', () => {
        const httpStatus = res.statusCode || 0;
        const bodyText = Buffer.concat(chunks).toString('utf8');
        const json = parseRpcBody(bodyText);
        if (httpStatus === 401 || httpStatus === 403) {
          return done({ ok: false, httpStatus, code: 'AUTH_DENIED', message: (json && (json.message || (json.error && json.error.message))) || ('คีย์ browser.lol ใช้ไม่ได้ (HTTP ' + httpStatus + ')') });
        }
        if (httpStatus === 429) {
          return done({ ok: false, httpStatus, code: 'rate_limited', retryable: true, message: 'browser.lol ตอบ HTTP 429' });
        }
        if (!json || typeof json !== 'object') {
          return done({ ok: false, httpStatus, code: 'transport', transport: true, message: 'browser.lol API ตอบกลับไม่ใช่ JSON (HTTP ' + httpStatus + ')' });
        }
        if (json.error) {
          return done({ ok: false, httpStatus, code: String(json.error.code || 'rpc_error'), message: json.error.message || 'browser.lol RPC error', raw: json });
        }
        const result = json.result || {};
        const meta = result._meta && result._meta['guard.ch/result'];
        const text = Array.isArray(result.content)
          ? result.content.map((c) => (c && c.text) || '').filter(Boolean).join('\n')
          : '';
        const isErr = Boolean(result.isError || (meta && meta.status && meta.status !== 'ok'));
        if (isErr) {
          const errCode = (meta && (meta.code || meta.error || meta.reason)) ||
            (/user_in_control/i.test(text) ? 'user_in_control' : /not_ready|starting/i.test(text) ? 'session_not_ready' : 'tool_error');
          return done({
            ok: false,
            httpStatus,
            code: errCode,
            message: (meta && meta.message) || text || 'คำสั่งเบราว์เซอร์ล้มเหลว',
            data: meta || null,
            text,
            raw: json
          });
        }
        return done({
          ok: true,
          httpStatus,
          data: meta || result,
          text,
          raw: json
        });
      });
    });
    req.end(payload);
  });
}

const activeSessionJobs = new Map();

function acquireSessionSlot(sessionId) {
  const id = String(sessionId || '').trim();
  if (!id) return () => {};
  activeSessionJobs.set(id, (activeSessionJobs.get(id) || 0) + 1);
  let released = false;
  return () => {
    if (released) return;
    released = true;
    const next = (activeSessionJobs.get(id) || 1) - 1;
    if (next <= 0) activeSessionJobs.delete(id);
    else activeSessionJobs.set(id, next);
  };
}

function activeSessionCount(sessionId) {
  return activeSessionJobs.get(String(sessionId || '').trim()) || 0;
}

function cleanTargetUrl(rawUrl) {
  const clean = String(rawUrl || '').replace(/[\u200B-\u200D\u2060\uFEFF]/g, '').trim();
  if (!clean || clean.length > 10000) return null;
  try {
    const u = new URL(clean);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    if (u.username || u.password) return null;
    return u.href;
  } catch {
    return null;
  }
}

async function pasteOpenUrl(sessionId, rawUrl, opts = {}) {
  const t0 = Date.now();
  let id;
  try {
    id = (String(sessionId || '').trim()) || defaultSessionId();
    validateSessionId(id);
  } catch (err) {
    return {
      ok: false,
      status: 'denied',
      code: (err && err.code) || 'SESSION_ID_REQUIRED',
      message: (err && err.message) || 'ต้องระบุ session_id ของ Browser.LOL ที่ถูกต้อง',
      pasteMs: Date.now() - t0
    };
  }

  const url = cleanTargetUrl(rawUrl);
  if (!url) {
    return {
      ok: false,
      status: 'denied',
      code: 'INVALID_TARGET_URL',
      message: 'ลิงก์ต้องเป็น http:// หรือ https:// ที่ถูกต้อง',
      pasteMs: Date.now() - t0
    };
  }

  const busy = activeSessionCount(id) > 0;
  if (!busy && !opts.preserveTabs && url.length <= 2000) {
    const launch = await v7Request('POST', '/vm/launch', { workspaceId: id, url }, {
      timeoutMs: Math.max(800, Math.min(opts.timeoutMs || 6000, 6000)),
      signal: opts.signal
    });
    const pasteMs = Date.now() - t0;
    if (launch.ok) {
      return {
        ok: true,
        status: 'ok',
        httpStatus: launch.httpStatus,
        pasteMs,
        method: 'v7_launch',
        singleTab: true,
        data: {
          ...(launch.data || {}),
          status: 'ok',
          tab_id: null,
          paste_ms: pasteMs,
          method: 'v7_launch'
        }
      };
    }
    const fatalMsg = String(launch.message || '');
    if (
      launch.code === 'AUTH_DENIED' ||
      launch.code === 'API_KEY_REQUIRED' ||
      /unknown session|no such|not found|deleted|stopped|suspended|starting/i.test(fatalMsg)
    ) {
      return {
        ok: false,
        status: launch.status || 'error',
        httpStatus: launch.httpStatus,
        code: /starting/i.test(fatalMsg) ? 'session_not_ready' : (launch.code || 'SESSION_ERROR'),
        message: launch.message || 'ส่งลิงก์เข้าเซสชันไม่สำเร็จ',
        pasteMs,
        data: launch.data || null
      };
    }
  }

  const cdp = await mcpRequest('tools/call', {
    name: 'browser_cdp',
    arguments: {
      session_id: id,
      target: 'browser',
      method: 'Target.createTarget',
      params: { url },
      max_chars: 1000
    }
  }, {
    timeoutMs: Math.max(1000, Math.min(opts.timeoutMs || 8000, 8000)),
    signal: opts.signal
  });
  const pasteMs = Date.now() - t0;
  if (!cdp.ok) {
    return { ...cdp, pasteMs };
  }
  const targetId = String((cdp.data && cdp.data.data && cdp.data.data.targetId) || (cdp.data && cdp.data.targetId) || '');
  const tabId = targetId.length >= 6 ? ('t' + targetId.slice(0, 6).toLowerCase()) : ((cdp.data && cdp.data.tab_id) || null);
  return {
    ok: true,
    status: 'ok',
    httpStatus: cdp.httpStatus,
    pasteMs,
    method: 'cdp_create_target',
    singleTab: false,
    data: {
      status: 'ok',
      tab_id: tabId,
      targetId: targetId || null,
      paste_ms: pasteMs,
      method: 'cdp_create_target'
    }
  };
}

async function callTool(name, args = {}, opts = {}) {
  if (name === 'browser_tabs' && args && args.action === 'new' && typeof args.url === 'string' && args.url.trim()) {
    return pasteOpenUrl(args.session_id, args.url, opts);
  }
  if (name === 'browser_navigate' && args && typeof args.url === 'string' && args.url.trim()) {
    if (!args.tab_id) {
      return pasteOpenUrl(args.session_id, args.url, opts);
    }
    const url = cleanTargetUrl(args.url);
    if (!url) {
      return { ok: false, code: 'INVALID_TARGET_URL', message: 'ลิงก์ต้องเป็น http:// หรือ https:// ที่ถูกต้อง' };
    }
    const t0 = Date.now();
    const nav = await mcpRequest('tools/call', {
      name: 'browser_cdp',
      arguments: {
        session_id: args.session_id,
        tab_id: args.tab_id,
        method: 'Page.navigate',
        params: { url },
        max_chars: 1000
      }
    }, opts);
    return { ...nav, pasteMs: Date.now() - t0 };
  }
  return mcpRequest('tools/call', { name, arguments: args }, opts);
}

async function evaluate(sessionId, expression, opts = {}) {
  const args = {
    session_id: sessionId,
    expression,
    world: opts.world || 'main',
    await_promise: opts.await_promise !== false
  };
  if (opts.tab_id) args.tab_id = opts.tab_id;
  if (opts.frame_id) args.frame_id = opts.frame_id;
  if (opts.max_chars) args.max_chars = opts.max_chars;
  return callTool('browser_evaluate', args, opts);
}

function evaluationValue(reply, protocol) {
  if (!reply || !reply.ok) return null;
  const queue = [reply.data, reply.text];
  for (let i = 0; i < queue.length && i < 24; i++) {
    const value = queue[i];
    if (value && typeof value === 'object') {
      if (!protocol || value.protocol === protocol) {
        if (value.protocol || (!('data' in value && typeof value.data === 'string') && !('status' in value && 'tab_id' in value))) {
          return value;
        }
      }
      for (const key of ['value', 'result', 'evaluation', 'text', 'data', 'json']) {
        if (value[key] != null) queue.push(value[key]);
      }
    } else if (typeof value === 'string') {
      try {
        queue.push(JSON.parse(value));
      } catch {
        const start = value.indexOf('{');
        const end = value.lastIndexOf('}');
        if (start >= 0 && end > start) {
          try { queue.push(JSON.parse(value.slice(start, end + 1))); } catch {}
        }
      }
    }
  }
  return null;
}

let lastPreconnect = 0;
function preconnect(count = 1) {
  const now = Date.now();
  if (now - lastPreconnect < 800) return Promise.resolve(false);
  lastPreconnect = now;
  let target;
  try { target = new URL(v7Base() + '/image'); } catch { return Promise.resolve(false); }
  const agent = AGENTS[target.protocol];
  if (!agent) return Promise.resolve(false);
  const wanted = Math.max(1, Math.min(2, count));
  const missing = wanted - dropStaleSockets(agent);
  if (missing <= 0) return Promise.resolve(true);
  const tasks = [
    v7Request('GET', '/image', null, { auth: false, timeoutMs: 2000 }).then((r) => !!r.ok, () => false)
  ];
  const sid = defaultSessionId();
  if (sid && apiKey()) {
    tasks.push(
      mcpRequest('tools/call', { name: 'browser_tabs', arguments: { session_id: sid, action: 'list' } }, { timeoutMs: 2200 })
        .then((r) => !!r.ok, () => false)
    );
  }
  return Promise.all(tasks).then((results) => results.some(Boolean));
}

// อุ่นสาย TLS keep-alive ไปยัง api.browser.lol ล่วงหน้าทันทีเมื่อโหลดโมดูลเพื่อลด Cold Start
try {
  const warmTimer = setTimeout(() => { preconnect(1).catch(() => {}); }, 1);
  if (typeof warmTimer.unref === 'function') warmTimer.unref();
} catch {}

async function v7SessionData(id, opts = {}) {
  const q = id ? '?id=' + encodeURIComponent(id) : '';
  return v7Request('GET', '/vm/data' + q, null, opts);
}

async function v7SessionCreate(o = {}, opts = {}) {
  const body = { browser: o.browser || 'chrome' };
  if (o.url) body.url = o.url;
  if (o.language) body.language = o.language;
  if (o.layout) body.layout = o.layout;
  if (o.timezone) body.timezone = o.timezone;
  if (o.country) body.country = o.country;
  if (o.profile_id) body.profile_id = o.profile_id;
  if (o.egress) body.egress = o.egress;
  if (o.shareLanguage) body.shareLanguage = o.shareLanguage;
  if (typeof o.shareExtensions === 'boolean') body.shareExtensions = o.shareExtensions;
  if (o.callbackUrl) body.callbackUrl = o.callbackUrl;
  if (o.idempotencyKey) body.idempotencyKey = o.idempotencyKey;
  return v7Request('POST', '/vm/create', body, opts);
}

async function v7SessionRemove(id, opts = {}) {
  validateSessionId(id);
  return v7Request('POST', '/vm/remove', { id }, opts);
}

async function existingSession(requestedId, opts = {}) {
  if (requestedId != null && typeof requestedId !== 'string') {
    throw sessionError('SESSION_ID_INVALID', 'session_id ต้องเป็นข้อความ');
  }
  const id = (requestedId || '').trim() || defaultSessionId();
  validateSessionId(id);
  const v7 = await v7SessionData(id, { timeoutMs: Math.min(12000, opts.timeoutMs || 12000), signal: opts.signal });
  if (!v7.ok) {
    throw sessionError(v7.code || 'SESSION_LOOKUP_FAILED', v7.message || 'ตรวจสอบเซสชันผ่าน API v7 ไม่สำเร็จ');
  }
  const rows = Array.isArray(v7.data && v7.data.data) ? v7.data.data : [];
  const row = rows[0] || null;
  if (!row) {
    throw sessionError('NO_EXISTING_SESSION', 'ไม่พบเซสชันเดิมใน Browser.LOL กรุณาตรวจ session_id');
  }
  if (row.status === 'running') {
    return {
      session_id: id,
      session_status: 'running',
      drivable: true,
      live_view_url: 'https://browser.lol/en/viewer?id=' + encodeURIComponent(id),
      v7: row
    };
  }
  if (row.status === 'starting') {
    throw Object.assign(sessionError('session_not_ready', 'เซสชันกำลังเริ่มทำงาน กรุณารอสักครู่'), { retryable: true });
  }
  throw sessionError('NO_EXISTING_SESSION', 'เซสชันเดิมไม่ได้กำลังทำงานอยู่ (status: ' + row.status + ')');
}

module.exports = {
  v7Base,
  mcpEndpoint,
  v7Request,
  v7SessionData,
  v7SessionCreate,
  v7SessionRemove,
  v7SessionLaunch: (id, url, opts = {}) => pasteOpenUrl(id, url, opts),
  pasteOpenUrl,
  acquireSessionSlot,
  activeSessionCount,
  v7Quota: (opts = {}) => v7Request('GET', '/user/quota', null, opts),
  v7Account: (opts = {}) => v7Request('GET', '/user/api', null, opts),
  v7Images: (opts = {}) => v7Request('GET', '/image', null, { ...opts, auth: false }),
  mcpRequest,
  callTool,
  evaluate,
  evaluationValue,
  apiKey,
  configuredSessionId,
  defaultSessionId,
  validateSessionId,
  existingSession,
  preconnect
};
