----------------------------------------------------------
-- 📦 Services
----------------------------------------------------------
-- รอเกมโหลดเสร็จก่อน (รีโมทของเกมจะได้มีครบ ไม่ต้องรอทีละอัน)
if not game:IsLoaded() then
    game.Loaded:Wait()
end

local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local MarketplaceService = game:GetService("MarketplaceService")
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local GuiService = game:GetService("GuiService")
local LocalPlr = Players.LocalPlayer

----------------------------------------------------------
-- ⏱️ แบ่งงานตอนโหลดเป็นช่วงสั้นๆ (กันเกมค้าง แต่ยังโหลดเสร็จเร็วสุด)
--   Yield() = ถ้าทำงานติดกันมาเกินช่วงที่กำหนด (loadSlice) แล้ว จะพักให้เกมวาดจอ 1 เฟรม แล้วทำต่อ
--             ยังไม่เกิน = ทำต่อทันที ไม่เสียเวลารอ (ของเดิมรอ 1 เฟรมทุก Section ไม่ว่าจะงานน้อยแค่ไหน)
--   ช่วงทำงานยาวแค่ไหน ปรับเองตามเครื่อง: ทำงานต่อได้ 1.5 เท่าของเวลาที่เกมใช้วาดจอ 1 เฟรม
--     (เครื่องเร็ว 0.025 วิ / เครื่องช้าวาดจอนาน ยืดได้ถึง 0.05 วิ)
--     ของเดิมทำรวดละ 0.05-0.1 วิ = จอค้างทีละ 3-6 เฟรมตลอดช่วงโหลด / แบบใหม่เกมยังขยับลื่นระหว่างโหลด
--   โหลดเสร็จแล้ว Yield() จะไม่ทำอะไรเลย
----------------------------------------------------------
local LOAD_SLICE_MIN = 0.025
local LOAD_SLICE_MAX = 0.05
local loadSlice = LOAD_SLICE_MIN
local loading = true
local holdYield = false   -- เพิ่งสร้าง Section แต่ยังไม่ได้ใส่ของชิ้นแรก (ห้ามพัก ไม่งั้น Section ของ WindUI จะพัง)
local sliceStart = os.clock()

local function Yield()
    if loading and not holdYield and os.clock() - sliceStart >= loadSlice then
        local frameTime = tonumber((task.wait())) or 0
        loadSlice = math.clamp(frameTime * 1.5, LOAD_SLICE_MIN, LOAD_SLICE_MAX)
        sliceStart = os.clock()
    end
end

-- งานที่รอทำตอนสร้าง UI ครบแล้ว (ก่อนโหลด Config) เช่น ใส่รายชื่อยูนิต / ของในกระเป๋า
local AfterLoad = {}

----------------------------------------------------------
-- 🖼️ รูปพื้นหลัง: เริ่มดาวน์โหลดตั้งแต่เปิดสคริป (พร้อมกับโหลด WindUI)
--   รันครั้งแรกจะได้ไม่ต้องรอดาวน์โหลดตอนท้าย / รอบต่อไปใช้ไฟล์ในเครื่องเลย
----------------------------------------------------------
local DefaultBackground = "https://img1.pic.in.th/images/5573a1c232fced2ac60da9136ae9ea30.jpg"
local bgDownloading = {}   -- รูปที่กำลังดาวน์โหลดอยู่ (กันดาวน์โหลดรูปเดียวกันซ้อนกัน)

-- ชื่อไฟล์มาจากลิงก์ (ลิงก์เดิม = ไฟล์เดิม รันรอบหน้าไม่ต้องดาวน์โหลดใหม่)
local function backgroundPath(url)
    return "XEPHEX HUB/bg_" .. url:gsub("[^%w]", ""):sub(-40) .. ".png"
end

-- มีไฟล์ในเครื่องแล้ว = ใช้เลย / ไม่มี = ดาวน์โหลดเก็บไว้ (สำเร็จ = true)
local function downloadBackground(url)
    local path = backgroundPath(url)
    while bgDownloading[path] do
        task.wait()
    end

    local hasFile = false
    pcall(function() hasFile = isfile(path) end)
    if hasFile then
        return true
    end

    bgDownloading[path] = true
    pcall(function()
        if isfolder and makefolder and not isfolder("XEPHEX HUB") then
            makefolder("XEPHEX HUB")
        end
    end)
    local ok, data = pcall(game.HttpGet, game, url)
    local saved = ok and type(data) == "string" and #data > 0 and pcall(writefile, path, data)
    bgDownloading[path] = nil
    return saved == true
end

if writefile and getcustomasset then
    task.spawn(downloadBackground, DefaultBackground)
end

----------------------------------------------------------
-- 🏷️ ชื่อเกม
--   ถามเว็บ Roblox ไปพร้อมกับโหลด UI (ไม่ต้องรอทีละอย่าง)
--   ได้ชื่อมาแล้วค่อยเปลี่ยนชื่อหน้าต่างให้ทีหลัง
----------------------------------------------------------
local gameName = "Climb For Animals Eggs"
local Window   -- สร้างจริงในส่วน "🪟 Window" ข้างล่าง

task.spawn(function()
    local success, gameInfo = pcall(function()
        return MarketplaceService:GetProductInfo(game.PlaceId)
    end)
    if success and gameInfo and gameInfo.Name then
        gameName = gameInfo.Name
        if Window then
            pcall(function() Window:SetTitle("XEPHEX HUB  | " .. gameName) end)
        end
    end
end)

----------------------------------------------------------
-- ⚡ โหลด WindUI แบบเร็ว (สำคัญมากกับมือถือสเปกต่ำ)
--   1) ล็อก WindUI ไว้ที่รุ่น 1.6.66 + ไอคอนชุด lucide ชุดเดียว (ชุดอื่นไม่ได้ใช้ ไม่ต้องโหลด)
--   2) แก้จุดที่ทำให้ WindUI ช้า/ค้างตอนสร้าง UI เยอะๆ (ดูรายการ PATCHES ข้างล่าง)
--   3) รวม WindUI + ไอคอน เป็นไฟล์เดียว เก็บไว้ในเครื่อง (XEPHEX HUB/cache)
--      รันรอบหน้าอ่านไฟล์เดียวจบ ไม่ต้องดาวน์โหลด ไม่ต้องแก้โค้ดซ้ำ
--   แก้จุดไหนไม่ได้ (โค้ดไม่ตรง) จะข้ามแค่จุดนั้น / ถ้าพังทั้งหมดจะโหลด WindUI แบบปกติให้เอง สคริปไม่พัง
----------------------------------------------------------
local WindUI
do
    local WINDUI_VERSION = "1.6.66"
    local FAST_BUILD = 2   -- แก้ PATCHES เมื่อไหร่ ให้เพิ่มเลขนี้ (สคริปจะสร้างไฟล์รวมใหม่ให้เอง) / ข้อที่เพิ่มใหม่ใส่ since = เลขนี้
    local ICONS_COMMIT = "46d30c19ba7bc601d6ec794a48dc3a89568b1eec"

    local CACHE_FOLDER = "XEPHEX HUB/cache"
    local function fastPath(build)
        return CACHE_FOLDER .. "/WindUI-" .. WINDUI_VERSION .. "-fast" .. build .. ".lua"
    end
    local FAST_FILE = fastPath(FAST_BUILD)

    local WINDUI_URL = "https://github.com/Footagesus/WindUI/releases/download/" .. WINDUI_VERSION .. "/main.lua"
    local ICONS_URL = "https://raw.githubusercontent.com/Footagesus/Icons/" .. ICONS_COMMIT .. "/Main-v2.lua"
    local LUCIDE_URL = "https://raw.githubusercontent.com/Footagesus/Icons/" .. ICONS_COMMIT .. "/lucide/dist/Icons.lua"

    local canUseFiles = (readfile and writefile and isfile and isfolder and makefolder) and true or false

    local function readCache(path)
        if not canUseFiles then
            return nil
        end
        local ok, text = pcall(function()
            if isfile(path) then
                return readfile(path)
            end
            return nil
        end)
        if ok and type(text) == "string" and #text > 0 then
            return text
        end
        return nil
    end

    local function writeCache(path, text)
        if not canUseFiles then
            return
        end
        pcall(function()
            if not isfolder("XEPHEX HUB") then makefolder("XEPHEX HUB") end
            if not isfolder(CACHE_FOLDER) then makefolder(CACHE_FOLDER) end
            writefile(path, text)
        end)
    end

    -- mustHave = ข้อความที่ต้องมีในไฟล์ (กันได้หน้าเว็บ error มาแทนโค้ดจริง)
    local function download(url, mustHave)
        local ok, text = pcall(game.HttpGet, game, url)
        if ok and type(text) == "string" and text:find(mustHave, 1, true) then
            return text
        end
        return nil
    end

    -- แทนข้อความแบบตรงตัว ต้องเจอ "ที่เดียวพอดี" เท่านั้น (ไม่เจอ / เจอหลายที่ = nil จะได้ไม่แก้ผิดที่)
    local function replaceOnce(text, old, new)
        local first, last = text:find(old, 1, true)
        if not first or text:find(old, last + 1, true) then
            return nil
        end
        return text:sub(1, first - 1) .. new .. text:sub(last + 1)
    end

    local function replaceAll(text, edits)
        for _, edit in ipairs(edits) do
            text = text and replaceOnce(text, edit[1], edit[2])
        end
        return text
    end

    ------------------------------------------------------
    -- จุดที่แก้ใน WindUI 1.6.66 (แต่ละข้อ แก้ได้ครบทุกบรรทัด = ใช้ / ไม่ครบ = ข้ามข้อนั้นทั้งข้อ)
    ------------------------------------------------------
    local PATCHES = {
        -- [ตัวการหลักที่ทำให้ค้าง] ทุกครั้งที่สร้างข้อความใหม่ 1 อัน WindUI จะตั้งฟอนต์ใหม่ให้ "ข้อความทุกอันที่เคยสร้าง"
        -- UI นี้มีข้อความเกือบพันอัน = ตั้งฟอนต์ซ้ำหลายแสนครั้งตอนโหลด -> แก้ให้ตั้งเฉพาะอันที่สร้างใหม่
        {
            name = "font",
            edits = {
                {
                    "function r.AddFontObject(u)\ntable.insert(r.FontObjects,u)\nr.UpdateFont(r.Font)\nend",
                    "function r.AddFontObject(u)\ntable.insert(r.FontObjects,u)\nlocal f=u.FontFace\nif f.Family~=r.Font then u.FontFace=Font.new(r.Font,f.Weight,f.Style) end\nend",
                },
            },
        },

        -- รูปโปรไฟล์มุมซ้ายล่าง: เดิมถามเว็บ Roblox แล้วนั่งรอคำตอบก่อนสร้างหน้าต่าง -> ใช้ลิงก์ rbxthumb (เกมโหลดรูปเองทีหลัง ไม่ต้องรอ)
        {
            name = "avatar",
            edits = {
                {
                    "f=ak:GetUserThumbnailAsync(",
                    "f=(function(i)return\"rbxthumb://type=AvatarHeadShot&id=\"..tostring(i)..\"&w=420&h=420\"end)(",
                },
            },
        },

        -- Dropdown: เดิมสร้างปุ่มตัวเลือก "ทุกอัน" ทันทีที่สร้าง / Select / Refresh (ทั้งที่ยังไม่มีใครเปิดดู)
        -- -> จำค่าไว้ก่อน แล้วค่อยสร้างรายการตอนกดเปิดครั้งแรก (ค่าที่เลือก + Callback ทำงานเหมือนเดิมทุกอย่าง)
        {
            name = "dropdown-lazy",
            edits = {
                {
                    "function as.Refresh(au,av)\nif ao.Window.Destroyed then\nreturn\nend",
                    "function as.Refresh(au,av)\nif ao.Window.Destroyed then\nreturn\nend\n"
                        .. "if not ap.UIElements.MenuCanvas.Visible then\n"
                        .. "if ap.Multi and typeof(ap.Value)==\"string\" then\n"
                        .. "for _,x in next,av do\nif x.Type~=\"Divider\"then\n"
                        .. "for _,i in next,ap.Values or av do\n"
                        .. "if typeof(i)==\"table\"then\nif i.Title==ap.Value then ap.Value={i} end\n"
                        .. "elseif i==ap.Value then\nap.Value={ap.Value}\nend\nend\nbreak\nend\nend\nend\n"
                        .. "as.__dirty=true\nCallback()\nap.Values=av\nreturn\nend\n"
                        .. "return as.__build(au,av)\nend\n"
                        .. "function as.__build(au,av)\nas.__dirty=false\nif ao.Window.Destroyed then\nreturn\nend",
                },
                {
                    ")\nCallback()\n\nap.Values=av\nend\n\nas:Refresh(ap.Values)",
                    ")\nif as.__silent then as:Display() else Callback() end\n\nap.Values=av\nend\n\nas:Refresh(ap.Values)",
                },
                {
                    "RecalculateListSize()\nRecalculateCanvasSize()\n\nfunction as.Open(au)\nif not ap.Locked then\nap.UIElements.Menu.Visible=true",
                    "if not as.__dirty then\nRecalculateListSize()\nRecalculateCanvasSize()\nend\n\n"
                        .. "function as.Open(au)\nif not ap.Locked then\n"
                        .. "if as.__dirty then\nas.__silent=true\nlocal ok,err=pcall(as.__build,as,ap.Values)\nas.__silent=false\n"
                        .. "if not ok then warn(err) end\nend\n"
                        .. "ap.UIElements.Menu.Visible=true",
                },
            },
        },

        -- Dropdown: เดิมวัดขนาดรายการใหม่ทุกครั้งที่เพิ่มตัวเลือก 1 อัน (บังคับเกมคำนวณเลย์เอาต์ซ้ำๆ) -> วัดครั้งเดียวตอนเพิ่มครบ
        {
            name = "dropdown-items",
            edits = {
                {
                    "ap.Tabs[aw]=ay\n\nas:Display()\n\nif ar==\"Dropdown\"then",
                    "ap.Tabs[aw]=ay\n\nif ar==\"Dropdown\"then",
                },
                {
                    "Callback(ax.Callback or function()end)\nend)\nend\n\nRecalculateCanvasSize()\nRecalculateListSize()\nelse a.load'M'",
                    "Callback(ax.Callback or function()end)\nend)\nend\n\nelse a.load'M'",
                },
                {
                    "ap.UIElements.MenuCanvas.Size=UDim2.new(\n0,\nap.MenuWidth+6+6+5+5+18+6+6,",
                    "RecalculateCanvasSize()\nRecalculateListSize()\nap.UIElements.MenuCanvas.Size=UDim2.new(\n0,\nap.MenuWidth+6+6+5+5+18+6+6,",
                },
            },
        },

        -- Dropdown ช่องค้นหา: เดิมวัดขนาดใหม่ทุกตัวเลือก ต่อการพิมพ์ 1 ตัวอักษร -> วัดครั้งเดียวต่อการพิมพ์
        {
            name = "dropdown-search",
            edits = {
                {
                    "ay.UIElements.TabItem.Visible=false\nend\nRecalculateListSize()\nRecalculateCanvasSize()\nend\nend,true)",
                    "ay.UIElements.TabItem.Visible=false\nend\nend\nRecalculateListSize()\nRecalculateCanvasSize()\nend,true)",
                },
            },
        },

        -- Dropdown: เดิมทุกอันคำนวณตำแหน่งเมนูใหม่ทุกครั้งที่เลื่อนหน้าจอ (ทั้งที่เมนูปิดอยู่)
        -- -> คำนวณเฉพาะตอนเมนูเปิด (แก้บั๊กเดิมที่ฟังก์ชันนี้เป็น global ทำให้ทุกอันใช้ตัวของอันสุดท้ายด้วย)
        {
            name = "dropdown-position",
            edits = {
                {
                    "function UpdatePosition()\nlocal at=ap.UIElements.Dropdown or ap.DropdownFrame.UIElements.Main",
                    "local function UpdatePosition()\nif not ap.UIElements.MenuCanvas.Visible then return end\nlocal at=ap.UIElements.Dropdown or ap.DropdownFrame.UIElements.Main",
                },
            },
        },

        -- Dropdown: เดิมแตะจอที่ไหนก็ตาม ทุก Dropdown จะเช็กตำแหน่งนิ้ว -> เช็กเฉพาะอันที่เปิดอยู่
        {
            name = "dropdown-tap",
            edits = {
                {
                    "ak.AddSignal(af.InputBegan,function(au)\nif\nau.UserInputType==Enum.UserInputType.MouseButton1",
                    "ak.AddSignal(af.InputBegan,function(au)\nif not ap.Opened then return end\nif\nau.UserInputType==Enum.UserInputType.MouseButton1",
                },
            },
        },

        -- ทุกปุ่ม/สวิตช์ เดิมสร้างเลเยอร์ซ่อนไว้ 5 ชั้น + ไอคอนกุญแจ (ล็อก / ไฮไลต์ / เอฟเฟกต์ตอนชี้) ทั้งที่แทบไม่ได้ใช้
        -- -> สร้างตอนถูกใช้ครั้งแรกแทน (ลดจำนวนของที่ต้องสร้างตอนโหลดไปเกือบครึ่ง)
        {
            name = "element-layers",
            apply = function(code)
                local startMark = "local as=aa.Image(\"lock\",\"lock\",0,ag.Window.Folder,\"Lock\",false)"
                local endMark = "local d,f=ac(ah.UICorner,\"Squircle\",{"
                local first = code:find(startMark, 1, true)
                local last = first and code:find(endMark, first, true)
                if not (first and last) or code:find(startMark, first + 1, true) then
                    return nil
                end

                -- กรอบใสที่ครอบปุ่มยังสร้างทันทีเหมือนเดิม (เลย์เอาต์จะได้เหมือนเดิมเป๊ะ)
                local frameCode = "local au=ab(\"Frame\",{\nSize=UDim2.new(1,ah.UIPadding*2,1,ah.UIPadding*2),\n"
                    .. "BackgroundTransparency=1,\nAnchorPoint=Vector2.new(0.5,0.5),\nPosition=UDim2.new(0.5,0,0.5,0),\n"
                    .. "ZIndex=9999999,\n})\n"
                local layers = replaceAll(code:sub(first, last - 1), {
                    { frameCode, "" },
                    { "local as=", "as=" },
                    { "local at=", "at=" },
                    { "local av,aw=", "av,aw=" },
                    { "},nil,true)local\n\nax=", "},nil,true)\nax=" },
                    { "local ay,az=", "ay,az=" },
                    { "},nil,true)local\n\naA=", "},nil,true)\naA=" },
                    { "local aB,b=", "aB,b=" },
                })
                if not layers then
                    return nil
                end

                code = code:sub(1, first - 1)
                    .. frameCode
                    .. "local as,at,av,aw,ax,ay,az,aA,aB,b,__xLayerShape\n"
                    .. "local function __xLayers()\nif av then return end\n"
                    .. layers
                    .. "if __xLayerShape then aw:SetType(__xLayerShape) az:SetType(__xLayerShape) b:SetType(__xLayerShape) end\n"
                    .. "ah.UIElements.Locked=av\nend\n"
                    .. code:sub(last)

                return replaceAll(code, {
                    { "aa.AddSignal(d.MouseEnter,function()\nif am then\n", "aa.AddSignal(d.MouseEnter,function()\nif am then\n__xLayers()\n" },
                    { "aa.AddSignal(d.InputEnded,function()\nif am then\n", "aa.AddSignal(d.InputEnded,function()\nif am and aB then\n" },
                    { "function ah.Lock(g,h)\nam=false\nav.Active=true", "function ah.Lock(g,h)\nam=false\n__xLayers()\nav.Active=true" },
                    { "function ah.Unlock(g)\nam=true\nav.Active=false\nav.Visible=false\nend", "function ah.Unlock(g)\nam=true\nif av then\nav.Active=false\nav.Visible=false\nend\nend" },
                    { "function ah.Highlight(g)\nlocal h=ab(\"UIGradient\",{", "function ah.Highlight(g)\n__xLayers()\nlocal h=ab(\"UIGradient\",{" },
                    { "f:SetType(h)\naw:SetType(h)\naz:SetType(h)\n\nb:SetType(h)", "f:SetType(h)\n__xLayerShape=h\nif aw then\naw:SetType(h)\naz:SetType(h)\nb:SetType(h)\nend" },
                })
            end,
        },

        -- ทุกปุ่ม/สวิตช์ เดิมสร้างแถบ "ป้าย (Tags)" ซ่อนไว้ทุกอัน (3 ชิ้น + ตัวดักขนาด) ทั้งที่สคริปนี้ไม่ได้ใช้ป้ายเลย
        -- -> สร้างเฉพาะอันที่ใส่ Tags มาจริงๆ (ตอนซ่อนอยู่มันไม่กินที่ หน้าตาเลยเหมือนเดิมทุกอย่าง)
        {
            name = "element-tags",
            edits = {
                {
                    "ab(\"ScrollingFrame\",{\nSize=UDim2.new(1,0,0,0),\nAutomaticSize=\"Y\",\nLayoutOrder=-99,",
                    "(next(ag.Tags or{})~=nil or nil)and ab(\"ScrollingFrame\",{\nSize=UDim2.new(1,0,0,0),\nAutomaticSize=\"Y\",\nLayoutOrder=-99,",
                },
                {
                    "ab(\"Frame\",{\nName=\"Space\",\nSize=UDim2.new(1,0,0,0),\nBackgroundTransparency=1,\nVisible=false,\n}),\naq,\nar,",
                    "(next(ag.Tags or{})~=nil or nil)and ab(\"Frame\",{\nName=\"Space\",\nSize=UDim2.new(1,0,0,0),\nBackgroundTransparency=1,\nVisible=false,\n}),\naq,\nar,",
                },
                {
                    "aa.AddSignal(\nah.UIElements.Container.TitleFrame.TitleFrame.ScrollingFrame.UIListLayout:GetPropertyChangedSignal",
                    "if next(ag.Tags or{})~=nil then aa.AddSignal(\nah.UIElements.Container.TitleFrame.TitleFrame.ScrollingFrame.UIListLayout:GetPropertyChangedSignal",
                },
                {
                    "ah.UIElements.Container.TitleFrame.TitleFrame.ScrollingFrame.UIListLayout.AbsoluteContentSize.Y\n/ag.ParentConfig.UIScale\n)\nend\n)",
                    "ah.UIElements.Container.TitleFrame.TitleFrame.ScrollingFrame.UIListLayout.AbsoluteContentSize.Y\n/ag.ParentConfig.UIScale\n)\nend\n) end",
                },
            },
        },

        -- ปุ่มที่มีเอฟเฟกต์ตอนชี้: เดิมทุกครั้งที่เมาส์/นิ้วแตะเข้าปุ่ม จะผูกตัวดักการขยับเมาส์เพิ่มอีก 1 ตัว (ไม่เคยถอดออก)
        --   ใช้ไปนานๆ ตัวดักพอกเป็นร้อย ขยับเมาส์ทีเดียวทำงานซ้ำเป็นร้อยรอบ (ยิ่งเปิดนานยิ่งหน่วง) -> ผูกครั้งเดียวพอ
        {
            name = "hover-once",
            since = 2,
            edits = {
                {
                    "if ah.Hover then\naa.AddSignal(d.MouseEnter,function()",
                    "if ah.Hover then\nlocal __xMoved=false\naa.AddSignal(d.MouseEnter,function()",
                },
                {
                    "aa.AddSignal(d.MouseMoved,function(g,h)\naB.HoverGradient.Offset=",
                    "if not __xMoved then\n__xMoved=true\naa.AddSignal(d.MouseMoved,function(g,h)\nif not aB then return end\naB.HoverGradient.Offset=",
                },
                {
                    "aA.HoverGradient.Offset=\nVector2.new(((g-d.AbsolutePosition.X)/d.AbsoluteSize.X)-0.5,0)\nend)\n",
                    "aA.HoverGradient.Offset=\nVector2.new(((g-d.AbsolutePosition.X)/d.AbsoluteSize.X)-0.5,0)\nend)\nend\n",
                },
            },
        },
    }

    -- ตรงที่ WindUI โหลดตัวจัดการไอคอน / ตรงที่ตัวจัดการไอคอนดาวน์โหลดไอคอนแต่ละชุด -> ใช้ไอคอนที่ฝังไว้ในไฟล์แทน
    local WIND_ICON_LOADER = "loadstring(\ngame.HttpGet and game:HttpGet(l)or h:GetAsync(l)\n)()"
    local ICON_EDITS = {
        { "return request and true or false", "return true" },
        { "return game:HttpGet(url)", "return __XEPHEX_ICON_PACK(url)" },
    }

    -- ใส่ไอคอน lucide ไว้ในไฟล์ WindUI เลย (ไม่ต้องดาวน์โหลด / ไม่ต้องอ่านไฟล์แยก)
    local function embedIcons(windCode, iconCode, lucideCode)
        iconCode = replaceAll(iconCode, ICON_EDITS)
        if not iconCode then
            return nil
        end
        local level = 1
        while lucideCode:find("]" .. string.rep("=", level) .. "]", 1, true) do
            level = level + 1
        end
        local open, close = "[" .. string.rep("=", level) .. "[", "]" .. string.rep("=", level) .. "]"
        local header = "local __XEPHEX_LUCIDE=" .. open .. "\n" .. lucideCode .. close .. "\n"
            .. "local function __XEPHEX_ICON_PACK(url)\n"
            .. "if string.find(url,\"/lucide/\",1,true) then return __XEPHEX_LUCIDE end\n"
            .. "return \"return {}\"\nend\n"
        windCode = replaceOnce(windCode, WIND_ICON_LOADER, "(function()\n" .. iconCode .. "\nend)()")
        return windCode and (header .. windCode)
    end

    -- แก้ 1 ข้อ (แก้ไม่ได้ = nil)
    local function applyPatch(code, patch)
        if patch.apply then
            local ok, out = pcall(patch.apply, code)
            return ok and out or nil
        end
        return replaceAll(code, patch.edits)
    end

    local function applyPatches(code)
        local skipped = {}
        for _, patch in ipairs(PATCHES) do
            local result = applyPatch(code, patch)
            if result then
                code = result
            else
                table.insert(skipped, patch.name)
            end
        end
        return code, skipped
    end

    -- ไฟล์รวมของรุ่นก่อน (FAST_BUILD - 1) แก้เพิ่มแค่ข้อใหม่ (since = FAST_BUILD) ก็ใช้ได้เลย
    --   ไม่ต้องดาวน์โหลด WindUI / ไอคอนใหม่ทั้งหมด (แก้ข้อใหม่ไม่ได้ = nil แล้วไปสร้างใหม่แบบเต็ม)
    local function upgradePrevFast()
        local code = FAST_BUILD > 1 and readCache(fastPath(FAST_BUILD - 1))
        if not code then
            return nil
        end
        for _, patch in ipairs(PATCHES) do
            if patch.since == FAST_BUILD then
                code = applyPatch(code, patch)
                if not code then
                    return nil
                end
            end
        end
        return code
    end

    -- ไฟล์ที่สคริปรุ่นก่อนเก็บไว้ (ใช้ตอนสร้างไฟล์รวมครั้งแรก แล้วลบทิ้ง)
    local OLD_FILES = { "WindUI.lua", "Icons.lua", "Lucide.lua" }

    local function readOld(name, mustHave)
        local text = readCache(CACHE_FOLDER .. "/" .. name)
        if text and text:find(mustHave, 1, true) then
            return text
        end
        return nil
    end

    -- สร้างไฟล์รวม (ครั้งแรกครั้งเดียว)
    --   useOld = ลองใช้ไฟล์เก่าในเครื่องก่อน / ไม่มีหรือใช้ไม่ได้ค่อยดาวน์โหลด (ดาวน์โหลดพร้อมกันทีเดียว)
    --   คืนค่า: โค้ดที่รวมแล้ว, ได้ใช้ไฟล์เก่าไหม
    local function buildFast(useOld)
        local got = {}
        local patched
        if useOld then
            got.icons = readOld("Icons.lua", "IconModule")
            got.lucide = readOld("Lucide.lua", "rbxassetid://")
            -- ตัวจัดการไอคอนเก่า ใช้ได้เฉพาะตอนแก้ได้ครบ
            if got.icons and not replaceAll(got.icons, ICON_EDITS) then
                got.icons = nil
            end
            -- WindUI เก่า ใช้ได้เฉพาะตอนแก้ได้ครบทุกข้อ (= รุ่นเดียวกัน) ไม่งั้นโหลดรุ่นที่ล็อกไว้ใหม่
            local oldWind = readOld("WindUI.lua", "WindUI")
            if oldWind and oldWind:find(WIND_ICON_LOADER, 1, true) then
                local code, skipped = applyPatches(oldWind)
                if #skipped == 0 then
                    patched = code
                end
            end
        end
        local usedOld = (patched or got.icons or got.lucide) and true or false

        local pending = 0
        local function fetch(key, url, mustHave)
            pending = pending + 1
            task.spawn(function()
                got[key] = download(url, mustHave)
                pending = pending - 1
            end)
        end
        if not patched then fetch("wind", WINDUI_URL, "WindUI") end
        if not got.icons then fetch("icons", ICONS_URL, "IconModule") end
        if not got.lucide then fetch("lucide", LUCIDE_URL, "rbxassetid://") end
        while pending > 0 do
            task.wait()
        end

        if not patched then
            if not got.wind then
                return nil
            end
            local skipped
            patched, skipped = applyPatches(got.wind)
            if #skipped > 0 then
                warn("[XEPHEX HUB] WindUI patch skipped: " .. table.concat(skipped, ", "))
            end
        end
        if not (got.icons and got.lucide) then
            return nil, usedOld
        end
        return embedIcons(patched, got.icons, got.lucide), usedOld
    end

    local function removeOldFiles()
        if not (canUseFiles and delfile) then
            return
        end
        for _, name in ipairs(OLD_FILES) do
            for _, path in ipairs({ CACHE_FOLDER .. "/" .. name, CACHE_FOLDER .. "/" .. name .. ".time" }) do
                pcall(function()
                    if isfile(path) then delfile(path) end
                end)
            end
        end
        -- ไฟล์รวมรุ่นก่อนๆ (ใช้ไม่ได้แล้ว ลบทิ้งไม่ให้รกเครื่อง)
        for build = 1, FAST_BUILD - 1 do
            local path = fastPath(build)
            pcall(function()
                if isfile(path) then delfile(path) end
            end)
        end
    end

    local function runWindUI(code)
        local fn = code and loadstring(code)
        if not fn then
            return nil
        end
        Yield()   -- แปลงโค้ดเสร็จ (ก้อนใหญ่สุด) พักให้จอขยับก่อน แล้วค่อยเริ่ม WindUI
        local ok, lib = pcall(fn)
        if ok and type(lib) == "table" and lib.CreateWindow then
            return lib
        end
        return nil
    end

    local fastCode = readCache(FAST_FILE)
    WindUI = runWindUI(fastCode)
    if not WindUI then
        -- มีไฟล์รวมรุ่นก่อน = แก้เพิ่มแค่ข้อใหม่ (เร็วสุด ไม่ต้องดาวน์โหลด)
        fastCode = upgradePrevFast()
        WindUI = runWindUI(fastCode)
        if not WindUI then
            local usedOld
            fastCode, usedOld = buildFast(true)
            WindUI = runWindUI(fastCode)
            if not WindUI and usedOld then
                -- ไฟล์เก่าในเครื่องใช้ไม่ได้ -> ดาวน์โหลดรุ่นที่ล็อกไว้มาสร้างใหม่
                fastCode = buildFast(false)
                WindUI = runWindUI(fastCode)
            end
        end
        if WindUI then
            writeCache(FAST_FILE, fastCode)
            removeOldFiles()
        end
    end
    if not WindUI then
        WindUI = loadstring(game:HttpGet(WINDUI_URL))()
    end
end

----------------------------------------------------------
-- 🌐 ภาษา (แก้ข้อความได้ที่นี่)
-- ไทยมีแต่ภาษาไทย / อังกฤษมีแต่ภาษาอังกฤษ (ยกเว้นชื่อยูนิต / ชื่อไอเทม ที่เป็นชื่อเฉพาะของเกม)
----------------------------------------------------------
local Translations = {
    th = {
        tab_log = "ข้อมูล",
        tab_main = "หลัก",
        tab_misc = "เบ็ดเตล็ด",
        tab_settings = "ตั้งค่า",

        hello = "สวัสดี ",
        config_loaded = "โหลดการตั้งค่าที่เซฟไว้แล้ว",

        sec_credit = "เครดิต",
        discord_desc = "ไว้คุยกันและถามปัญหา",
        discord_copied = "คัดลอกลิงก์ดิสคอร์ดแล้ว",
        youtube_desc = "ช่องยูทูป",
        youtube_copied = "คัดลอกลิงก์ยูทูปแล้ว",
        free_title = "สคริปก็ให้เล่นฟรีแล้ว",
        free_desc = "ฝากไปกดติดตามกันด้วยนะครับ",

        -- ใส่ของที่ดีที่สุด (Equip Best)

        -- ออโต้ทาวเวอร์ / ออโต้หาไอเทม

        -- Anime Adventures : ออโต้เพลย์
        aa_sec_play = "ออโต้เพลย์",
        aa_status_title = "สถานะ",
        aa_st_unsupported = "เกมนี้ไม่ใช่ Anime Adventures ฟังก์ชันในหน้านี้จะไม่ทำงาน",
        aa_st_lobby = "ตอนนี้อยู่ในล็อบบี้",
        aa_st_match = "ตอนนี้อยู่ในด่าน",
        aa_st_afk = "ตอนนี้อยู่ในห้อง AFK",
        aa_st_team = "อ่านทีมที่ใส่อยู่ได้ ",
        aa_st_units = " ตัว",
        aa_st_team_none = "ยังอ่านทีมไม่ได้ (รอเกมโหลดเสร็จแล้วกดรีเฟรชทีม)",
        aa_st_remote_ok = "รีโมทของเกม: พร้อมใช้",
        aa_st_remote_missing = "รีโมทของเกม: หาไม่เจอ",
        aa_st_hook_yes = "ดักคำสั่งของเกมได้ (มาโครอัดได้ครบทุกอย่าง และบล็อกคำสั่งของผู้เล่นตอนมาโครเล่นได้)",
        aa_st_hook_no = "ดักคำสั่งของเกมไม่ได้ (มาโครอัดได้เฉพาะวาง อัปเกรด และขาย ส่วนตอนเล่นยังล็อกจอและการบังคับได้ตามปกติ)",
        aa_start_title = "เริ่มเกมอัตโนมัติ",
        aa_start_desc = "โหวตเริ่มให้ทันทีที่ด่านพร้อม",
        aa_skip_title = "ข้ามเวฟอัตโนมัติ",
        aa_skip_desc = "เปิดการข้ามเวฟของเกมให้ ถ้าเปิดไม่ได้จะโหวตข้ามให้เองทุกเวฟ",
        aa_skip_unavailable = "เปิดข้ามเวฟอัตโนมัติไม่ได้: เกมรุ่นนี้ไม่มีคำสั่งข้ามเวฟที่สคริปรู้จัก (กดบันทึกข้อมูลเกมในหมวดลดแลค แล้วส่งไฟล์ให้คนทำสคริป)",
        aa_units_title = "ยูนิตที่ใช้",
        aa_units_desc = "เลือกยูนิตในทีมที่จะให้วางและอัปเกรด ไม่เลือกเลยคือใช้ทุกตัว",
        aa_units_refresh = "รีเฟรชทีม",
        aa_units_refresh_desc = "อ่านทีมที่ใส่อยู่ใหม่ (กดหลังเปลี่ยนทีม)",
        aa_units_loaded = "อ่านทีมแล้ว ",
        aa_need_team = "ยังอ่านทีมไม่ได้ รอเกมโหลดเสร็จแล้วกดรีเฟรชทีมอีกครั้ง",
        aa_placemode_title = "จุดวางยูนิต",
        aa_placemode_desc = "Path คือวางข้างทางเดินของศัตรู / My Position คือวางรอบจุดที่ตัวละครยืนอยู่ตอนเปิด",
        aa_pathpct_title = "ตำแหน่งบนทางเดิน (%)",
        aa_pathpct_desc = "0 คือจุดที่ศัตรูเกิด 100 คือฐานของเรา (ใช้กับจุดวางแบบ Path)",
        aa_cap_title = "จำนวนสูงสุดต่อยูนิต",
        aa_cap_desc = "วางยูนิตแต่ละตัวไม่เกินเท่านี้ และไม่เกินที่เกมกำหนด",
        aa_place_title = "วางยูนิตอัตโนมัติ",
        aa_place_desc = "วางยูนิตให้ทันทีที่เงินพอ",
        aa_place_stuck = "หาจุดวางไม่ได้แล้ว ลองเปลี่ยนจุดวางยูนิตหรือตำแหน่งบนทางเดิน",
        aa_uporder_title = "ลำดับการอัปเกรด",
        aa_uporder_desc = "Cheapest คืออัปตัวที่ราคาถูกสุดก่อน / Slot Order คืออัปตามลำดับช่องในทีมจนตันทีละตัว",
        aa_upcap_title = "อัปเกรดสูงสุดถึงขั้น",
        aa_upcap_desc = "0 คืออัปจนตัน",
        aa_upgrade_title = "อัปเกรดอัตโนมัติ",
        aa_upgrade_desc = "อัปเกรดให้ทันทีที่เงินพอ (ถ้าเปิดวางยูนิตอยู่จะวางให้ครบก่อน)",
        aa_skill_title = "ใช้สกิลอัตโนมัติ",
        aa_skill_desc = "กดสกิลของยูนิตให้ทุกครั้งที่คูลดาวน์ครบ",
        aa_end_title = "เมื่อจบด่าน",
        aa_end_desc = "None คือไม่ทำอะไร / Replay คือเล่นซ้ำ / Next Story คือไปด่านถัดไป / Lobby คือกลับล็อบบี้",
        aa_leave_title = "กลับล็อบบี้เมื่อถึงเวฟ",
        aa_leave_desc = "ใส่เลขเวฟ ถึงเวฟนี้แล้วจะกลับล็อบบี้ให้ (0 คือปิด)",
        aa_sellwave_title = "ขายยูนิตทั้งหมดเมื่อถึงเวฟ",
        aa_sellwave_desc = "ใส่เลขเวฟ ถึงเวฟนี้แล้วจะขายยูนิตทุกตัว และหยุดวางกับอัปเกรดจนกว่าจะเริ่มรอบใหม่ (0 คือปิด)",

        -- Anime Adventures : มาโคร
        aa_sec_macro = "มาโคร",
        aa_macro_status_title = "สถานะมาโคร",
        aa_macro_idle = "ยังไม่ได้อัดหรือเล่น",
        aa_macro_name_title = "ชื่อมาโคร",
        aa_macro_name_desc = "ชื่อไฟล์ที่จะเซฟตอนอัด เว้นว่างไว้จะใช้ชื่อด่านให้",
        aa_macro_record_title = "อัดมาโคร",
        aa_macro_record_desc = "เปิดแล้วเล่นตามปกติ ปิดเพื่อเซฟ (ต้องอยู่ในด่าน)",
        aa_macro_file_title = "ไฟล์มาโคร",
        aa_macro_file_desc = "Auto คือใช้ไฟล์ที่ชื่อตรงกับด่านที่กำลังเล่น",
        aa_macro_refresh = "รีเฟรชรายชื่อไฟล์",
        aa_macro_sync_title = "จังหวะการเล่น",
        aa_macro_sync_desc = "Wave + Time คือทำตามเวฟและเวลาเดิมที่อัดไว้ / Money คือทำตามลำดับทันทีที่เงินพอ",
        aa_macro_lock_title = "ล็อกการควบคุมตอนเล่นมาโคร",
        aa_macro_lock_desc = "ระหว่างมาโครเล่น จะหมุนจอ เดิน กดปุ่ม หรือส่งคำสั่งเองไม่ได้ กดหยุดแล้วกลับเป็นปกติทันที",
        aa_macro_play_title = "เล่นมาโคร",
        aa_macro_play_desc = "เล่นมาโครที่เลือกไว้ (ยังไม่เริ่มเกมก็กดเริ่มให้เอง) เปิดค้างไว้จะเล่นให้ทุกครั้งที่เริ่มด่าน",
        aa_macro_delete = "ลบไฟล์มาโครที่เลือก",
        aa_macro_need_match = "ต้องอยู่ในด่านก่อนถึงจะอัดมาโครได้",
        aa_macro_wait_match = "จะเริ่มเล่นมาโครให้เองตอนเข้าด่าน",
        aa_macro_busy = "กำลังอัดหรือเล่นมาโครอยู่",
        aa_macro_rec_started = "เริ่มอัดมาโครแล้ว",
        aa_macro_recording = "กำลังอัด ",
        aa_macro_steps = " ขั้นตอน",
        aa_macro_saved = "เซฟมาโครแล้ว: ",
        aa_macro_empty = "ยังไม่มีขั้นตอนให้เซฟ",
        aa_macro_nofile = "ตัวรันนี้เซฟไฟล์ไม่ได้ มาโครจะอยู่ได้ถึงแค่ตอนออกจากเซิร์ฟ",
        aa_macro_missing = "ไม่เจอไฟล์มาโคร: ",
        aa_macro_playing = "กำลังเล่น ",
        aa_macro_done = "เล่นครบทุกขั้นตอนแล้ว",
        aa_macro_stopped = "หยุดมาโครแล้ว",
        aa_macro_step_fail = "ข้ามขั้นตอนที่ทำไม่สำเร็จ: ",
        aa_macro_deleted = "ลบแล้ว: ",
        aa_lock_stop = "หยุด",

        -- Anime Adventures : เข้าด่านอัตโนมัติ
        aa_sec_join = "เข้าด่านอัตโนมัติ",
        aa_joinmode_title = "โหมด",
        aa_joinmode_desc = "โหมดที่จะเข้า (Challenge ไม่ต้องเลือกแมพและด่าน)",
        aa_joinworld_title = "แมพ",
        aa_joinworld_desc = "แมพที่จะเล่น",
        aa_joinact_title = "ด่าน",
        aa_joinact_desc = "ด่านในแมพที่เลือก",
        aa_joindiff_title = "ความยาก",
        aa_joindiff_desc = "ใช้กับโหมด Story (Infinite / Legend Stage / Raid เกมกำหนดเป็น Hard เสมอ)",
        aa_joinfriends_title = "เฉพาะเพื่อน",
        aa_joinfriends_desc = "เปิดห้องให้เข้าได้เฉพาะเพื่อน (คนอื่นเข้ามาเล่นด้วยไม่ได้)",
        aa_autojoin_title = "เข้าด่านอัตโนมัติ",
        aa_autojoin_desc = "อยู่ในล็อบบี้เมื่อไหร่ จะเปิดห้องแล้วเริ่มด่านที่เลือกให้",
        aa_execlink_title = "ลิงก์สคริป",
        aa_execlink_desc = "ลิงก์ของสคริปนี้ ไว้รันให้เองหลังย้ายเซิร์ฟ (ล็อบบี้ไปด่าน ด่านกลับล็อบบี้)",
        aa_autoexec_title = "รันสคริปเองหลังย้ายเซิร์ฟ",
        aa_autoexec_desc = "ต้องใส่ลิงก์สคริปก่อน และตัวรันต้องรองรับ",
        aa_exec_unsupported = "ตัวรันนี้รันสคริปเองหลังย้ายเซิร์ฟไม่ได้",
        aa_join_nolevel = "ยังไม่ได้เลือกด่าน",
        aa_join_nolobby = "ไม่เจอห้องว่าง",
        aa_join_going = "กำลังเข้าด่าน: ",
        aa_join_failed = "ยังเข้าด่านไม่ได้ กำลังลองใหม่",

        -- Anime Adventures : ของรางวัลและกาชา
        aa_sec_reward = "ของรางวัลและกาชา",
        aa_egg_title = "เก็บไข่อัตโนมัติ",
        aa_egg_desc = "ไข่โผล่เมื่อไหร่เก็บให้ทันที",
        aa_egg_none = "ตอนนี้เกมไม่มีอีเวนต์ไข่",
        aa_daily_title = "รับรางวัลรายวัน",
        aa_daily_desc = "รับรางวัลล็อกอินรายวันให้ตอนอยู่ในล็อบบี้",
        aa_banner_title = "ตู้กาชา",
        aa_banner_desc = "ตู้ที่จะสุ่ม (รายชื่อขึ้นตอนอยู่ในล็อบบี้)",
        aa_method_title = "วิธีสุ่ม",
        aa_method_desc = "gems คือสุ่ม 1 ครั้ง / gems10 คือสุ่ม 10 ครั้ง / ticket คือใช้ตั๋ว",
        aa_summon_count_title = "จำนวนรอบที่สุ่ม",
        aa_summon_count_desc = "สุ่มครบเท่านี้แล้วหยุดเอง",
        aa_summon_title = "สุ่มกาชา",
        aa_summon_desc = "สุ่มตามจำนวนรอบที่ตั้งไว้ (ใช้ได้ในล็อบบี้)",
        aa_summon_done = "สุ่มครบแล้ว",
        aa_summon_nobanner = "เลือกตู้กาชาก่อน",
        aa_only_lobby = "ใช้ได้เฉพาะตอนอยู่ในล็อบบี้",
        aa_unavailable = "เกมรุ่นนี้ไม่มีฟังก์ชันนี้",
        aa_no_command = "เกมรุ่นนี้ไม่มีคำสั่ง: ",

        -- Anime Adventures : ลดแลค
        aa_sec_perf = "ลดแลค",
        aa_lowfx_title = "ลดเอฟเฟกต์ของเกม",
        aa_lowfx_desc = "เปิดการตั้งค่าลดเอฟเฟกต์ของเกมให้ทีเดียว ปิดแล้วคืนค่าเดิม (เงาและลายพื้นผิวใช้ลดกราฟิกด้านล่าง)",
        aa_boost_title = "ลดกราฟิก",
        aa_boost_desc = "ลบลายพื้นผิว เงา และเอฟเฟกต์ของแมพ (ต้องเข้าเกมใหม่ถึงจะกลับมาเหมือนเดิม)",
        aa_norender_title = "ปิดการแสดงผล 3D",
        aa_norender_desc = "จอจะดำแต่เกมยังเล่นต่อ เครื่องลื่นขึ้นมากตอนฟาร์มทิ้งไว้",
        aa_fps_title = "จำกัด FPS",
        aa_fps_desc = "ลดความร้อนและประหยัดแบต (0 คือไม่ปรับ)",
        aa_debug_title = "บันทึกข้อมูลเกม",
        aa_debug_desc = "เซฟรายชื่อรีโมทและโครงสร้างของเกมลงไฟล์ ไว้ส่งให้คนทำสคริปตอนฟังก์ชันไหนไม่ทำงาน",
        aa_debug_saved = "เซฟแล้วที่ ",
        aa_debug_copied = "คัดลอกข้อมูลเกมแล้ว",

        sec_misc_tools = "เครื่องมือ",
        antiafk_title = "กันหลุด",
        antiafk_desc = "ยืนเฉยๆ ได้ ไม่โดนเตะ (ปกติ Roblox เตะตอนไม่ได้กดอะไรเลย 20 นาที)",
        bright_title = "แมพสว่าง",
        bright_desc = "เปิดไฟทั้งแมพ มองเห็นชัดขึ้น ปิดแล้วแสงกลับเป็นแบบเดิมทุกอย่าง",
        nofog_title = "ไม่มีหมอก",
        nofog_desc = "ลบหมอกในแมพออกให้หมด",
        noclip_title = "เดินทะลุ",
        noclip_desc = "เดินทะลุกำแพงและของต่างๆ ได้",
        infjump_title = "กระโดดไม่จำกัด",
        infjump_desc = "กระโดดซ้ำกลางอากาศได้เรื่อยๆ",
        float_height_title = "ความสูงตอนลอย",
        float_height_desc = "ใส่ตัวเลขว่าจะให้ลอยสูงแค่ไหน",
        float_title = "ลอยตัว",
        float_desc = "ลอยค้างอยู่กลางอากาศ",

        sec_theme = "ธีมสี",
        theme_title = "ธีม",
        theme_desc = "เลือกธีมสำเร็จรูป หรือปรับสีเองด้านล่าง ธีมจะสลับเป็นแบบกำหนดเองให้",
        color_desc = "เลือกสีแล้วจะสลับเป็นธีมแบบกำหนดเองให้เอง",
        color_background = "สีพื้นหลัง",
        color_accent = "สีแถบข้าง",
        color_text = "สีข้อความ",
        color_icon = "สีไอคอน",
        color_button = "สีปุ่ม",
        color_toggle = "สีสวิตช์และสไลเดอร์",

        sec_background = "รูปพื้นหลัง",
        bg_link_title = "ลิงก์รูปพื้นหลัง",
        bg_link_desc = "วางลิงก์รูป หรือไอดีรูปในเกม แล้วกดตกลง",
        bg_transparency = "ความโปร่งของรูป",
        bg_reset = "ใช้รูปเดิม",
        bg_reset_desc = "ล้างลิงก์แล้วกลับไปใช้รูปเริ่มต้น",
        bg_applied = "เปลี่ยนรูปพื้นหลังแล้ว",
        bg_failed = "โหลดรูปไม่ได้ ลองเช็กลิงก์ดูอีกที",

        sec_language = "ภาษา",
        language_title = "ภาษา",
        language_desc = "เปลี่ยนภาษาของเมนู",

        keybind_title = "ปุ่มเปิด/ปิดเมนู",
        keybind_desc = "เลือกปุ่มที่ใช้เปิดปิดเมนู",

        sec_jobid = "เซิร์ฟเวอร์",
        join_link_title = "ลิงก์เข้าเซิร์ฟ",
        join_link_desc = "คัดลอกลิงก์ไว้ส่งให้เพื่อนเข้าเซิร์ฟเดียวกัน",
        link_copied = "คัดลอกลิงก์แล้ว",
        jobid_missing = "หาไอดีของเซิร์ฟนี้ไม่เจอ",
        copy_jobid_title = "คัดลอกไอดีเซิร์ฟ",
        copy_jobid_desc = "คัดลอกไอดีของเซิร์ฟที่อยู่ตอนนี้",
        jobid_copied = "คัดลอกไอดีเซิร์ฟแล้ว",
        jobid_input_title = "ไอดีเซิร์ฟ",
        jobid_input_desc = "วางไอดีของเซิร์ฟที่อยากไป",
        teleport_title = "เข้าเซิร์ฟตามไอดี",
        teleport_desc = "วาร์ปไปเซิร์ฟที่ใส่ไอดีไว้",
        jobid_required = "ใส่ไอดีเซิร์ฟก่อนนะ",

    },
    en = {
        tab_log = "Log",
        tab_main = "Main",
        tab_misc = "Misc",
        tab_settings = "Settings",

        hello = "Hey ",
        config_loaded = "Saved settings loaded",

        sec_credit = "Credits",
        discord_desc = "Chat with us and ask questions",
        discord_copied = "Discord link copied",
        youtube_desc = "Our YouTube channel",
        youtube_copied = "YouTube link copied",
        free_title = "This script is free to use",
        free_desc = "Please consider following us",

        -- Equip Best

        -- Auto Tower / Auto Item

        -- Anime Adventures : Auto Play
        aa_sec_play = "Auto Play",
        aa_status_title = "Status",
        aa_st_unsupported = "This isn't Anime Adventures, so the features on this page won't work",
        aa_st_lobby = "You're in the lobby",
        aa_st_match = "You're in a match",
        aa_st_afk = "You're in the AFK room",
        aa_st_team = "Equipped team loaded: ",
        aa_st_units = " units",
        aa_st_team_none = "Couldn't read your team yet (wait for the game to load, then press Refresh Team)",
        aa_st_remote_ok = "Game remotes: ready",
        aa_st_remote_missing = "Game remotes: not found",
        aa_st_hook_yes = "Game commands can be intercepted (macros record everything and the player's commands are blocked during playback)",
        aa_st_hook_no = "Game commands cannot be intercepted (macros record place, upgrade and sell only; the screen and controls are still locked during playback)",
        aa_start_title = "Auto Start",
        aa_start_desc = "Votes to start as soon as the match is ready",
        aa_skip_title = "Auto Skip Wave",
        aa_skip_desc = "Turns on the game's own wave skipping, or votes to skip every wave if that can't be turned on",
        aa_skip_unavailable = "Auto Skip Wave couldn't be turned on: this version of the game has no skip command the script knows (use Save Game Info under Performance and send the file to the script maker)",
        aa_units_title = "Units to Use",
        aa_units_desc = "Pick which team units to place and upgrade. Leave it empty to use all of them",
        aa_units_refresh = "Refresh Team",
        aa_units_refresh_desc = "Read your equipped team again (press after changing your team)",
        aa_units_loaded = "Team loaded: ",
        aa_need_team = "Couldn't read your team yet. Wait for the game to load, then press Refresh Team",
        aa_placemode_title = "Placement Spot",
        aa_placemode_desc = "Path places next to the enemy path / My Position places around where your character stands when you turn it on",
        aa_pathpct_title = "Position on Path (%)",
        aa_pathpct_desc = "0 is where enemies spawn, 100 is your base (used with the Path placement spot)",
        aa_cap_title = "Max per Unit",
        aa_cap_desc = "Place at most this many of each unit, never more than the game allows",
        aa_place_title = "Auto Place",
        aa_place_desc = "Places units as soon as you can afford them",
        aa_place_stuck = "No free spot left. Try another placement spot or position on the path",
        aa_uporder_title = "Upgrade Order",
        aa_uporder_desc = "Cheapest upgrades the cheapest unit first / Slot Order maxes each unit in team slot order",
        aa_upcap_title = "Max Upgrade Level",
        aa_upcap_desc = "0 means upgrade all the way",
        aa_upgrade_title = "Auto Upgrade",
        aa_upgrade_desc = "Upgrades as soon as you can afford it (after everything is placed, if Auto Place is on)",
        aa_skill_title = "Auto Skill",
        aa_skill_desc = "Uses unit abilities every time the cooldown is up",
        aa_end_title = "When the Match Ends",
        aa_end_desc = "None does nothing / Replay plays again / Next Story goes to the next level / Lobby returns to the lobby",
        aa_leave_title = "Leave at Wave",
        aa_leave_desc = "Enter a wave number to return to the lobby at that wave (0 = off)",
        aa_sellwave_title = "Sell all units at wave",
        aa_sellwave_desc = "Enter a wave number. At that wave every unit is sold, and placing and upgrading stop until the next round (0 = off)",

        -- Anime Adventures : Macro
        aa_sec_macro = "Macro",
        aa_macro_status_title = "Macro Status",
        aa_macro_idle = "Not recording or playing",
        aa_macro_name_title = "Macro Name",
        aa_macro_name_desc = "File name used when recording. Leave it empty to use the level's name",
        aa_macro_record_title = "Record Macro",
        aa_macro_record_desc = "Turn on and play normally, turn off to save (you must be in a match)",
        aa_macro_file_title = "Macro File",
        aa_macro_file_desc = "Auto uses the file named after the level you're playing",
        aa_macro_refresh = "Refresh File List",
        aa_macro_sync_title = "Playback Timing",
        aa_macro_sync_desc = "Wave + Time follows the recorded wave and timing / Money does each step in order as soon as you can afford it",
        aa_macro_lock_title = "Lock Controls While Playing",
        aa_macro_lock_desc = "While the macro plays you can't rotate the camera, move, press buttons or send commands. Stopping puts everything back right away",
        aa_macro_play_title = "Play Macro",
        aa_macro_play_desc = "Plays the selected macro (starts the game by itself if needed). Leave it on to play every time a match starts",
        aa_macro_delete = "Delete Selected Macro",
        aa_macro_need_match = "You need to be in a match to record a macro",
        aa_macro_wait_match = "The macro will start by itself when you enter a match",
        aa_macro_busy = "A macro is already recording or playing",
        aa_macro_rec_started = "Recording started",
        aa_macro_recording = "Recording ",
        aa_macro_steps = " steps",
        aa_macro_saved = "Macro saved: ",
        aa_macro_empty = "Nothing was recorded",
        aa_macro_nofile = "This executor can't save files, so the macro only lasts until you leave the server",
        aa_macro_missing = "Macro file not found: ",
        aa_macro_playing = "Playing ",
        aa_macro_done = "All steps done",
        aa_macro_stopped = "Macro stopped",
        aa_macro_step_fail = "Skipped a step that failed: ",
        aa_macro_deleted = "Deleted: ",
        aa_lock_stop = "STOP",

        -- Anime Adventures : Auto Join
        aa_sec_join = "Auto Join",
        aa_joinmode_title = "Mode",
        aa_joinmode_desc = "The mode to join (Challenge doesn't need a world or act)",
        aa_joinworld_title = "World",
        aa_joinworld_desc = "The world to play",
        aa_joinact_title = "Act",
        aa_joinact_desc = "The act in the selected world",
        aa_joindiff_title = "Difficulty",
        aa_joindiff_desc = "Used for Story (the game fixes Infinite, Legend Stage and Raid to Hard)",
        aa_joinfriends_title = "Friends Only",
        aa_joinfriends_desc = "Only friends can enter your room (nobody else can join you)",
        aa_autojoin_title = "Auto Join",
        aa_autojoin_desc = "Whenever you're in the lobby, opens a room and starts the selected level",
        aa_execlink_title = "Script Link",
        aa_execlink_desc = "Link to this script, used to run it again after teleporting (lobby to match and back)",
        aa_autoexec_title = "Run Script After Teleport",
        aa_autoexec_desc = "Needs the script link, and your executor has to support it",
        aa_exec_unsupported = "This executor can't run scripts after teleporting",
        aa_join_nolevel = "Pick a level first",
        aa_join_nolobby = "No free room found",
        aa_join_going = "Joining: ",
        aa_join_failed = "Couldn't join yet, trying again",

        -- Anime Adventures : Rewards & Summon
        aa_sec_reward = "Rewards & Summon",
        aa_egg_title = "Auto Collect Eggs",
        aa_egg_desc = "Grabs eggs the moment they spawn",
        aa_egg_none = "There's no egg event in the game right now",
        aa_daily_title = "Claim Daily Reward",
        aa_daily_desc = "Claims the daily login reward while you're in the lobby",
        aa_banner_title = "Banner",
        aa_banner_desc = "The banner to summon on (the list appears while you're in the lobby)",
        aa_method_title = "Summon Type",
        aa_method_desc = "gems summons once / gems10 summons 10 times / ticket uses a ticket",
        aa_summon_count_title = "Summon Rounds",
        aa_summon_count_desc = "Stops by itself after this many rounds",
        aa_summon_title = "Summon",
        aa_summon_desc = "Summons for the number of rounds you set (lobby only)",
        aa_summon_done = "Summoning finished",
        aa_summon_nobanner = "Pick a banner first",
        aa_only_lobby = "This only works in the lobby",
        aa_unavailable = "This isn't available in this version of the game",
        aa_no_command = "This version of the game has no command: ",

        -- Anime Adventures : Performance
        aa_sec_perf = "Performance",
        aa_lowfx_title = "Reduce Game Effects",
        aa_lowfx_desc = "Turns on the game's own effect-reducing settings in one go. Turning it off puts them back (for shadows and textures use Low Graphics below)",
        aa_boost_title = "Low Graphics",
        aa_boost_desc = "Removes map textures, shadows and effects (rejoin the game to get them back)",
        aa_norender_title = "Disable 3D Rendering",
        aa_norender_desc = "The screen goes black but the game keeps running. Much smoother for AFK farming",
        aa_fps_title = "FPS Limit",
        aa_fps_desc = "Less heat and battery use (0 = leave unchanged)",
        aa_debug_title = "Save Game Info",
        aa_debug_desc = "Saves the game's remote list and structure to a file, to send to the script maker when a feature doesn't work",
        aa_debug_saved = "Saved to ",
        aa_debug_copied = "Game info copied",

        sec_misc_tools = "Tools",
        antiafk_title = "Anti-AFK",
        antiafk_desc = "Stay idle without getting kicked (Roblox normally kicks after 20 min without any input)",
        bright_title = "Fullbright",
        bright_desc = "Light up the whole map so you can see clearly. Turning it off puts the lighting back exactly as it was",
        nofog_title = "No Fog",
        nofog_desc = "Clear all the fog from the map",
        noclip_title = "Noclip",
        noclip_desc = "Walk through walls and objects",
        infjump_title = "Infinite Jump",
        infjump_desc = "Keep jumping in mid-air",
        float_height_title = "Float Height",
        float_height_desc = "Enter how high you want to float",
        float_title = "Float",
        float_desc = "Hover in the air",

        sec_theme = "Theme Colors",
        theme_title = "Theme",
        theme_desc = "Pick a preset, or change the colors below and it switches to Custom for you",
        color_desc = "Pick a color to switch to the Custom theme automatically",
        color_background = "Background",
        color_accent = "Sidebar",
        color_text = "Text",
        color_icon = "Icons",
        color_button = "Buttons",
        color_toggle = "Toggles & Sliders",

        sec_background = "Background Image",
        bg_link_title = "Image Link",
        bg_link_desc = "Paste an image link or Asset ID, then press Enter",
        bg_transparency = "Image Transparency",
        bg_reset = "Use Default Image",
        bg_reset_desc = "Clear the link and go back to the default image",
        bg_applied = "Background updated",
        bg_failed = "Couldn't load that image, check the link",

        sec_language = "Language",
        language_title = "Language",
        language_desc = "Change the menu language",

        keybind_title = "Menu Key",
        keybind_desc = "Choose the key that opens and closes the menu",

        sec_jobid = "Server",
        join_link_title = "Join Link",
        join_link_desc = "Copy a link so friends can join your server",
        link_copied = "Link copied",
        jobid_missing = "Couldn't find this server's JobId",
        copy_jobid_title = "Copy Server ID",
        copy_jobid_desc = "Copy the JobId of the server you're in",
        jobid_copied = "Server ID copied",
        jobid_input_title = "Server ID",
        jobid_input_desc = "Paste the JobId of the server you want to join",
        teleport_title = "Join by Server ID",
        teleport_desc = "Teleport to the server with that ID",
        jobid_required = "Enter a server ID first",

    },
}

local currentLang = "th"

WindUI:Localization({
    Enabled = true,
    DefaultLanguage = "en",
    Prefix = "loc:",
    Translations = Translations,
})
WindUI:SetLanguage(currentLang)

local function T(key)
    return Translations[currentLang][key] or Translations.en[key] or key
end

-- แจ้งเตือนสั้นๆ (ใช้ซ้ำทั้งสคริป)
local function Notify(text, duration)
    WindUI:Notify({ Title = "XEPHEX HUB", Content = text, Duration = duration or 3 })
end

----------------------------------------------------------
-- 🪟 Window
----------------------------------------------------------
Window = WindUI:CreateWindow({
    Title = "XEPHEX HUB  | " .. gameName,
    Author = ".gg/rNKGmeyAHf",
    Folder = "XEPHEX HUB",
    Theme = "Dark",
    Size = UDim2.fromOffset(600, 300),
    Icon = "rbxassetid://80283328189076",
    HideSearchBar = false,
    User = {
        Enabled = true,
        Anonymous = false,
        Callback = function()
            Notify(T("hello") .. LocalPlr.Name, 3)
        end
    }
})

----------------------------------------------------------
-- ⏱️ ทุกครั้งที่สร้างแท็บ / Section / ปุ่ม / สวิตช์ จะเช็ก Yield() ก่อน
--   Section ไหนมีของเยอะ ก็ไม่ค้าง (เดิมพักได้แค่ระหว่าง Section)
----------------------------------------------------------
do
    local ELEMENT_KINDS = {
        "Section", "Group", "Paragraph", "Button", "Toggle", "Slider", "Keybind",
        "Input", "Dropdown", "Colorpicker", "Code", "Divider", "Space", "Image",
    }

    local function sliceContainer(container)
        for _, kind in ipairs(ELEMENT_KINDS) do
            local create = container[kind]
            if type(create) == "function" then
                container[kind] = function(self, ...)
                    Yield()
                    holdYield = false
                    local element = create(self, ...)
                    if (kind == "Section" or kind == "Group") and type(element) == "table" then
                        holdYield = true
                        sliceContainer(element)
                    end
                    return element
                end
            end
        end
        return container
    end

    local createTab = Window.Tab
    Window.Tab = function(self, ...)
        Yield()
        return sliceContainer(createTab(self, ...))
    end
end

----------------------------------------------------------
-- 🔘 ปุ่มเปิดปิด UI (ลากได้)
----------------------------------------------------------
Yield()
do
    local old = LocalPlr:WaitForChild("PlayerGui"):FindFirstChild("XephexToggleGui")
    if old then old:Destroy() end

    local gui = Instance.new("ScreenGui")
    gui.Name = "XephexToggleGui"
    gui.ResetOnSpawn = false
    gui.DisplayOrder = 999
    gui.IgnoreGuiInset = true
    gui.Parent = LocalPlr:WaitForChild("PlayerGui")

    local circle = Instance.new("Frame")
    circle.Size = UDim2.fromOffset(44, 44)
    circle.Position = UDim2.fromOffset(24, 200)
    circle.BackgroundColor3 = Color3.fromHex("0d0d0d")
    circle.BorderSizePixel = 0
    circle.Parent = gui

    Instance.new("UICorner", circle).CornerRadius = UDim.new(0, 10)

    local stroke = Instance.new("UIStroke")
    stroke.Thickness = 1.5
    stroke.Color = Color3.fromHex("00FFC8")
    stroke.Parent = circle

    local shadow = Instance.new("ImageLabel")
    shadow.Size = UDim2.fromOffset(50, 50)
    shadow.Position = UDim2.fromOffset(-3, -3)
    shadow.BackgroundTransparency = 1
    shadow.Image = "rbxassetid://2"
    shadow.ImageColor3 = Color3.new(1, 1, 1)
    shadow.ImageTransparency = 0.6
    shadow.ScaleType = Enum.ScaleType.Slice
    shadow.SliceCenter = Rect.new(24, 24, 276, 276)
    shadow.ZIndex = 0
    shadow.Parent = circle

    local icon = Instance.new("ImageLabel")
    icon.Name = "Icon"
    icon.Size = UDim2.fromOffset(55, 55)
    icon.AnchorPoint = Vector2.new(0.5, 0.5)
    icon.Position = UDim2.new(0.5, 0, 0.5, 0)
    icon.BackgroundTransparency = 1
    icon.Image = "rbxassetid://80283328189076"
    icon.ImageColor3 = Color3.new(1, 1, 1)
    icon.ScaleType = Enum.ScaleType.Fit
    icon.ResampleMode = Enum.ResamplerMode.Default
    icon.ImageTransparency = 0
    icon.ClipsDescendants = true
    icon.ZIndex = 2
    icon.Parent = circle

    local dragging = false
    local dragStart, frameStart
    local hasMoved = false
    local DRAG_THRESHOLD = 6
    local activeInput = nil

    -- เริ่มลาก
    circle.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
            activeInput = input
            dragging = true
            hasMoved = false
            dragStart = input.Position
            frameStart = Vector2.new(circle.Position.X.Offset, circle.Position.Y.Offset)
        end
    end)

    -- กำลังลาก
    UIS.InputChanged:Connect(function(input)
        if dragging and input == activeInput then
            local delta = input.Position - dragStart
            if delta.Magnitude > DRAG_THRESHOLD then
                hasMoved = true
            end
            circle.Position = UDim2.fromOffset(frameStart.X + delta.X, frameStart.Y + delta.Y)
        end
    end)

    -- ปล่อย (ถ้าไม่ได้ลาก = เปิดปิด UI)
    UIS.InputEnded:Connect(function(input)
        if input == activeInput then
            dragging = false
            activeInput = nil
            if not hasMoved then
                Window:Toggle()
            end
        end
    end)
end

Window:EditOpenButton({ Enabled = false })

local ConfigManager = Window.ConfigManager
local MyConfig = ConfigManager:CreateConfig("FishIt")

local TabLog = Window:Tab({ Title = "loc:tab_log", Icon = "crown" })
local TabMain = Window:Tab({ Title = "loc:tab_main", Icon = "menu" })
local TabMise = Window:Tab({ Title = "loc:tab_misc", Icon = "sparkles" })
local TabSettings = Window:Tab({ Title = "loc:tab_settings", Icon = "settings" })

----------------------------------------------------------
-- 👑 Tab Log
----------------------------------------------------------
TabLog:Section({ Title = "loc:sec_credit" })
TabLog:Button({
    Title = "Discord",
    Desc = "loc:discord_desc",
    Callback = function()
        setclipboard("https://discord.gg/rNKGmeyAHf")
        Notify(T("discord_copied"), 5)
    end
})
TabLog:Button({
    Title = "YouTube",
    Desc = "loc:youtube_desc",
    Callback = function()
        setclipboard("https://www.youtube.com/@x2Zeroo")
        Notify(T("youtube_copied"), 5)
    end
})

TabLog:Paragraph({
    Title = "loc:free_title",
    Desc = "loc:free_desc",
    Image = "badge-check",
    ImageSize = 20,
    Color = "White"
})

----------------------------------------------------------
-- 🧰 ตัวช่วยพื้นฐาน
----------------------------------------------------------

-- อ่านค่าแบบไม่ให้สคริปพัง (ถ้าอ่านไม่ได้ จะได้ nil)
local function safe(fn)
    local ok, result = pcall(fn)
    if ok then
        return result
    end
    return nil
end

-- ตัวละคร
local function getHRP()
    local char = LocalPlr.Character or LocalPlr.CharacterAdded:Wait()
    return char:WaitForChild("HumanoidRootPart", 5)
end

----------------------------------------------------------
-- ☁️ ตัวช่วยลอยตัว (ใช้ร่วมกับ Misc และเคาะประตู)
----------------------------------------------------------
local Float = {
    Height = 30,       -- ลอยสูงแค่ไหน
    Enabled = false,   -- ผู้เล่นเปิดลอยไว้ไหม
    Trick = false,     -- กำลังเคาะประตูอยู่ไหม (เคาะประตูอยู่ = ไม่ลอย)
}

local function applyFloat()
    local hrp = getHRP()
    if not hrp then return end

    -- ลอยเฉพาะตอนเปิดลอย และไม่ได้กำลังเคาะประตู
    if Float.Enabled and not Float.Trick then
        local f = hrp:FindFirstChild("FloatForce")
        if not f then
            f = Instance.new("BodyPosition")
            f.Name = "FloatForce"
            f.MaxForce = Vector3.new(0, 1e6, 0)
            f.P = 10000
            f.D = 1000
            f.Parent = hrp
        end
        f.Position = hrp.Position + Vector3.new(0, Float.Height, 0)
    else
        local f = hrp:FindFirstChild("FloatForce")
        if f then f:Destroy() end
    end
end

----------------------------------------------------------
-- ✨ Tab Misc
----------------------------------------------------------
local MiscSec = TabMise:Section({
    Title = "loc:sec_misc_tools",
    Icon = "sparkles",
    Box = true,
    TextSize = 18,
    Opened = false
})

----------------------------------------------------------
-- 🛡️ Anti AFK
--   Roblox เตะคนที่ไม่ได้กดอะไรเลย 20 นาที (เกมนี้ไม่มีระบบเตะ AFK ของตัวเอง) กันไว้ 3 ชั้น:
--   1) ปิดตัวที่ผูกกับ Idled ของ Roblox ไว้ (ถ้าตัวรันมี getconnections) ปิดสวิตช์ = เปิดคืนตามเดิม
--   2) Roblox บอกว่ายืนเฉย (Idled ดังทุก ~2 นาที) = จำลองการกดให้ ตัวนับเวลา AFK เริ่มนับใหม่
--   3) กันพลาด: ไม่ได้กดอะไรเลยเกิน 60 วินาที = จำลองการกดให้เองด้วย (เผื่อ Idled ไม่ดังในบางตัวรัน)
--   จำลองการกด: VirtualUser ก่อน (วิธีมาตรฐาน) ใช้ไม่ได้ค่อยใช้ VirtualInputManager
--   ของเดิม: ถ้า VirtualUser พังในตัวรันนั้น จะ error เงียบๆ แล้วโดนเตะ (ไม่มีทางสำรอง)
----------------------------------------------------------
Yield()
do
    local IDLE_POKE = 60   -- ไม่ได้กดอะไรเลยนานเท่านี้ (วินาที) = จำลองการกดให้

    local VirtualUser = safe(function() return game:GetService("VirtualUser") end)
    local VirtualInput = safe(function() return game:GetService("VirtualInputManager") end)

    local antiAFK = false
    local runId = 0
    local conns = {}          -- ตัวดักของเรา (ปิดสวิตช์ = ตัดทิ้ง)
    local disabledIdled = {}  -- ตัวที่ผูกกับ Idled ที่เราปิดไว้ (ปิดสวิตช์ = เปิดคืน)
    local lastInput = os.clock()

    -- ทำให้ Roblox นับว่าเพิ่งมีการกด
    local function poke()
        lastInput = os.clock()
        local done = VirtualUser ~= nil and pcall(function()
            VirtualUser:CaptureController()
            VirtualUser:ClickButton2(Vector2.new())
        end)
        if not done and VirtualInput then
            pcall(function()
                local camera = workspace.CurrentCamera
                local size = camera and camera.ViewportSize or Vector2.new(2, 2)
                VirtualInput:SendMouseMoveEvent(size.X / 2, size.Y / 2, game)
            end)
        end
    end

    local function blockIdleKick()
        if type(getconnections) ~= "function" then
            return
        end
        local ok, list = pcall(getconnections, LocalPlr.Idled)
        if not ok or type(list) ~= "table" then
            return
        end
        for _, conn in ipairs(list) do
            if pcall(function() conn:Disable() end) then
                table.insert(disabledIdled, conn)
            end
        end
    end

    local function restoreIdleKick()
        for _, conn in ipairs(disabledIdled) do
            pcall(function() conn:Enable() end)
        end
        disabledIdled = {}
    end

    local function stopAntiAFK()
        antiAFK = false
        runId = runId + 1
        for _, conn in ipairs(conns) do
            conn:Disconnect()
        end
        conns = {}
        restoreIdleKick()
    end

    local function startAntiAFK()
        stopAntiAFK()
        antiAFK = true
        lastInput = os.clock()

        blockIdleKick()   -- ทำก่อนต่อตัวดักของเรา (ไม่งั้นจะปิดตัวดักของเราไปด้วย)
        table.insert(conns, LocalPlr.Idled:Connect(poke))
        table.insert(conns, UIS.InputBegan:Connect(function()
            lastInput = os.clock()
        end))
        table.insert(conns, UIS.InputChanged:Connect(function()
            lastInput = os.clock()
        end))

        runId = runId + 1
        local myId = runId
        task.spawn(function()
            while antiAFK and runId == myId do
                task.wait(5)
                if antiAFK and runId == myId and os.clock() - lastInput >= IDLE_POKE then
                    poke()
                end
            end
        end)
    end

    local TogAntiAFK = MiscSec:Toggle({
        Title = "loc:antiafk_title",
        Icon = "shield",
        Desc = "loc:antiafk_desc",
        Value = false,
        Callback = function(state)
            if state then
                startAntiAFK()
            else
                stopAntiAFK()
            end
        end
    })
    MyConfig:Register("AntiAFK", TogAntiAFK)
end

----------------------------------------------------------
-- 💡 ตัวคุมค่าแสง (ใช้ร่วมกัน: แมพสว่าง / ไม่มีหมอก)
--   LightOverride.set("ชื่อ", { ClockTime = 12, ... })  = บังคับค่าแสงตามนี้
--   LightOverride.set("ชื่อ", nil)                      = เลิกบังคับ (ค่าไหนไม่มีใครบังคับแล้ว คืนค่าเดิมทันที)
--   ค่าเดิม = ค่าตอนก่อนเริ่มบังคับ (ระหว่างนั้นเกมเปลี่ยนค่าเอง เช่นอากาศ / กลางวันกลางคืน = จำค่าล่าสุดของเกมไว้คืนแทน)
--   เกมเปลี่ยนค่าระหว่างบังคับ = ใส่ค่าของเรากลับทันที (ไม่ต้องวนลูปทุกวินาทีแบบเดิม)
--   เปิดหลายอย่างพร้อมกัน ปิดอันหนึ่งไม่ทำให้อีกอันพัง (ปิดแมพสว่างตอนไม่มีหมอกยังเปิดอยู่ หมอกก็ไม่กลับมา)
--   ของเดิม: จำค่าแสงไว้ตั้งแต่ตอนรันสคริป (ไม่ใช่ตอนกดเปิด) และจำไม่ครบ ปิดแล้วเลยไม่กลับเป็นแบบเดิม
----------------------------------------------------------
local LightOverride = {}
do
    local base = {}       -- ค่าเดิมที่จะคืน   base.ClockTime = 14
    local layers = {}     -- ค่าที่แต่ละอย่างบังคับ   layers.bright = { ClockTime = 12, ... }
    local order = {}      -- ลำดับที่เปิด (อันที่เปิดทีหลังชนะ)
    local watchers = {}   -- ตัวดักการเปลี่ยนค่าของแต่ละค่า

    local function same(a, b)
        if type(a) == "number" and type(b) == "number" then
            return math.abs(a - b) < 1e-3
        end
        if typeof(a) == "Color3" and typeof(b) == "Color3" then
            return math.abs(a.R - b.R) < 1e-3 and math.abs(a.G - b.G) < 1e-3 and math.abs(a.B - b.B) < 1e-3
        end
        return a == b
    end

    local function wanted(prop)
        local value = nil
        for _, name in ipairs(order) do
            if layers[name][prop] ~= nil then
                value = layers[name][prop]
            end
        end
        return value
    end

    local function write(prop, value)
        if not same(Lighting[prop], value) then
            pcall(function() Lighting[prop] = value end)
        end
    end

    local function watch(prop)
        if watchers[prop] then
            return
        end
        base[prop] = Lighting[prop]   -- ค่าก่อนเริ่มบังคับ
        watchers[prop] = Lighting:GetPropertyChangedSignal(prop):Connect(function()
            local value = wanted(prop)
            local now = Lighting[prop]
            if value ~= nil and not same(now, value) then
                base[prop] = now      -- เกมเปลี่ยนเอง = จำค่าใหม่ของเกมไว้คืน
                write(prop, value)
            end
        end)
    end

    local function unwatch(prop)
        local conn = watchers[prop]
        if not conn then
            return
        end
        conn:Disconnect()
        watchers[prop] = nil
        write(prop, base[prop])
        base[prop] = nil
    end

    function LightOverride.set(name, values)
        local index = table.find(order, name)
        if values then
            layers[name] = values
            if not index then
                table.insert(order, name)
            end
        else
            layers[name] = nil
            if index then
                table.remove(order, index)
            end
        end

        local props = {}
        for prop in pairs(watchers) do
            props[prop] = true
        end
        for _, layer in pairs(layers) do
            for prop in pairs(layer) do
                props[prop] = true
            end
        end
        for prop in pairs(props) do
            local value = wanted(prop)
            if value ~= nil then
                watch(prop)
                write(prop, value)
            else
                unwatch(prop)
            end
        end
    end
end

----------------------------------------------------------
-- ☀️ Bright (แมพสว่าง)
--   เปิด = จำค่าแสงตอนนั้นไว้ แล้วบังคับให้สว่าง / ปิด = คืนค่าแสงเดิมทุกค่า (ผ่าน LightOverride)
----------------------------------------------------------
Yield()
do
    local BRIGHT = {
        ClockTime = 12,
        Brightness = 3,
        Ambient = Color3.new(1, 1, 1),
        OutdoorAmbient = Color3.new(1, 1, 1),
        FogEnd = 999999,
        GlobalShadows = false,
    }

    local TogBright = MiscSec:Toggle({
        Title = "loc:bright_title",
        Icon = "sun",
        Desc = "loc:bright_desc",
        Value = false,
        Callback = function(state)
            LightOverride.set("bright", state and BRIGHT or nil)
        end
    })
    MyConfig:Register("Bright", TogBright)
end

----------------------------------------------------------
-- 🌫️ No Fog
----------------------------------------------------------
Yield()
do
    local NO_FOG = { FogStart = 0, FogEnd = 999999 }

    local TogNoFog = MiscSec:Toggle({
        Title = "loc:nofog_title",
        Icon = "cloud-off",
        Desc = "loc:nofog_desc",
        Value = false,
        Callback = function(state)
            LightOverride.set("nofog", state and NO_FOG or nil)
        end
    })
    MyConfig:Register("NoFog", TogNoFog)
end

----------------------------------------------------------
-- 🚫 Noclip
----------------------------------------------------------
Yield()
do
    local noclipParts = {}   -- ชิ้นส่วนที่เดิมชนได้ (ไว้คืนค่าตอนปิด)
    local noclipConns = {}

    -- จดชิ้นส่วนตัวละครที่ชนได้ไว้ (ไม่ต้องไล่หาทุกเฟรม)
    local function collectNoclipParts()
        noclipParts = {}
        local char = LocalPlr.Character
        if not char then return end
        for _, part in ipairs(char:GetDescendants()) do
            if part:IsA("BasePart") and part.CanCollide then
                noclipParts[part] = true
            end
        end
    end

    local function stopNoclip()
        for _, conn in ipairs(noclipConns) do conn:Disconnect() end
        noclipConns = {}
        for part in pairs(noclipParts) do
            if part.Parent then part.CanCollide = true end
        end
        noclipParts = {}
    end

    local function startNoclip()
        stopNoclip()
        collectNoclipParts()

        -- ปิดการชนทุกเฟรม
        table.insert(noclipConns, RunService.Stepped:Connect(function()
            for part in pairs(noclipParts) do
                if part.Parent then
                    part.CanCollide = false
                else
                    noclipParts[part] = nil
                end
            end
        end))

        -- เกิดใหม่ / โหลดชุดเสร็จ = จดชิ้นส่วนใหม่
        table.insert(noclipConns, LocalPlr.CharacterAdded:Connect(function(char)
            char:WaitForChild("HumanoidRootPart", 5)
            collectNoclipParts()
        end))
        table.insert(noclipConns, LocalPlr.CharacterAppearanceLoaded:Connect(collectNoclipParts))
    end

    local TogNoclip = MiscSec:Toggle({
        Title = "loc:noclip_title",
        Icon = "ghost",
        Desc = "loc:noclip_desc",
        Default = false,
        Callback = function(state)
            if state then startNoclip() else stopNoclip() end
        end
    })
    MyConfig:Register("Noclip", TogNoclip)
end

----------------------------------------------------------
-- 🦘 Infinite Jump
----------------------------------------------------------
Yield()
do
    local infJumpConn
    local TogInfJump = MiscSec:Toggle({
        Title = "loc:infjump_title",
        Icon = "arrow-up",
        Desc = "loc:infjump_desc",
        Default = false,
        Callback = function(state)
            if infJumpConn then
                infJumpConn:Disconnect()
                infJumpConn = nil
            end
            if state then
                infJumpConn = UIS.JumpRequest:Connect(function()
                    local char = LocalPlr.Character
                    local hum = char and char:FindFirstChildOfClass("Humanoid")
                    if hum and hum.Health > 0 then
                        hum:ChangeState(Enum.HumanoidStateType.Jumping)
                    end
                end)
            end
        end
    })
    MyConfig:Register("InfiniteJump", TogInfJump)
end

----------------------------------------------------------
-- ☁️ Float
----------------------------------------------------------
Yield()
do
    MiscSec:Input({
        Title = "loc:float_height_title",
        Icon = "sliders",
        Desc = "loc:float_height_desc",
        Default = tostring(Float.Height),
        Callback = function(Value)
            local v = tonumber(Value)
            if v then
                Float.Height = v
                if Float.Enabled then applyFloat() end
            end
        end
    })

    local TogFloat = MiscSec:Toggle({
        Title = "loc:float_title",
        Icon = "cloud",
        Desc = "loc:float_desc",
        Default = false,
        Callback = function(state)
            Float.Enabled = state
            applyFloat()
        end
    })
    MyConfig:Register("Float", TogFloat)

    -- ตายแล้วเกิดใหม่ ให้ลอยต่อ
    LocalPlr.CharacterAdded:Connect(function(char)
        if Float.Enabled then
            char:WaitForChild("HumanoidRootPart", 5)
            task.wait(1)
            applyFloat()
        end
    end)
end

----------------------------------------------------------
-- 🎮 Anime Adventures : แกนกลาง
--   ที่มาของข้อมูล (ไฟล์ Tester)
--     ReplicatedStorage.src.Loader        : load_client_service / load_data / LevelData (บริการและข้อมูลของเกม)
--     workspace._MAP_CONFIG               : IsLobby / IsTimeMachine / GetLevelData
--     workspace._UNITS.<ยูนิต>._stats      : id / upgrade
--     LocalPlayer._settings.<ชื่อ>         : ค่าการตั้งค่าของเกม (รายชื่ออยู่ใน Data.Settings)
--     ReplicatedStorage._TheHatch.Remotes : Spawn / Despawn / Pickup (ไข่)
--     packages.assets.MapIcons.<แมพ>      : รูปของแมพ (ใช้ใส่ในดรอปดาวน์)
--   คำสั่งที่ส่งให้เซิร์ฟอยู่ใน ReplicatedStorage.endpoints.client_to_server
--     (ชุดเดียวกับที่ EndpointsClient.invoke_server ของเกมใช้) ไฟล์ Tester ไม่มีโค้ดส่วนที่เรียกคำสั่งพวกนี้
--     สคริปเลย "ส่งแล้วดูผลจริงจากเกม" (ยูนิตโผล่ไหม / เลเวลขึ้นไหม) แล้วจำรูปแบบที่ใช้ได้ไว้ใน AA.Shape
--   ทุกอย่างทำงานตามเหตุการณ์ (ค่าเปลี่ยน / ของโผล่) ไม่มีลูปวนเช็กถี่ๆ
----------------------------------------------------------
local AA = {
    Flags = {},      -- ค่าที่ตั้งไว้ใน UI
    Shape = {},      -- รูปแบบค่าที่ส่งให้เซิร์ฟ: spawn = "ray" / "cf", unit = "name" / "inst"
    State = {},      -- ตัวเก็บค่าของเกม: money / wave / started / finished / units
    Mine = {},       -- ยูนิตของเราในด่าน เรียงตามลำดับที่วาง
    MineInfo = {},   -- model -> { id, uuid, upgrade, order }
    Lock = {},
    Net = {},
    Macro = {},
    Auto = {},
}

do
    local FOLDER = "XEPHEX HUB"
    local SHAPE_FILE = FOLDER .. "/aa_shape.json"
    local myName = LocalPlr.Name
    local srcFolder = ReplicatedStorage:FindFirstChild("src")
    local mapConfig = workspace:FindFirstChild("_MAP_CONFIG")

    AA.Supported = srcFolder ~= nil and mapConfig ~= nil
    AA.IsLobby = AA.Supported and safe(function() return mapConfig.IsLobby.Value end) == true
    AA.IsTimeMachine = AA.Supported and mapConfig:FindFirstChild("IsTimeMachine") ~= nil
    AA.InMatch = AA.Supported and not AA.IsLobby and not AA.IsTimeMachine

    -- รันสคริปซ้ำ = ตัวเก่าหยุดทำงานเอง (ไม่แย่งกันส่งคำสั่ง) และคืนของที่ตัวเก่ายึดไว้ก่อน (ล็อกการควบคุม / ตัวดักรีโมท)
    local env = safe(function() return getgenv() end) or _G
    local generation = (tonumber(env.__XEPHEX_AA) or 0) + 1
    if type(env.__XEPHEX_AA_STOP) == "function" then
        pcall(env.__XEPHEX_AA_STOP)
    end
    env.__XEPHEX_AA = generation

    AA.Shutdown = {}   -- งานเก็บกวาดของตัวนี้ (ถูกเรียกตอนมีตัวใหม่มาแทน)
    env.__XEPHEX_AA_STOP = function()
        for _, job in ipairs(AA.Shutdown) do
            pcall(job)
        end
    end

    function AA.Alive()
        return env.__XEPHEX_AA == generation
    end

    -- อ่านค่าจาก Value object (ของที่ไม่ใช่ Value object = nil ไม่ error)
    function AA.ValueOf(object)
        if object and object:IsA("ValueBase") then
            return object.Value
        end
        return nil
    end

    -- ชิ้นส่วนหลักของยูนิต (ใช้บอกตำแหน่ง)
    function AA.RootOf(model)
        local root = model:FindFirstChild("HumanoidRootPart")
        if root and root:IsA("BasePart") then
            return root
        end
        if model:IsA("Model") then
            return model.PrimaryPart
        end
        return nil
    end

    ------------------------------------------------------
    -- ไฟล์
    ------------------------------------------------------
    AA.CanFiles = type(writefile) == "function" and type(readfile) == "function" and type(isfile) == "function"

    function AA.ReadJSON(path)
        if not AA.CanFiles then
            return nil
        end
        local ok, data = pcall(function()
            if not isfile(path) then
                return nil
            end
            return HttpService:JSONDecode(readfile(path))
        end)
        if ok and type(data) == "table" then
            return data
        end
        return nil
    end

    function AA.WriteJSON(path, data)
        if not AA.CanFiles then
            return false
        end
        local ok = pcall(function()
            if type(makefolder) == "function" and type(isfolder) == "function" then
                if not isfolder(FOLDER) then
                    makefolder(FOLDER)
                end
                local dir = path:match("^(.*)/[^/]+$")
                if dir and dir ~= FOLDER and not isfolder(dir) then
                    makefolder(dir)
                end
            end
            writefile(path, HttpService:JSONEncode(data))
        end)
        return ok
    end

    ------------------------------------------------------
    -- รอแบบไม่วนลูป
    --   AA.Await(timeout, setup)  : หยุดรอจนกว่า resolve(ค่า) ถูกเรียก หรือหมดเวลา (ได้ nil)
    --   AA.Waker()                : ตัวปลุกของงานเบื้องหลัง  sleep() = หลับจนกว่าจะมีเหตุการณ์มา wake()
    ------------------------------------------------------
    function AA.Await(timeout, setup)
        local thread = coroutine.running()
        local state, value = 0, nil   -- 0 = กำลังตั้งค่า, 1 = รออยู่, 2 = จบแล้ว

        local function resolve(result)
            if state == 2 then
                return
            end
            local was = state
            state, value = 2, result
            if was == 1 then
                task.spawn(thread)
            end
        end

        local cleanup = setup(resolve)
        if state ~= 2 then
            state = 1
            if timeout then
                task.delay(timeout, resolve)
            end
            coroutine.yield()
        end
        if cleanup then
            cleanup()
        end
        return value
    end

    function AA.Waker()
        local thread, pending, token = nil, false, 0
        local waker = {}

        function waker.wake()
            local sleeping = thread
            if sleeping then
                thread = nil
                task.spawn(sleeping, true)
            else
                pending = true
            end
        end

        -- คืน true = โดนปลุก / false = หมดเวลา
        function waker.sleep(timeout)
            if pending then
                pending = false
                return true
            end
            token = token + 1
            local mine = token
            thread = coroutine.running()
            if timeout then
                -- ไม่ต่ำกว่า 0.03 วิ: เวลาที่เหลือน้อยมากๆ (เศษทศนิยม) จะได้ไม่ตื่นมาวนซ้ำถี่ๆ
                task.delay(math.max(timeout, 0.03), function()
                    local sleeping = thread
                    if token == mine and sleeping then
                        thread = nil
                        task.spawn(sleeping, false)
                    end
                end)
            end
            return coroutine.yield()
        end

        return waker
    end

    ------------------------------------------------------
    -- เหตุการณ์ภายในสคริป
    --   ตัวรับต้องไม่หยุดรอ (แค่ตั้งค่า / ปลุกงานเบื้องหลัง) งานยาวให้ task.spawn เอง
    --   money / wave / started / finished : ค่าของเกมเปลี่ยน
    --   unit / unitRemoved / enemy        : ของใน workspace._UNITS
    --   matchStart / matchEnd             : เริ่มรอบใหม่ (รวมตอนกดเล่นซ้ำ) / จบรอบ
    ------------------------------------------------------
    local listeners = {}

    -- รายชื่อตัวรับไม่ถูกแก้ตรงๆ: เพิ่ม / ถอน = สร้างรายชื่อใหม่ (นานๆ ที) ตอนส่งเหตุการณ์ (ถี่ เช่นเงินขยับ) เลยวนได้เลย ไม่ต้องคัดลอก
    function AA.On(name, fn)
        local list = listeners[name]
        list = list and table.clone(list) or {}
        list[#list + 1] = fn
        listeners[name] = list
        return function()
            local current = listeners[name]
            local index = current and table.find(current, fn)
            if index then
                current = table.clone(current)
                table.remove(current, index)
                listeners[name] = current
            end
        end
    end

    function AA.Emit(name, ...)
        local list = listeners[name]
        if not list then
            return
        end
        for index = 1, #list do
            local ok, err = pcall(list[index], ...)
            if not ok then
                warn("[XEPHEX HUB] " .. name .. ": " .. tostring(err))
            end
        end
    end

    ------------------------------------------------------
    -- บริการ / ข้อมูลของเกม (ผ่าน Loader ตัวเดียวกับที่เกมใช้)
    ------------------------------------------------------
    local loader
    local loaderTried, gcTried = -math.huge, false

    local function getLoader()
        if loader then
            return loader
        end
        if not AA.Supported or os.clock() - loaderTried < 3 then
            return nil
        end
        loaderTried = os.clock()

        local ok, result = pcall(function()
            return require(srcFolder.Loader)
        end)
        if ok and type(result) == "table" and type(result.load_client_service) == "function" then
            loader = result
            return loader
        end

        -- ตัวรันบางตัว require ไม่ได้ -> หาตาราง Loader ที่เกมสร้างไว้แล้วในหน่วยความจำแทน (ลองครั้งเดียว)
        if not gcTried and type(getgc) == "function" then
            gcTried = true
            pcall(function()
                for _, object in ipairs(getgc(true)) do
                    if type(object) == "table"
                        and type(rawget(object, "load_client_service")) == "function"
                        and type(rawget(object, "load_data")) == "function" then
                        loader = object
                        break
                    end
                end
            end)
        end
        return loader
    end

    local services, serviceMissed = {}, {}

    function AA.Service(name)
        local cached = services[name]
        if cached then
            return cached
        end
        -- ยังหาไม่เจอ (เกมยังโหลดไม่เสร็จ) : ถามซ้ำไม่ถี่กว่า 3 วิ (Loader ของเกมจะ warn ทุกครั้งที่ถามหาของที่ยังไม่มี)
        local missed = serviceMissed[name]
        if missed and os.clock() - missed < 3 then
            return nil
        end
        local current = getLoader()
        if not current then
            return nil
        end
        local ok, service = pcall(current.load_client_service, "XEPHEX", name)
        if ok and type(service) == "table" then
            services[name] = service
            serviceMissed[name] = nil
            return service
        end
        serviceMissed[name] = os.clock()
        return nil
    end

    local dataCache = {}

    function AA.Data(name)
        local cached = dataCache[name]
        if cached then
            return cached
        end
        if not AA.Supported then
            return nil
        end
        local current = getLoader()
        local ok, data = false, nil
        if current then
            ok, data = pcall(current.load_data, "XEPHEX", name)
        end
        if not (ok and type(data) == "table") then
            ok, data = pcall(function()
                return require(srcFolder.Data[name])
            end)
        end
        if ok and type(data) == "table" then
            dataCache[name] = data
            return data
        end
        return nil
    end

    function AA.UnitData(id)
        local units = AA.Data("Units")
        return units and units[id] or nil
    end

    -- ข้อมูลด่านที่กำลังเล่น (เกมเก็บไว้ที่ Loader.LevelData / ยังไม่มีก็ถามเซิร์ฟแบบเดียวกับที่เกมถาม) *หยุดรอได้*
    local invokeServer = Instance.new("RemoteFunction").InvokeServer
    local fireServer = Instance.new("RemoteEvent").FireServer
    local levelData

    function AA.Level()
        if levelData then
            return levelData
        end
        local current = getLoader()
        local data = current and current.LevelData
        if type(data) ~= "table" and AA.InMatch then
            local getter = mapConfig:FindFirstChild("GetLevelData")
            if getter then
                local ok, result = pcall(invokeServer, getter)
                if ok then
                    data = result
                end
            end
        end
        if type(data) == "table" then
            levelData = data
        end
        return levelData
    end

    -- ชื่อด่าน (ใช้เป็นชื่อไฟล์มาโคร / ไฟล์จุดวาง) *หยุดรอได้*
    function AA.MapKey()
        local data = AA.Level()
        local key = data and (data.id or data._id or data.map or data.name)
        if key == nil then
            return nil
        end
        local clean = tostring(key):gsub("[^%w_%-]", "_")
        return clean
    end

    -- ตัวคูณราคาของด่านนี้ (ตัวปรับด่าน / ชาเลนจ์ที่ทำให้ของแพงขึ้น) *หยุดรอได้*
    local CHALLENGE_AS_MODIFIER = { double_cost = "high_cost" }

    function AA.CostScale()
        local data = AA.Level()
        if type(data) ~= "table" then
            return 1
        end
        local scale, seen = 1, {}
        local modifiers = AA.Data("LevelModifiers") or {}
        for _, entry in pairs(type(data._levelmodifiers) == "table" and data._levelmodifiers or {}) do
            local id = type(entry) == "table" and entry.id or entry
            local def = modifiers[id]
            local mods = type(def) == "table" and def.game_mods
            if type(mods) == "table" and tonumber(mods.player_cost_scale) then
                scale = scale * mods.player_cost_scale
                seen[id] = true
            end
        end
        local challenge = data._challenge
        if challenge and not seen[challenge] and not seen[CHALLENGE_AS_MODIFIER[challenge] or ""] then
            local rewards = AA.Data("ChallengeAndRewards")
            local def = rewards and type(rewards.challenges) == "table" and rewards.challenges[challenge]
            if type(def) == "table" and tonumber(def.player_cost_scale) then
                scale = scale * def.player_cost_scale
            end
        end
        return scale
    end

    ------------------------------------------------------
    -- รูป (ใส่ในดรอปดาวน์) : ไม่มีรูปจริง = nil ปล่อยว่าง
    ------------------------------------------------------
    local IMAGE_KEYS = { "image", "icon", "icon_id", "thumbnail", "override_item_model" }

    function AA.Image(entry)
        if type(entry) ~= "table" or entry._use_override_item_model_3D then
            return nil
        end
        for _, key in ipairs(IMAGE_KEYS) do
            local value = entry[key]
            if type(value) == "string" and value:find("^rbxassetid://%d+") then
                return value
            end
        end
        return nil
    end

    function AA.MapImage(mapId)
        if type(mapId) ~= "string" then
            return nil
        end
        return safe(function()
            local folder = ReplicatedStorage.packages.assets.MapIcons:FindFirstChild(mapId)
            local first = folder and folder:GetChildren()[1]
            local image = first and first.Image
            if type(image) == "string" and image ~= "" then
                return image
            end
            return nil
        end)
    end

    ------------------------------------------------------
    -- ทีมที่ใส่อยู่ (session ของเกม : บริการทุกตัวเก็บไว้ที่ .session)
    ------------------------------------------------------
    local SESSION_SERVICES = { "ItemInventoryServiceClient", "UnitCollectionServiceClient", "StatsServiceClient", "GUIService", "EndpointsClient" }

    function AA.Session()
        for _, name in ipairs(SESSION_SERVICES) do
            local service = AA.Service(name)
            local session = service and service.session
            if type(session) == "table" then
                return session
            end
        end
        return nil
    end

    -- ตารางยูนิตที่มี: ปกติอยู่ที่ session.collection.collection_profile_data.owned_units
    --   ถ้าเกมย้ายที่เก็บ จะไล่หาใน session เอง = ตารางที่ข้างในเป็นยูนิต (มี unit_id + uuid) และมีตัวที่ใส่อยู่ (equipped_slot)
    --   ไล่แบบจำกัด (ลึกไม่เกิน 4 ชั้น / ไม่เกิน 4000 ช่อง) ไม่ค้าง และทำเฉพาะตอนที่ตำแหน่งปกติไม่มี
    local function isUnitTable(tbl)
        local _, first = next(tbl)
        if type(first) ~= "table" or rawget(first, "unit_id") == nil or rawget(first, "uuid") == nil then
            return false
        end
        for _, info in next, tbl do
            if type(info) == "table" and rawget(info, "equipped_slot") then
                return true
            end
        end
        return false
    end

    local function findOwnedUnits(session)
        local direct = safe(function()
            return session.collection.collection_profile_data.owned_units
        end)
        if type(direct) == "table" and next(direct) ~= nil then
            return direct
        end
        local level, seen, visited = { session }, { [session] = true }, 0
        for _ = 1, 4 do
            local deeper = {}
            for _, current in ipairs(level) do
                for _, value in next, current do
                    visited = visited + 1
                    if visited > 4000 then
                        return nil
                    end
                    if type(value) == "table" and not seen[value] then
                        seen[value] = true
                        if isUnitTable(value) then
                            return value
                        end
                        deeper[#deeper + 1] = value
                    end
                end
            end
            level = deeper
        end
        return nil
    end

    local equipped

    -- คืนรายการ { slot, uuid, id, name, title, data } เรียงตามช่อง
    function AA.Equipped(force)
        if equipped and not force then
            return equipped
        end
        local list = {}
        local session = AA.Session()
        local owned = session and safe(function()
            return findOwnedUnits(session)
        end)
        if type(owned) == "table" then
            local unitsData = AA.Data("Units") or {}
            for key, info in pairs(owned) do
                if type(info) == "table" and info.equipped_slot then
                    local id = info.unit_id
                    local data = unitsData[id]
                    list[#list + 1] = {
                        slot = tonumber(info.equipped_slot) or (#list + 1),
                        uuid = tostring(info.uuid or key),
                        id = id,
                        name = type(data) == "table" and data.name or tostring(id),
                        data = type(data) == "table" and data or nil,
                    }
                end
            end
            table.sort(list, function(a, b)
                return a.slot < b.slot
            end)
            for _, unit in ipairs(list) do
                unit.title = unit.slot .. ". " .. unit.name
            end
        end
        if #list > 0 then
            equipped = list
        end
        return list
    end

    ------------------------------------------------------
    -- คำสั่งที่ส่งให้เซิร์ฟ
    --   เรียกแบบ remote.InvokeServer(remote, ...) (ไม่ผ่าน __namecall) ตัวดักรีโมทของเราเลยไม่เห็นคำสั่งของสคริปเอง
    ------------------------------------------------------
    local clientToServer
    local missingTold = {}   -- ชื่อคำสั่งที่แจ้งไปแล้วว่าเกมไม่มี

    function AA.Endpoints()
        if clientToServer and clientToServer.Parent then
            return clientToServer
        end
        local folder = ReplicatedStorage:FindFirstChild("endpoints")
        clientToServer = folder and folder:FindFirstChild("client_to_server")
        return clientToServer
    end

    function AA.Remote(name)
        local folder = AA.Endpoints()
        return folder and folder:FindFirstChild(name) or nil
    end

    AA.InvokeRemote = invokeServer
    AA.RawInvoke = nil   -- invoke_server ตัวจริงของ EndpointsClient (ตอนที่ถูกครอบไว้ตอนบล็อก)

    -- คืน ok, ผลลัพธ์...  *หยุดรอจนเซิร์ฟตอบ*
    function AA.Call(name, ...)
        local folder = AA.Endpoints()
        local remote = folder and folder:FindFirstChild(name)
        if remote then
            local class = remote.ClassName
            if class == "RemoteFunction" then
                return pcall(invokeServer, remote, ...)
            elseif class == "RemoteEvent" then
                return pcall(fireServer, remote, ...)
            end
        elseif folder then
            -- โฟลเดอร์คำสั่งของเกมมีอยู่ แต่ไม่มีคำสั่งชื่อนี้ = เกมรุ่นนี้ไม่มีคำสั่งนี้: จบตรงนี้เลย
            --   ไม่ถามต่อผ่านตัวเกม (เกมอาจนั่งรอคำสั่งที่ไม่มีวันมา แล้วงานของเราจะค้างตามไปด้วย)
            --   แจ้งผู้ใช้ 1 ครั้งต่อคำสั่ง: ฟังก์ชันที่ต้องใช้คำสั่งนี้จะได้ไม่เปิดค้างแบบเงียบๆ
            if not missingTold[name] then
                missingTold[name] = true
                Notify(T("aa_no_command") .. tostring(name), 6)
            end
            return false, "endpoint not found: " .. tostring(name)
        end
        local invoke = AA.RawInvoke
        if not invoke then
            local service = AA.Service("EndpointsClient")
            invoke = service and service.invoke_server
        end
        if type(invoke) == "function" then
            return pcall(invoke, name, ...)
        end
        return false, "endpoint not found: " .. tostring(name)
    end

    -- เหมือน AA.Call แต่ไม่รอเกิน timeout วินาที
    function AA.CallWait(timeout, name, ...)
        local args = table.pack(...)
        local result = AA.Await(timeout, function(resolve)
            task.spawn(function()
                resolve(table.pack(AA.Call(name, table.unpack(args, 1, args.n))))
            end)
        end)
        if result then
            return table.unpack(result, 1, result.n)
        end
        return false, "timeout"
    end

    -- ส่งคำสั่ง แล้วดูผลจริงจากเกม: watch(resolve) ต้องเรียก resolve(true) ตอนเห็นผล
    --   เซิร์ฟตอบแล้วแต่ยังไม่เห็นผลภายใน grace วินาที = ไม่สำเร็จ
    function AA.Act(timeout, grace, watch, name, ...)
        local args = table.pack(...)
        return AA.Await(timeout, function(resolve)
            local cleanup = watch(resolve)
            task.spawn(function()
                AA.Call(name, table.unpack(args, 1, args.n))
                task.wait(grace)
                resolve(false)
            end)
            return cleanup
        end) == true
    end

    -- จำรูปแบบค่าที่ใช้ได้ (เซฟลงไฟล์ รอบหน้าไม่ต้องลองใหม่)
    function AA.Learn(key, value)
        if AA.Shape[key] == value then
            return
        end
        AA.Shape[key] = value
        task.defer(AA.WriteJSON, SHAPE_FILE, AA.Shape)
    end

    ------------------------------------------------------
    -- การตั้งค่าของเกม : รายชื่ออยู่ใน Data.Settings / ค่าจริงอยู่ที่ LocalPlayer._settings.<ชื่อ>
    --   ไฟล์ Tester ไม่มีโค้ดส่วนที่เกมส่งคำสั่งเปลี่ยนค่า สคริปเลย "ส่งแล้วดูค่าจริง" ว่าเปลี่ยนตามไหม
    --   ค่าไม่เปลี่ยน = คืน false ตามจริง ให้คนเรียกไปใช้ทางสำรอง / แจ้งผู้ใช้ (ไม่ทำเป็นว่าสำเร็จ)
    ------------------------------------------------------
    function AA.SettingValue(id, timeout)
        local folder = LocalPlr:FindFirstChild("_settings")
        if not folder and timeout then
            folder = LocalPlr:WaitForChild("_settings", timeout)
        end
        local value = folder and folder:FindFirstChild(id)
        if value and value:IsA("ValueBase") then
            return value
        end
        return nil
    end

    local settingFails, settingRetryAt = 0, 0

    -- คืน true ถ้าค่าเป็นตามที่ขอแล้วจริงๆ  *หยุดรอได้*
    function AA.SetSetting(id, state)
        local value = AA.SettingValue(id)
        if not value then
            return false
        end
        if value.Value == state then
            return true
        end
        -- เกมไม่มีคำสั่งนี้ / เพิ่งส่งแล้วค่าไม่ขยับ 2 ครั้งติด = พัก 60 วิ (ไม่ส่งคำสั่งที่เซิร์ฟไม่รับซ้ำๆ)
        if not AA.Remote("toggle_setting") or os.clock() < settingRetryAt then
            return false
        end
        AA.Act(5, 1, function(resolve)
            local conn = value.Changed:Connect(function()
                if value.Value == state then
                    resolve(true)
                end
            end)
            return function()
                conn:Disconnect()
            end
        end, "toggle_setting", id, state)
        if value.Value == state then
            settingFails = 0
            return true
        end
        settingFails = settingFails + 1
        if settingFails >= 2 then
            settingFails, settingRetryAt = 0, os.clock() + 60
        end
        return false
    end

    -- กลับล็อบบี้: คำสั่งของเกม (ปุ่ม Return to Lobby ในหน้าตั้งค่าของเกม = Data.Settings.teleport_back_to_lobby)
    --   เกมไม่มีคำสั่งนี้ = ย้ายเองด้วยเลขแมพล็อบบี้จากข้อมูลของเกม (Data.GameplaySettings.LOBBY_PLACE_ID)
    function AA.ToLobby()
        if AA.Remote("teleport_back_to_lobby") then
            return AA.Call("teleport_back_to_lobby")
        end
        local gameplay = AA.Data("GameplaySettings")
        local place = type(gameplay) == "table" and tonumber(gameplay.LOBBY_PLACE_ID)
        if not place then
            return false
        end
        return pcall(function()
            game:GetService("TeleportService"):Teleport(place, LocalPlr)
        end)
    end

    ------------------------------------------------------
    -- ค่าของเกมในด่าน
    ------------------------------------------------------
    function AA.Money()
        local value = AA.State.money
        return value and tonumber(value.Value) or nil
    end

    function AA.Wave()
        local value = AA.State.wave
        return value and tonumber(value.Value) or 0
    end

    -- รอบนี้เริ่มแล้วหรือยัง: ดูจากเลขเวฟก่อน (เวฟ 0 = ยังไม่เริ่ม แม้ค่า _waves_started จะค้างจากรอบก่อน)
    function AA.Started()
        if AA.State.wave then
            return AA.Wave() > 0
        end
        local value = AA.State.started
        return value ~= nil and value.Value == true
    end

    function AA.Finished()
        local value = AA.State.finished
        return value ~= nil and value.Value == true
    end

    local function watchValue(parent, name, key, timeout)
        task.spawn(function()
            local value = parent:WaitForChild(name, timeout)
            if not value or not value:IsA("ValueBase") or not AA.Alive() then
                return
            end
            AA.State[key] = value
            value.Changed:Connect(function(new)
                AA.Emit(key, new)
            end)
            AA.Emit(key, value.Value)
        end)
    end

    ------------------------------------------------------
    -- ยูนิตใน workspace._UNITS (เริ่มตามเมื่อมีฟังก์ชันไหนต้องใช้)
    ------------------------------------------------------
    local unitsFolder, tracking, placedCount = nil, false, 0

    local function isMe(owner)
        return owner == LocalPlr or tostring(owner) == myName
    end

    local function untrack(model)
        local info = AA.MineInfo[model]
        if not info then
            return
        end
        AA.MineInfo[model] = nil
        local index = table.find(AA.Mine, model)
        if index then
            table.remove(AA.Mine, index)
        end
        AA.Emit("unitRemoved", model, info)
    end

    local function track(model)
        local stats = model:FindFirstChild("_stats") or model:WaitForChild("_stats", 3)
        if not stats or AA.MineInfo[model] then
            return
        end
        local player = stats:FindFirstChild("player") or stats:WaitForChild("player", 1.5)
        if not player then
            return
        end
        local owner = AA.ValueOf(player)
        if owner == nil then
            task.wait(0.25)   -- ค่ามาช้ากว่าตัวของมันนิดหน่อย
            owner = AA.ValueOf(player)
        end
        if not isMe(owner) or model.Parent ~= unitsFolder or AA.MineInfo[model] then
            return
        end
        local id, uuid = AA.ValueOf(stats:FindFirstChild("id")), AA.ValueOf(stats:FindFirstChild("uuid"))
        local upgrade = stats:FindFirstChild("upgrade")
        if upgrade and not (upgrade:IsA("ValueBase") and tonumber(upgrade.Value)) then
            upgrade = nil
        end
        placedCount = placedCount + 1
        local info = {
            model = model,
            id = id ~= nil and tostring(id) or model.Name,
            uuid = uuid ~= nil and tostring(uuid) or "",
            upgrade = upgrade,
            order = placedCount,
        }
        AA.MineInfo[model] = info
        table.insert(AA.Mine, model)
        AA.Emit("unit", model, info)
    end

    local function onUnitAdded(model)
        local stats = model:FindFirstChild("_stats")
        if stats then
            -- ศัตรู / ยูนิตของคนอื่น = จบตรงนี้เลย (ไม่ต้องสร้างงานใหม่ต่อศัตรู 1 ตัว)
            if AA.ValueOf(stats:FindFirstChild("base")) == "pve" then
                AA.Emit("enemy", model)
                return
            end
            local owner = AA.ValueOf(stats:FindFirstChild("player"))
            if owner ~= nil and not isMe(owner) then
                return
            end
        end
        task.spawn(track, model)
    end

    function AA.TrackUnits()
        if tracking or not AA.InMatch then
            return
        end
        tracking = true
        task.spawn(function()
            unitsFolder = workspace:WaitForChild("_UNITS", 120)
            if not unitsFolder or not AA.Alive() then
                tracking = false
                return
            end
            AA.State.units = unitsFolder
            unitsFolder.ChildAdded:Connect(onUnitAdded)
            unitsFolder.ChildRemoved:Connect(untrack)
            for _, model in ipairs(unitsFolder:GetChildren()) do
                onUnitAdded(model)
            end
        end)
    end

    ------------------------------------------------------
    -- โหวตเริ่มเกม (ใช้ร่วมกัน: สวิตช์เริ่มเกมอัตโนมัติ / มาโคร)
    --   ส่งทันทีที่เซิร์ฟพร้อม ยังไม่เริ่มก็ส่งใหม่ห่างขึ้นเรื่อยๆ (ไม่เกิน 8 ครั้ง) เวฟขยับเมื่อไหร่เลิกทันที
    --   wanted() = คนที่ขอยังต้องการอยู่ไหม (สวิตช์ยังเปิด / มาโครยังเล่น)
    ------------------------------------------------------
    local startWanted, startWaker, startBusy, lastVote = {}, AA.Waker(), false, -math.huge

    local function startStillWanted()
        local any = false
        for key, wanted in pairs(startWanted) do
            if wanted() then
                any = true
            else
                startWanted[key] = nil
            end
        end
        return any
    end

    function AA.VoteStart(key, wanted)
        if not AA.InMatch then
            return
        end
        startWanted[key] = wanted
        if startBusy then
            startWaker.wake()   -- มีงานโหวตอยู่แล้ว: ปลุกให้ดูใหม่ (ไม่ส่งซ้ำถี่กว่าช่วงที่กำหนด)
            return
        end
        startBusy = true
        task.spawn(function()
            local ready = workspace:FindFirstChild("SERVER_READY") or workspace:WaitForChild("SERVER_READY", 30)
            if ready and AA.ValueOf(ready) == false then
                AA.Await(60, function(resolve)
                    local conn = ready.Changed:Connect(function(value)
                        if value then
                            resolve(true)
                        end
                    end)
                    return function()
                        conn:Disconnect()
                    end
                end)
            end
            local offs = { AA.On("started", startWaker.wake), AA.On("wave", startWaker.wake) }
            local attempt = 0
            while attempt < 8 and AA.Alive() and not AA.Started() and not AA.Finished() and startStillWanted() do
                local gap = 2 + attempt * 2
                local since = os.clock() - lastVote
                if since >= gap then
                    attempt = attempt + 1
                    lastVote = os.clock()
                    task.spawn(AA.Call, "vote_start")
                    if AA.Endpoints() and not AA.Remote("vote_start") then
                        break   -- เกมไม่มีคำสั่งนี้ (แจ้งไปแล้วใน AA.Call) : ลองซ้ำไปก็ไม่ได้ผล
                    end
                    startWaker.sleep(2 + attempt * 2)
                else
                    startWaker.sleep(gap - since)
                end
            end
            for _, off in ipairs(offs) do
                off()
            end
            startBusy = false
        end)
    end

    ------------------------------------------------------
    -- เริ่มรอบ / จบรอบ
    ------------------------------------------------------
    if AA.InMatch then
        local lastWave, wasFinished, settling = 0, false, false

        -- เกมรีเซ็ตค่าไม่พร้อมกัน (เวฟ / สถานะจบเกม / เงิน / ยูนิต) และไม่รู้ว่าค่าไหนมาก่อน
        --   เห็นค่าไหนรีเซ็ตก็รอให้นิ่ง 1 วิ แล้วค่อยบอกว่า "เริ่มรอบใหม่" ครั้งเดียว (ยังอยู่หน้าสรุปผล = รอสถานะจบเกมเปลี่ยนก่อน)
        local function matchStart()
            if settling then
                return
            end
            settling = true
            task.delay(1, function()
                settling = false
                if AA.Alive() and not AA.Finished() then
                    wasFinished = false
                    AA.Emit("matchStart")
                end
            end)
        end

        AA.On("wave", function(wave)
            wave = tonumber(wave) or 0
            if wave < lastWave then
                matchStart()
            end
            lastWave = wave
        end)

        AA.On("finished", function(finished)
            if finished and not wasFinished then
                wasFinished = true
                AA.Emit("matchEnd")
            elseif not finished and wasFinished then
                wasFinished = false
                matchStart()
            end
        end)

        watchValue(workspace, "_wave_num", "wave", 120)
        watchValue(workspace, "_waves_started", "started", 120)
        task.spawn(function()
            local stats = LocalPlr:WaitForChild("_stats", 120)
            if stats then
                watchValue(stats, "resource", "money", 30)
            end
        end)
        task.spawn(function()
            local data = workspace:WaitForChild("_DATA", 120)
            if data then
                watchValue(data, "GameFinished", "finished", 30)
            end
        end)
        task.defer(function()
            local saved = AA.ReadJSON(SHAPE_FILE)
            if saved then
                AA.Shape.spawn = AA.Shape.spawn or saved.spawn
                AA.Shape.unit = AA.Shape.unit or saved.unit
            end
        end)
    end
end

----------------------------------------------------------
-- 🎮 Anime Adventures : คำสั่งกับยูนิต (วาง / อัปเกรด / ขาย / สกิล)
--   สำเร็จหรือไม่ ดูจากของจริงใน workspace._UNITS เท่านั้น
--   รูปแบบค่าที่ส่ง (ลองตามลำดับ แล้วจำแบบที่ใช้ได้):
--     วาง     : "ray" = (uuid, { Origin, Direction }, มุมหมุน)   /  "cf"   = (uuid, CFrame)
--     ยูนิต   : "name" = ชื่อ model ของยูนิต                       /  "inst" = ตัว model
----------------------------------------------------------
do
    local UP = Vector3.new(0, 1, 0)
    local rayParams = RaycastParams.new()
    rayParams.FilterType = Enum.RaycastFilterType.Exclude

    -- พื้นที่อยู่ใต้ตำแหน่งนี้
    function AA.GroundBelow(position, lift)
        return AA.RayHit(position + UP * (lift or 3), UP * -200)
    end

    -- ยิงเส้นหาพื้น / สิ่งกีดขวาง (ไม่นับยูนิต / ตัวละคร / ของที่เกมให้มองข้าม)
    function AA.RayHit(origin, direction)
        local exclude = {}
        if AA.State.units then
            exclude[#exclude + 1] = AA.State.units
        end
        if LocalPlr.Character then
            exclude[#exclude + 1] = LocalPlr.Character
        end
        local ignore = workspace:FindFirstChild("ignore")
        if ignore then
            exclude[#exclude + 1] = ignore
        end
        rayParams.FilterDescendantsInstances = exclude
        return workspace:Raycast(origin, direction, rayParams)
    end

    local function spawnArgs(shape, uuid, position)
        if shape == "cf" then
            return { uuid, CFrame.new(position) }
        end
        return { uuid, { Origin = position + UP * 6, Direction = -UP }, 0 }
    end

    local function unitRef(model, shape)
        if shape == "inst" then
            return model
        end
        return model.Name
    end

    local function unitShapes()
        local known = AA.Shape.unit
        if known then
            return { known }
        end
        return { "name", "inst" }
    end

    local spawnFails, unitFails = 0, 0

    -- วางยูนิต 1 ตัว: คืน model ถ้าเซิร์ฟสร้างยูนิตให้จริง
    --   rawArgs = ค่าที่อัดไว้จากเกมจริง (มาโคร) ถ้ามีจะส่งตามนั้นเป๊ะ
    function AA.PlaceUnit(uuid, position, rawArgs, grace)
        AA.TrackUnits()
        local shapes
        if rawArgs then
            shapes = { "raw" }
        elseif AA.Shape.spawn then
            shapes = { AA.Shape.spawn }
        else
            shapes = { "ray", "cf" }
        end

        for _, shape in ipairs(shapes) do
            local args = shape == "raw" and rawArgs or spawnArgs(shape, uuid, position)
            local count = args.n or #args
            AA.Emit("spawnCall", uuid, args, count)
            local model = AA.Await(5, function(resolve)
                local off = AA.On("unit", function(unit, info)
                    if info.uuid == "" or info.uuid == uuid then
                        resolve(unit)
                    end
                end)
                task.spawn(function()
                    local before = AA.Money()
                    AA.Call("spawn_unit", table.unpack(args, 1, count))
                    task.wait(grace or 0.75)
                    local after = AA.Money()
                    if before and after and after < before then
                        task.wait(2.5)   -- เงินลดแล้ว = เซิร์ฟรับคำสั่งแล้ว ยูนิตแค่โผล่ช้า: รอต่ออีกหน่อย (จะได้ไม่วางซ้ำ)
                    end
                    resolve(nil)
                end)
                return off
            end)
            if model then
                spawnFails = 0
                if shape ~= "raw" then
                    AA.Learn("spawn", shape)
                end
                return model
            end
        end
        -- รูปแบบที่จำไว้ใช้ไม่ได้ติดกัน 4 ครั้ง (เกมอาจอัปเดต) = ลืม แล้วครั้งหน้าลองทุกรูปแบบใหม่
        if not rawArgs and AA.Shape.spawn then
            spawnFails = spawnFails + 1
            if spawnFails >= 4 then
                spawnFails, AA.Shape.spawn = 0, nil
            end
        end
        return nil
    end

    local function unitShapeFailed()
        if AA.Shape.unit then
            unitFails = unitFails + 1
            if unitFails >= 4 then
                unitFails, AA.Shape.unit = 0, nil
            end
        end
    end

    function AA.UpgradeUnit(model, grace)
        local info = AA.MineInfo[model]
        local upgrade = info and info.upgrade
        if not upgrade then
            return false
        end
        local before = upgrade.Value
        for _, shape in ipairs(unitShapes()) do
            local done = AA.Act(5, grace or 0.75, function(resolve)
                local conn = upgrade.Changed:Connect(function()
                    if upgrade.Value > before then
                        resolve(true)
                    end
                end)
                return function()
                    conn:Disconnect()
                end
            end, "upgrade_unit_ingame", unitRef(model, shape))
            if done or upgrade.Value > before then
                unitFails = 0
                AA.Learn("unit", shape)
                return true
            end
        end
        unitShapeFailed()
        return false
    end

    function AA.SellUnit(model)
        AA.Emit("sellCall", model)
        for _, shape in ipairs(unitShapes()) do
            local gone = AA.Act(5, 0.75, function(resolve)
                local conn = model.AncestryChanged:Connect(function()
                    if not model:IsDescendantOf(workspace) then
                        resolve(true)
                    end
                end)
                return function()
                    conn:Disconnect()
                end
            end, "sell_unit_ingame", unitRef(model, shape))
            if gone or not model:IsDescendantOf(workspace) then
                unitFails = 0
                AA.Learn("unit", shape)
                return true
            end
        end
        unitShapeFailed()
        return false
    end

    -- สกิลไม่มีผลให้ดูในเกม: รู้รูปแบบแล้วส่งแบบนั้น / ยังไม่รู้ส่งทั้งสองแบบ (แบบที่ผิดเซิร์ฟจะไม่รับเอง)
    function AA.UseSkill(model)
        for _, shape in ipairs(unitShapes()) do
            task.spawn(AA.Call, "use_active_attack", unitRef(model, shape))
        end
    end

    -- ราคาอัปเกรดขั้นถัดไปจากข้อมูลของเกม: คืน ราคา (nil = ตันแล้ว / ไม่มีข้อมูล), เลเวลตอนนี้
    function AA.UpgradeCost(info)
        local level = info.upgrade and tonumber(info.upgrade.Value) or 0
        local data = AA.UnitData(info.id)
        local list = type(data) == "table" and data.upgrade
        local tier = type(list) == "table" and list[level + 1]
        if type(tier) ~= "table" then
            return nil, level
        end
        return tonumber(tier.cost) or 0, level
    end

    -- คูลดาวน์สกิลของยูนิตที่เลเวลตอนนี้ (nil = ยังไม่มีสกิล) / anyLevel = true คือดูทุกเลเวล (ยูนิตตัวนี้จะมีสกิลไหม)
    function AA.SkillCooldown(info, anyLevel)
        local data = AA.UnitData(info.id)
        if type(data) ~= "table" then
            return nil
        end
        -- active_attack = เลเวลที่ได้สกิล / active_attack_stats.attack_cooldown = คูลดาวน์ (เลเวลหลังๆ ปรับคูลดาวน์ได้อีก)
        local has, cooldown = false, nil
        local function read(entry)
            if type(entry) ~= "table" then
                return
            end
            if entry.active_attack then
                has = true
            end
            local stats = entry.active_attack_stats
            if type(stats) == "table" and tonumber(stats.attack_cooldown) then
                cooldown = tonumber(stats.attack_cooldown)
            end
        end
        read(data)
        if type(data.upgrade) == "table" then
            local level = info.upgrade and tonumber(info.upgrade.Value) or 0
            for tier = 1, anyLevel and #data.upgrade or math.min(level, #data.upgrade) do
                read(data.upgrade[tier])
            end
        end
        if not has then
            return nil
        end
        return cooldown or 30
    end
end

----------------------------------------------------------
-- 🔒 ล็อกการควบคุมตอนมาโครเล่น
--   กันทุกทาง แล้วคืนของเดิมทั้งหมดตอนหยุด:
--   1) ตัวละคร : ปิดการบังคับผ่าน PlayerModule ของเกม (GetControls():Enable(false)) ใช้ได้ทั้งคอม / มือถือ / จอย
--   2) กล้อง   : ตรึงเป็น Scriptable (หมุน / ซูมไม่ได้) เกมเปลี่ยนกลับเมื่อไหร่ก็ตรึงใหม่ทันที
--   3) จอ      : แผ่นใสเต็มจอกินการแตะ / ลาก / ล้อเมาส์ทั้งหมด (CameraInput ของเกมไม่นับการแตะที่ UI กินไปแล้ว)
--   4) ปุ่ม    : ContextActionService กินปุ่มคีย์บอร์ด / เมาส์ / จอย ที่ UI ไม่ได้กิน
--   5) ป้ายกด E ของเกม (ProximityPrompt) : ปิดชั่วคราว
--   ปุ่ม "หยุด" อยู่บนแผ่นใสเอง กดได้เสมอ (เมนูของสคริปก็ยังกดได้ตามปกติ)
----------------------------------------------------------
do
    local ContextActionService = game:GetService("ContextActionService")
    local ACTION = "XephexMacroLock"
    local locked = false
    local gui, label
    local saved, conns = {}, {}
    local onStop

    local function sinkInput()
        return Enum.ContextActionResult.Sink
    end

    local function playerControls()
        local ok, controls = pcall(function()
            local scripts = LocalPlr:FindFirstChild("PlayerScripts")
            local module = scripts and scripts:FindFirstChild("PlayerModule")
            return module and require(module):GetControls()
        end)
        if ok and type(controls) == "table" and type(controls.Enable) == "function" then
            return controls
        end
        return nil
    end

    local function buildGui()
        local playerGui = LocalPlr:FindFirstChildOfClass("PlayerGui")
        if not playerGui then
            return
        end

        -- อยู่เหนือ UI ของเกมทุกอัน แต่อยู่ใต้ปุ่มเปิดเมนูของสคริป
        local order = 998
        local toggleGui = playerGui:FindFirstChild("XephexToggleGui")
        for _, child in ipairs(playerGui:GetChildren()) do
            if child ~= toggleGui and child:IsA("ScreenGui") and child.DisplayOrder >= order then
                order = child.DisplayOrder + 1
            end
        end
        if toggleGui and toggleGui.DisplayOrder <= order then
            saved.toggleGui, saved.toggleOrder = toggleGui, toggleGui.DisplayOrder
            toggleGui.DisplayOrder = order + 1
        end

        gui = Instance.new("ScreenGui")
        gui.Name = "XephexMacroLock"
        gui.ResetOnSpawn = false
        gui.IgnoreGuiInset = true
        gui.DisplayOrder = order
        gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

        -- ScrollingFrame กินการลาก / ล้อเมาส์ / ซูมสองนิ้ว, ปุ่มข้างในกินการแตะ
        local scroll = Instance.new("ScrollingFrame")
        scroll.Size = UDim2.fromScale(1, 1)
        scroll.CanvasSize = UDim2.fromScale(0, 3)
        scroll.BackgroundTransparency = 1
        scroll.BorderSizePixel = 0
        scroll.ScrollBarThickness = 0
        scroll.ScrollingDirection = Enum.ScrollingDirection.Y
        scroll.ElasticBehavior = Enum.ElasticBehavior.Never
        scroll.Active = true
        scroll.Parent = gui

        local sink = Instance.new("TextButton")
        sink.Size = UDim2.fromScale(1, 3)
        sink.BackgroundTransparency = 1
        sink.AutoButtonColor = false
        sink.Text = ""
        sink.Active = true
        sink.Parent = scroll

        local bar = Instance.new("Frame")
        bar.AnchorPoint = Vector2.new(0.5, 0)
        bar.Position = UDim2.new(0.5, 0, 0, 10)
        bar.Size = UDim2.fromOffset(310, 44)
        bar.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
        bar.BackgroundTransparency = 0.1
        bar.BorderSizePixel = 0
        bar.Active = true
        bar.Parent = gui
        Instance.new("UICorner", bar).CornerRadius = UDim.new(0, 10)

        local stroke = Instance.new("UIStroke")
        stroke.Thickness = 1.5
        stroke.Color = Color3.fromRGB(0, 255, 200)
        stroke.Parent = bar

        label = Instance.new("TextLabel")
        label.BackgroundTransparency = 1
        label.Position = UDim2.fromOffset(12, 0)
        label.Size = UDim2.new(1, -118, 1, 0)
        label.Font = Enum.Font.GothamMedium
        label.TextSize = 14
        label.TextColor3 = Color3.new(1, 1, 1)
        label.TextXAlignment = Enum.TextXAlignment.Left
        label.TextTruncate = Enum.TextTruncate.AtEnd
        label.Text = ""
        label.Parent = bar

        local stop = Instance.new("TextButton")
        stop.AnchorPoint = Vector2.new(1, 0.5)
        stop.Position = UDim2.new(1, -6, 0.5, 0)
        stop.Size = UDim2.fromOffset(96, 32)
        stop.BackgroundColor3 = Color3.fromRGB(220, 53, 69)
        stop.BorderSizePixel = 0
        stop.Font = Enum.Font.GothamBold
        stop.TextSize = 15
        stop.TextColor3 = Color3.new(1, 1, 1)
        stop.Text = T("aa_lock_stop")
        stop.Parent = bar
        Instance.new("UICorner", stop).CornerRadius = UDim.new(0, 8)
        stop.MouseButton1Click:Connect(function()
            local callback = onStop
            if callback then
                task.spawn(callback)
            end
        end)

        gui.Parent = playerGui
    end

    function AA.Lock.On(stopCallback)
        if locked then
            return
        end
        locked = true
        onStop = stopCallback
        saved, conns = {}, {}

        local controls = playerControls()
        if controls then
            saved.controls, saved.controlsWere = controls, controls.controlsEnabled
            pcall(controls.Enable, controls, false)
        else
            -- ตัวรันที่ require PlayerModule ไม่ได้ -> ทำให้ตัวละครเดิน / กระโดดไม่ได้แทน
            local humanoid = LocalPlr.Character and LocalPlr.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then
                saved.humanoid = { humanoid, humanoid.WalkSpeed, humanoid.JumpPower, humanoid.JumpHeight }
                humanoid.WalkSpeed, humanoid.JumpPower, humanoid.JumpHeight = 0, 0, 0
            end
        end

        local camera = workspace.CurrentCamera
        if camera then
            saved.camera, saved.cameraType = camera, camera.CameraType
            camera.CameraType = Enum.CameraType.Scriptable
            conns[#conns + 1] = camera:GetPropertyChangedSignal("CameraType"):Connect(function()
                if locked and camera.CameraType ~= Enum.CameraType.Scriptable then
                    saved.cameraType = camera.CameraType   -- จำแบบที่เกมอยากได้ไว้คืนตอนหยุด
                    camera.CameraType = Enum.CameraType.Scriptable
                end
            end)
        end

        pcall(function()
            ContextActionService:BindActionAtPriority(ACTION, sinkInput, false, 10000,
                Enum.UserInputType.Keyboard, Enum.UserInputType.MouseButton1, Enum.UserInputType.MouseButton2,
                Enum.UserInputType.MouseButton3, Enum.UserInputType.MouseWheel, Enum.UserInputType.MouseMovement,
                Enum.UserInputType.Touch, Enum.UserInputType.Gamepad1)
        end)

        local prompts = safe(function()
            return game:GetService("ProximityPromptService")
        end)
        if prompts then
            saved.prompts, saved.promptsEnabled = prompts, prompts.Enabled
            prompts.Enabled = false
        end

        local ok, err = pcall(buildGui)
        if not ok then
            warn("[XEPHEX HUB] lock gui: " .. tostring(err))
        end
    end

    function AA.Lock.Off()
        if not locked then
            return
        end
        locked = false
        onStop = nil

        pcall(function()
            ContextActionService:UnbindAction(ACTION)
        end)
        for _, conn in ipairs(conns) do
            conn:Disconnect()
        end
        conns = {}

        if saved.controls then
            pcall(saved.controls.Enable, saved.controls, saved.controlsWere ~= false)
        end
        local humanoid = saved.humanoid
        if humanoid and humanoid[1].Parent then
            humanoid[1].WalkSpeed, humanoid[1].JumpPower, humanoid[1].JumpHeight = humanoid[2], humanoid[3], humanoid[4]
        end
        if saved.camera and saved.camera.Parent then
            saved.camera.CameraType = saved.cameraType
        end
        if saved.prompts then
            saved.prompts.Enabled = saved.promptsEnabled
        end
        if saved.toggleGui and saved.toggleGui.Parent then
            saved.toggleGui.DisplayOrder = saved.toggleOrder
        end
        if gui then
            gui:Destroy()
            gui, label = nil, nil
        end
        saved = {}
    end

    function AA.Lock.Text(text)
        if label then
            label.Text = text
        end
    end

    function AA.Lock.Active()
        return locked
    end
end

----------------------------------------------------------
-- 📡 ดักรีโมทของเกม (ใช้ 2 งาน: อัดมาโคร / บล็อกคำสั่งของผู้เล่นตอนมาโครเล่น)
--   ดักเฉพาะตอนที่ต้องใช้ แล้วถอดออกตอนเลิก (ไม่ทิ้งตัวดักไว้ถ่วงเกม)
--   ทางที่ 1: ครอบ EndpointsClient.invoke_server ของเกม (ใช้ได้ทุกตัวรัน)
--   ทางที่ 2: __namecall (ตัวรันที่มี hookmetamethod หรือ getrawmetatable) ดักได้แม้เกมเรียกรีโมทตรงๆ
--   คำสั่งของสคริปเองไม่ผ่านสองทางนี้ (ดู AA.Call) เลยไม่โดนบล็อก / ไม่ถูกอัดซ้ำ
--   บล็อกเฉพาะคำสั่งที่เป็น "การกระทำของผู้เล่น" (วาง / อัป / ขาย / โหวต / ซื้อ ...) คำสั่งอ่านข้อมูลของเกมปล่อยผ่าน
----------------------------------------------------------
do
    local hookMeta = type(hookmetamethod) == "function" and hookmetamethod or nil
    local callMethod = type(getnamecallmethod) == "function" and getnamecallmethod or nil
    local rawMeta = type(getrawmetatable) == "function" and getrawmetatable or nil
    local setReadOnly = type(setreadonly) == "function" and setreadonly or nil
    local asC = type(newcclosure) == "function" and newcclosure or function(fn)
        return fn
    end

    AA.Net.CanHook = callMethod ~= nil and (hookMeta ~= nil or (rawMeta ~= nil and setReadOnly ~= nil))

    local ACTION_PREFIXES = {
        "spawn_", "upgrade_", "sell_", "use_", "vote_", "cycle_", "set_", "toggle_", "teleport_",
        "buy_", "equip_", "unequip_", "switch_", "claim_", "redeem_", "open_", "accept_", "evolve_", "feed_",
        "craft_", "trade_", "skip_", "select_", "pick_", "choose_", "place_", "remove_", "swap_", "activate_",
        "cancel_", "start_", "leave_", "join_", "lock_", "change_", "apply_", "roll_", "reroll_",
    }

    local function isAction(name)
        for _, prefix in ipairs(ACTION_PREFIXES) do
            if name:sub(1, #prefix) == prefix then
                return true
            end
        end
        return false
    end

    local watch        -- remote -> ชื่อ (มีค่าเฉพาะตอนกำลังดัก)
    local watchNames   -- ชื่อ -> เป็นคำสั่งของผู้เล่นไหม
    local blocking = false
    local onCall
    local current      -- ตัวดัก __namecall ที่ติดอยู่ตอนนี้
    local wrapped      -- { service, fns } ของ EndpointsClient ที่ครอบไว้

    -- ตัวดัก 1 ตัวมีตัวแปรของตัวเอง: ถอดไม่ออก (ตัวรันบางตัว) ก็แค่ปล่อยผ่าน ไม่วนเรียกตัวเอง
    local function newHook()
        local enabled, real = true, nil
        local hook = {}

        hook.handler = function(self, ...)
            if enabled then
                local list = watch
                local name = list and list[self]
                if name then
                    local method = callMethod()
                    if method == "InvokeServer" or method == "FireServer" then
                        local callback = onCall
                        if callback then
                            pcall(callback, name, table.pack(...))
                        end
                        if blocking then
                            return nil
                        end
                    end
                end
            end
            return real(self, ...)
        end

        function hook.attach()
            local ok = false
            if hookMeta then
                ok = pcall(function()
                    real = hookMeta(game, "__namecall", asC(hook.handler))
                end) and type(real) == "function"
                hook.viaMeta = false
            end
            if not ok and rawMeta and setReadOnly then
                ok = pcall(function()
                    local meta = rawMeta(game)
                    local old = meta.__namecall
                    setReadOnly(meta, false)
                    real = old
                    meta.__namecall = asC(hook.handler)
                    setReadOnly(meta, true)
                end) and type(real) == "function"
                hook.viaMeta = ok
            end
            return ok
        end

        function hook.detach()
            enabled = false
            pcall(function()
                if hook.viaMeta then
                    local meta = rawMeta(game)
                    setReadOnly(meta, false)
                    meta.__namecall = real
                    setReadOnly(meta, true)
                else
                    hookMeta(game, "__namecall", real)
                end
            end)
        end

        return hook
    end

    local function wrapService()
        if wrapped then
            return
        end
        local service = AA.Service("EndpointsClient")
        if type(service) ~= "table" then
            return
        end
        wrapped = { service = service, fns = {} }
        for _, key in ipairs({ "invoke_server", "fire_server" }) do
            local real = rawget(service, key)
            if type(real) == "function" then
                wrapped.fns[key] = real
                service[key] = function(name, ...)
                    local names = watchNames
                    if names and type(name) == "string" then
                        local action = names[name]
                        if action == nil then
                            action = isAction(name)
                            names[name] = action
                        end
                        if action then
                            local callback = onCall
                            if callback and not current then   -- มีตัวดัก __namecall แล้ว = ให้ตัวนั้นอัด (ไม่อัดซ้ำ)
                                pcall(callback, name, table.pack(...))
                            end
                            if blocking then
                                return nil
                            end
                        end
                    end
                    return real(name, ...)
                end
            end
        end
        AA.RawInvoke = wrapped.fns.invoke_server
    end

    local function unwrapService()
        if not wrapped then
            return
        end
        for key, real in pairs(wrapped.fns) do
            wrapped.service[key] = real
        end
        wrapped = nil
        AA.RawInvoke = nil
    end

    -- record = ฟังก์ชันรับ (ชื่อคำสั่ง, ค่าที่ส่ง) หรือ nil / block = true คือไม่ให้คำสั่งของผู้เล่นออกไปถึงเซิร์ฟ
    --   คืน true ถ้าติดตัวดัก __namecall ได้
    function AA.Net.Start(record, block)
        watch, watchNames = {}, {}
        local folder = AA.Endpoints()
        if folder then
            for _, remote in ipairs(folder:GetChildren()) do
                local action = isAction(remote.Name)
                watchNames[remote.Name] = action
                if action then
                    watch[remote] = remote.Name
                end
            end
        end
        onCall, blocking = record, block == true
        wrapService()
        -- ตัวดัก __namecall ต้องทำงานกับ "ทุกคำสั่ง" ที่เกมเรียก (ถ่วงเครื่องช้า) เลยติดเฉพาะเมื่อจำเป็น:
        --   มีคีย์บอร์ด (ปุ่มลัดของเกมกดได้โดยไม่ผ่านจอ) หรือครอบ EndpointsClient ไม่ได้
        --   มือถือที่ครอบได้ = ไม่ติด เกมลื่นเท่าเดิม (ถ้าพบทีหลังว่าเกมส่งคำสั่งไม่ผ่านทางที่ครอบไว้ ค่อยติดเพิ่มด้วย AA.Net.Escalate)
        if wrapped == nil or UIS.KeyboardEnabled then
            AA.Net.Escalate()
        end
        return current ~= nil
    end

    -- ดักคำสั่งของเกมได้ไหม (ทางใดทางหนึ่ง) : ใช้บอกสถานะใน UI
    function AA.Net.CanSee()
        if AA.Net.CanHook then
            return true
        end
        local service = AA.Service("EndpointsClient")
        return type(service) == "table" and type(rawget(service, "invoke_server")) == "function"
    end

    -- ติดตัวดัก __namecall เพิ่ม (ถ้าตัวรันมี) : คืน true ถ้าติดอยู่
    function AA.Net.Escalate()
        if not current and watch and AA.Net.CanHook then
            local hook = newHook()
            if hook.attach() then
                current = hook
            end
        end
        return current ~= nil
    end

    function AA.Net.Stop()
        onCall, blocking, watch, watchNames = nil, false, nil, nil
        unwrapService()
        if current then
            current.detach()
            current = nil
        end
    end
end

----------------------------------------------------------
-- 🎬 มาโคร
--   ไฟล์: XEPHEX HUB/macros/<ชื่อ>.json   { version, map, steps = { ... } }
--   1 ขั้นตอน = { a = "place" / "upgrade" / "sell" / "skill" / "call", i = เลขยูนิตในมาโคร, wave, t, gt, cost, ... }
--     wave = เวฟตอนที่ทำ / t = วินาทีนับจากเวฟนั้นเริ่ม / gt = วินาทีนับจากเริ่มอัด / cost = เงินที่ใช้จริง
--   ตอนอัด: ดูผลจริงจากเกม (ยูนิตโผล่ / เลเวลขึ้น / ยูนิตหาย) + เก็บค่าที่เกมส่งให้เซิร์ฟตอนวาง (ถ้าตัวรันดักรีโมทได้)
--   ตอนเล่น: รอ "เวฟ + เวลา + เงิน" ตรงกับตอนอัด แล้วส่งคำสั่ง -> รอเห็นผลจริง -> ไม่สำเร็จลองใหม่ (ไม่ข้ามมั่ว)
--            วางแล้วจำ model ของยูนิตแต่ละตัวไว้ ขั้นตอนอัป / ขาย / สกิล จะสั่งถูกตัวเสมอ
----------------------------------------------------------
do
    local Macro = AA.Macro
    local MACRO_DIR = "XEPHEX HUB/macros"
    -- คำสั่งอื่นของผู้เล่นที่อัดเก็บไว้เล่นซ้ำตามเวลาเดิม (เปลี่ยนเป้าหมาย / โหวตข้ามเวฟ / เลือกการ์ด ...)
    --   โหวตเริ่มเกมไม่ต้องอัด: ตอนเล่น มาโครโหวตเริ่มเองเมื่อไม่มีอะไรให้ทำต่อจนกว่าเกมจะเริ่ม
    local RECORD_GENERIC = { "cycle_", "use_", "select_", "pick_", "choose_", "activate_", "swap_", "vote_wave" }

    Macro.recording = false
    Macro.playing = false
    Macro.memory = {}   -- มาโครที่อัดไว้ในรอบนี้ (สำหรับตัวรันที่เซฟไฟล์ไม่ได้)

    local function round2(seconds)
        return math.floor(seconds * 100 + 0.5) / 100
    end

    local function vec(list)
        return Vector3.new(list[1], list[2], list[3])
    end

    function Macro.CleanName(name)
        name = tostring(name or ""):gsub('[\\/:%*%?"<>|%c]', ""):match("^%s*(.-)%s*$")
        return name
    end

    function Macro.List()
        local names, seen = {}, {}
        if type(listfiles) == "function" and type(isfolder) == "function" then
            pcall(function()
                if not isfolder(MACRO_DIR) then
                    return
                end
                for _, path in ipairs(listfiles(MACRO_DIR)) do
                    local name = tostring(path):match("([^/\\]+)%.json$")
                    if name and not seen[name] then
                        seen[name] = true
                        names[#names + 1] = name
                    end
                end
            end)
        end
        for name in pairs(Macro.memory) do
            if not seen[name] then
                names[#names + 1] = name
            end
        end
        table.sort(names)
        return names
    end

    function Macro.Load(name)
        return Macro.memory[name] or AA.ReadJSON(MACRO_DIR .. "/" .. name .. ".json")
    end

    function Macro.Delete(name)
        Macro.memory[name] = nil
        pcall(function()
            delfile(MACRO_DIR .. "/" .. name .. ".json")
        end)
    end

    ------------------------------------------------------
    -- แปลงค่าที่ส่งให้เซิร์ฟ <-> ข้อมูลในไฟล์
    --   ยูนิตของเรา (ตัว model หรือชื่อ model) เก็บเป็นเลขยูนิตในมาโคร ตอนเล่นจะแทนด้วยตัวที่วางในรอบนั้น
    ------------------------------------------------------
    local function encode(value, unitOf, depth)
        local kind = typeof(value)
        if kind == "number" or kind == "boolean" then
            return value
        elseif kind == "string" then
            local index = unitOf(value)
            if index then
                return { __t = "UN", i = index }
            end
            return value
        elseif kind == "Vector3" then
            return { __t = "V3", v = { value.X, value.Y, value.Z } }
        elseif kind == "CFrame" then
            return { __t = "CF", v = { value:GetComponents() } }
        elseif kind == "Vector2" then
            return { __t = "V2", v = { value.X, value.Y } }
        elseif kind == "Instance" then
            local index = unitOf(value)
            if index then
                return { __t = "U", i = index }
            end
            return { __t = "I", p = value:GetFullName() }
        elseif kind == "table" and depth < 6 then
            local keys, values = {}, {}
            for key, item in pairs(value) do
                keys[#keys + 1] = encode(key, unitOf, depth + 1)
                values[#values + 1] = encode(item, unitOf, depth + 1)
            end
            return { __t = "T", k = keys, v = values }
        end
        return { __t = "nil" }
    end

    local function encodeArgs(args, count, unitOf)
        local out = {}
        for index = 1, count do
            out[index] = encode(args[index], unitOf, 0)
        end
        return { n = count, v = out }
    end

    local function findInstance(path)
        local current = game
        for name in tostring(path):gmatch("[^%.]+") do
            if current == game and name == "game" then
                continue
            end
            current = current:FindFirstChild(name)
            if not current then
                return nil
            end
        end
        return current
    end

    local function decode(value, units)
        if type(value) ~= "table" then
            return value
        end
        local kind = value.__t
        if kind == "V3" then
            return vec(value.v)
        elseif kind == "CF" then
            return CFrame.new(table.unpack(value.v))
        elseif kind == "V2" then
            return Vector2.new(value.v[1], value.v[2])
        elseif kind == "U" then
            return units[value.i]
        elseif kind == "UN" then
            local model = units[value.i]
            return model and model.Name or nil
        elseif kind == "I" then
            return findInstance(value.p)
        elseif kind == "T" then
            local out = {}
            for index, key in ipairs(value.k or {}) do
                local realKey = decode(key, units)
                if realKey ~= nil then
                    out[realKey] = decode(value.v[index], units)
                end
            end
            return out
        end
        return nil
    end

    -- คืนตารางค่าที่จะส่ง (มี n) / uuid ที่อัดไว้ถูกแทนด้วย uuid ของยูนิตที่ใส่อยู่ตอนนี้
    local function decodeArgs(packed, units, oldUuid, newUuid)
        local count = tonumber(packed.n) or #packed.v
        local out = { n = count }
        for index = 1, count do
            local value = decode(packed.v[index], units)
            if oldUuid and value == oldUuid then
                value = newUuid
            end
            out[index] = value
        end
        return out
    end

    ------------------------------------------------------
    -- อัด
    ------------------------------------------------------
    local rec

    -- ทิ้งรายการในคิวที่เก่าเกิน 2 วิ
    local function expire(queue, now)
        while queue[1] and now - queue[1].time > 2 do
            table.remove(queue, 1)
        end
    end

    local function addStep(step)
        local now = os.clock()
        step.wave = rec.wave
        step.t = round2(now - rec.waveAt)
        step.gt = round2(now - rec.start)
        rec.steps[#rec.steps + 1] = step

        -- เงินที่ลดตอนทำขั้นตอนนี้ = ราคาจริง (เฉพาะวาง / อัปเกรด)
        --   เงินลดมาก่อนหรือหลังขั้นตอนก็ได้: จับคู่ตามลำดับ (มาก่อนได้ก่อน) ภายใน 2 วิ
        if step.a == "place" or step.a == "upgrade" then
            expire(rec.drops, now)
            local drop = table.remove(rec.drops, 1)
            if drop then
                step.cost = drop.amount
            else
                rec.unpaid[#rec.unpaid + 1] = { step = step, time = now }
            end
        end
        if rec.status then
            rec.status(#rec.steps)
        end
        return step
    end

    local function unitIndex(value)
        if type(value) == "string" then
            return rec.names[value]
        end
        return rec.index[value]
    end

    local function register(model, info)
        rec.count = rec.count + 1
        local index = rec.count
        rec.index[model] = index
        rec.names[model.Name] = index

        local upgrade = info.upgrade
        if upgrade then
            local last = tonumber(upgrade.Value) or 0
            rec.conns[#rec.conns + 1] = upgrade.Changed:Connect(function(level)
                level = tonumber(level) or last
                for nextLevel = last + 1, level do
                    addStep({ a = "upgrade", i = index, lvl = nextLevel })
                end
                last = level
            end)
        end
        return index
    end

    local function placeStep(model, info, spawn)
        local index = register(model, info)
        local step = addStep({
            a = "place",
            i = index,
            unit = info.id,
            uuid = info.uuid ~= "" and info.uuid or (spawn and spawn.uuid) or nil,
            args = spawn and spawn.args or nil,
        })
        local function setPosition(root)
            local position = root.Position
            step.pos = { position.X, position.Y, position.Z }
        end
        local root = AA.RootOf(model)
        if root then
            setPosition(root)
        else
            task.spawn(function()
                root = model:WaitForChild("HumanoidRootPart", 3)
                if root and root:IsA("BasePart") then
                    setPosition(root)
                end
            end)
        end
    end

    -- จุดที่คำสั่งวางชี้ไป (ไว้จับคู่คำสั่งกับยูนิตที่โผล่)
    local function landing(args)
        local where = args[2]
        local kind = typeof(where)
        if kind == "CFrame" then
            return where.Position
        end
        if kind == "table" and typeof(where.Origin) == "Vector3" and typeof(where.Direction) == "Vector3" and where.Direction.Magnitude > 0 then
            local hit = AA.RayHit(where.Origin, where.Direction.Unit * 1000)
            return hit and hit.Position or nil
        end
        return nil
    end

    -- คำสั่งวางที่ส่งไปแล้ว รอจับคู่กับยูนิตที่โผล่ (uuid ต้องตรงกัน)
    --   วางยูนิตชนิดเดียวกันติดๆ กัน: เลือกคำสั่งที่ชี้ใกล้ตัวยูนิตที่สุด / ไม่รู้จุดก็เอาคำสั่งเก่าสุด
    local function takeSpawn(uuid, model)
        local now = os.clock()
        for index = #rec.spawns, 1, -1 do
            if now - rec.spawns[index].time > 8 then
                table.remove(rec.spawns, index)
            end
        end
        local root = AA.RootOf(model)
        local best, bestDistance
        for index, spawn in ipairs(rec.spawns) do
            if spawn.uuid == uuid or spawn.uuid == nil or uuid == "" then
                local distance = math.huge
                if root and spawn.spot then
                    local offset = root.Position - spawn.spot
                    distance = offset.X * offset.X + offset.Z * offset.Z
                end
                if not best or distance < bestDistance then
                    best, bestDistance = index, distance
                end
            end
        end
        if best then
            return table.remove(rec.spawns, best)
        end
        return nil
    end

    local function modelOf(value)
        if typeof(value) == "Instance" then
            return rec.index[value] and value or nil
        end
        if type(value) == "string" then
            for model in pairs(rec.index) do
                if model.Name == value then
                    return model
                end
            end
        end
        return nil
    end

    -- คำสั่งที่เกมส่งเอง (ผู้เล่นกดในเกม) : ถูกเรียกจากตัวดักรีโมท ต้องเร็ว เลยแค่เข้าคิวไว้
    local function flushCalls()
        if not rec then
            return
        end
        local queue = rec.queue
        rec.queue, rec.flushing = {}, false
        for _, call in ipairs(queue) do
            local name, args = call[1], call[2]
            if name == "spawn_unit" then
                -- เกมส่งแบบไหน สคริปก็ใช้แบบนั้น
                local second = typeof(args[2])
                if second == "CFrame" then
                    AA.Learn("spawn", "cf")
                elseif second == "table" then
                    AA.Learn("spawn", "ray")
                end
                rec.sees = true   -- คำสั่งวางของเกมผ่านตัวดักของเรา
                rec.spawns[#rec.spawns + 1] = {
                    uuid = type(args[1]) == "string" and args[1] or nil,
                    args = encodeArgs(args, args.n, unitIndex),
                    spot = landing(args),
                    time = call[3],
                }
            elseif name == "upgrade_unit_ingame" or name == "sell_unit_ingame" or name == "use_active_attack" then
                local first = typeof(args[1])
                if first == "Instance" then
                    AA.Learn("unit", "inst")
                elseif first == "string" then
                    AA.Learn("unit", "name")
                end
                local model = modelOf(args[1])
                if model and name == "sell_unit_ingame" then
                    addStep({ a = "sell", i = rec.index[model] })
                    rec.sold[model] = true
                elseif model and name == "use_active_attack" then
                    addStep({ a = "skill", i = rec.index[model] })
                end
            else
                for _, prefix in ipairs(RECORD_GENERIC) do
                    if name:sub(1, #prefix) == prefix then
                        addStep({ a = "call", n = name, args = encodeArgs(args, args.n, unitIndex) })
                        break
                    end
                end
            end
        end
    end

    local function onGameCall(name, args)
        local current = rec
        if not current then
            return
        end
        current.queue[#current.queue + 1] = { name, args, os.clock() }
        if not current.flushing then
            current.flushing = true
            task.defer(flushCalls)
        end
    end

    -- status(จำนวนขั้นตอน) ถูกเรียกทุกครั้งที่อัดได้เพิ่ม
    function Macro.StartRecord(status)
        if Macro.recording or Macro.playing or not AA.InMatch then
            return false
        end
        AA.TrackUnits()
        local now = os.clock()
        rec = {
            steps = {}, index = {}, names = {}, count = 0, sold = {},
            start = now, waveAt = now, wave = AA.Wave(),
            spawns = {}, queue = {}, flushing = false,
            money = AA.Money(), drops = {}, unpaid = {},
            offs = {}, conns = {}, status = status,
        }
        Macro.recording = true
        -- sees = เห็นคำสั่งของเกมไหม: ติดตัวดัก __namecall = เห็นแน่นอน / ทางที่ครอบไว้ = รู้เมื่อคำสั่งวางแรกผ่านมา
        rec.sees = AA.Net.Start(onGameCall, false)

        -- ยูนิตที่วางไว้ก่อนเริ่มอัด = ขั้นตอนแรกของมาโคร (มาโครเล่นตั้งแต่ต้นได้ครบ)
        for _, model in ipairs(AA.Mine) do
            local info = AA.MineInfo[model]
            if info then
                placeStep(model, info, nil)
                -- เลเวลที่อัปไว้แล้วก็เป็นขั้นตอนด้วย (ตอนเล่นจะได้ยูนิตเลเวลเท่าเดิม)
                for level = 1, info.upgrade and tonumber(info.upgrade.Value) or 0 do
                    addStep({ a = "upgrade", i = rec.index[model], lvl = level })
                end
            end
        end
        rec.unpaid = {}   -- ของที่จ่ายไปก่อนเริ่มอัด ไม่มีเงินให้จับคู่: ราคาใช้จากข้อมูลของเกมตอนเซฟ

        rec.offs = {
            AA.On("unit", function(model, info)
                if rec.index[model] then
                    return
                end
                local spawn = takeSpawn(info.uuid, model)
                if not spawn then
                    if rec.sees or info.uuid == "" then
                        return   -- เห็นคำสั่งของเกมอยู่ แต่ตัวนี้ไม่มีคำสั่งวาง = ไม่ได้มาจากการกดวาง (เช่น ยูนิตที่ยูนิตตัวอื่นเรียกออกมา)
                    end
                    -- เกมส่งคำสั่งวางไม่ผ่านทางที่ครอบไว้: ตัวนี้อัดจากผลจริง แล้วติดตัวดัก __namecall เพิ่ม (ถ้าตัวรันมี)
                    rec.sees = AA.Net.Escalate()
                end
                placeStep(model, info, spawn)
            end),
            AA.On("unitRemoved", function(model)
                -- ไม่เห็นคำสั่งของเกม = ยูนิตของเราหายไประหว่างรอบ ถือว่าขาย
                local index = rec.index[model]
                if index and not rec.sold[model] and not rec.sees and not AA.Finished() then
                    addStep({ a = "sell", i = index })
                end
            end),
            AA.On("spawnCall", function(uuid, args, count)
                rec.spawns[#rec.spawns + 1] = { uuid = uuid, args = encodeArgs(args, count, unitIndex), spot = landing(args), time = os.clock() }
            end),
            AA.On("sellCall", function(model)
                local index = rec.index[model]
                if index and not rec.sold[model] then
                    rec.sold[model] = true
                    addStep({ a = "sell", i = index })
                end
            end),
            AA.On("wave", function(wave)
                rec.wave, rec.waveAt = tonumber(wave) or 0, os.clock()
            end),
            AA.On("money", function(money)
                money = tonumber(money)
                local before = rec.money
                rec.money = money
                if not (money and before and money < before) then
                    return
                end
                local amount, time = before - money, os.clock()
                expire(rec.unpaid, time)
                local waiting = table.remove(rec.unpaid, 1)
                if waiting then
                    waiting.step.cost = amount
                else
                    rec.drops[#rec.drops + 1] = { amount = amount, time = time }
                end
            end),
        }
        return true
    end

    -- คืน จำนวนขั้นตอน, ชื่อไฟล์ที่เซฟ (nil = ไม่มีอะไรให้เซฟ)  *หยุดรอได้ (ถามชื่อด่าน)*
    function Macro.StopRecord(name)
        local current = rec
        if not current then
            return 0, nil
        end
        rec = nil
        Macro.recording = false
        AA.Net.Stop()
        for _, off in ipairs(current.offs) do
            off()
        end
        for _, conn in ipairs(current.conns) do
            conn:Disconnect()
        end

        local steps = current.steps
        if #steps == 0 then
            return 0, nil
        end

        -- ราคาของแต่ละขั้นตอน = เงินที่ลดจริงตอนอัด โดยเทียบกับราคาจากข้อมูลของเกมอีกชั้น:
        --   จับเงินไม่ทัน = ใช้ราคาของเกม
        --   วัดได้ต่างจากราคาของเกมไม่เกิน 10% (มีเงินเข้ามาจังหวะเดียวกับตอนจ่าย) = ใช้ราคาของเกม (ตัวเลขเป๊ะกว่า)
        --   ต่างมากกว่านั้น (ส่วนลด / ตัวคูณที่ข้อมูลไม่ได้บอก) = เชื่อเงินที่ลดจริง
        local scale = AA.CostScale()
        local unitOf = {}
        for _, step in ipairs(steps) do
            if step.a == "place" then
                unitOf[step.i] = step.unit
            end
            if step.a == "place" or step.a == "upgrade" then
                local data = AA.UnitData(unitOf[step.i])
                if type(data) == "table" then
                    local tier = step.a == "upgrade" and type(data.upgrade) == "table" and data.upgrade[step.lvl]
                    local cost = step.a == "place" and data.cost or (type(tier) == "table" and tier.cost)
                    local known = tonumber(cost) and math.ceil(cost * scale)
                    if known and (not step.cost or math.abs(step.cost - known) <= known * 0.1) then
                        step.cost = known
                    end
                end
            end
        end

        local map = AA.MapKey()
        name = Macro.CleanName(name)
        if name == "" then
            name = map or ("macro_" .. os.time())
        end
        local data = { version = 1, game = "Anime Adventures", map = map, created = os.time(), steps = steps }
        if not AA.WriteJSON(MACRO_DIR .. "/" .. name .. ".json", data) then
            Macro.memory[name] = data
        end
        return #steps, name
    end

    ------------------------------------------------------
    -- เล่น
    ------------------------------------------------------
    local runId = 0
    local run   -- { offs, waker, lock, status }

    -- reason: "user" = กดหยุด / "end" = จบรอบ
    function Macro.Stop(reason)
        local current = run
        if not current then
            return
        end
        run = nil
        runId = runId + 1
        Macro.playing = false
        for _, off in ipairs(current.offs) do
            off()
        end
        if current.lock then
            AA.Net.Stop()
            AA.Lock.Off()
        end
        current.waker.wake()
        if current.status then
            current.status(nil, reason)
        end
    end

    -- ยูนิตของเราที่ยืนอยู่ตรงจุดของขั้นตอนนี้ และยังไม่ถูกจับคู่ (วางไปแล้วแต่ยูนิตโผล่ช้า / เล่นมาโครซ้ำกลางรอบ)
    local function findPlaced(units, step)
        if not step.pos then
            return nil
        end
        local target = vec(step.pos)
        local taken = {}
        for _, model in pairs(units) do
            taken[model] = true
        end
        for _, model in ipairs(AA.Mine) do
            local info = AA.MineInfo[model]
            local root = not taken[model] and info and info.id == step.unit and AA.RootOf(model)
            if root then
                -- วัดแนวราบอย่างเดียว (ตอนอัด ยูนิตอาจยังลอยอยู่ในท่าลงพื้น)
                local offset = root.Position - target
                if offset.X * offset.X + offset.Z * offset.Z < 6.25 then
                    return model
                end
            end
        end
        return nil
    end

    local function uuidFor(step)
        local fallback
        for _, unit in ipairs(AA.Equipped()) do
            if unit.uuid == step.uuid then
                return unit.uuid
            end
            if unit.id == step.unit and not fallback then
                fallback = unit.uuid
            end
        end
        return fallback or step.uuid
    end

    -- options: sync = "Wave + Time" / "Money", lock = true/false, onStop = ตอนกดปุ่มหยุดบนจอ
    --          status(ข้อความ, เหตุผลที่จบ) = อัปเดตสถานะ
    function Macro.Play(name, data, options)
        if Macro.playing or Macro.recording or not AA.InMatch then
            return false
        end
        local steps = data.steps
        runId = runId + 1
        local id = runId
        local waker = AA.Waker()
        local units = {}                     -- เลขยูนิตในมาโคร -> model ในรอบนี้
        local start = os.clock()
        local wave, waveAt = AA.Wave(), start

        Macro.playing = true
        AA.TrackUnits()
        run = { waker = waker, lock = options.lock, status = options.status }
        local needMoney   -- เงินที่ขั้นตอนถัดไปรออยู่ (เงินขยับแต่ยังไม่ถึง = ไม่ต้องปลุกงาน)
        run.offs = {
            AA.On("money", function(money)
                if needMoney and (tonumber(money) or 0) >= needMoney then
                    needMoney = nil
                    waker.wake()
                end
            end),
            AA.On("unit", waker.wake),
            AA.On("wave", function(value)
                wave, waveAt = tonumber(value) or 0, os.clock()
                waker.wake()
            end),
            AA.On("matchEnd", function()
                Macro.Stop("end")
            end),
        }
        if options.lock then
            -- ปุ่มหยุดบนจอ: หยุดมาโครก่อน (ปลดล็อกแน่นอน) แล้วค่อยให้ UI ปิดสวิตช์ตาม
            AA.Lock.On(function()
                Macro.Stop("user")
                if options.onStop then
                    options.onStop()
                end
            end)
            AA.Net.Start(nil, true)
        end

        local function alive()
            return runId == id and AA.Alive()
        end

        -- ยังไม่เริ่มเกม และไม่มีอะไรให้ทำต่อจนกว่าเกมจะเริ่ม = มาโครโหวตเริ่มเอง (ตอนล็อก ผู้เล่นกดเริ่มเองไม่ได้)
        local startAsked = -math.huge

        local function needStart()
            if AA.State.wave and wave == 0 and os.clock() - startAsked > 30 then
                startAsked = os.clock()
                AA.VoteStart("macro", alive)
            end
        end

        local function report(text)
            if options.status then
                options.status(text)
            end
            AA.Lock.Text(text)
        end

        -- ถึงจังหวะของขั้นตอนนี้หรือยัง: คืน true / false + อีกกี่วินาที (ถ้ารู้)
        local function ready(step)
            if options.sync ~= "Money" then
                if AA.State.wave then
                    local stepWave = tonumber(step.wave) or 0
                    if wave < stepWave then
                        needStart()
                        return false
                    end
                    -- เวฟ 0 (ยังไม่เริ่มเกม) ไม่ต้องรอเวลา: ไม่มีศัตรู ไม่มีเงินเข้า ทำตามลำดับได้เลย
                    if wave == stepWave and stepWave > 0 then
                        local remain = (tonumber(step.t) or 0) - (os.clock() - waveAt)
                        if remain > 0 then
                            return false, remain
                        end
                    end
                else
                    local remain = (tonumber(step.gt) or 0) - (os.clock() - start)
                    if remain > 0 then
                        return false, remain
                    end
                end
            end
            local money, cost = AA.Money(), tonumber(step.cost)
            if money and cost and money < cost then
                needMoney = cost
                needStart()   -- เงินไม่พอและเกมยังไม่เริ่ม = เงินจะไม่เพิ่มจนกว่าจะเริ่ม
                return false
            end
            needMoney = nil
            return true
        end

        local function place(step)
            for attempt = 1, 10 do
                if not alive() then
                    return false
                end
                local model = findPlaced(units, step)
                if not model then
                    local uuid = uuidFor(step)
                    local raw = step.args and attempt <= 3 and decodeArgs(step.args, units, step.uuid, uuid) or nil
                    local position
                    if step.pos then
                        local hit = AA.GroundBelow(vec(step.pos), 3)
                        position = hit and hit.Position or vec(step.pos)
                    end
                    if uuid and (raw or position) then
                        model = AA.PlaceUnit(uuid, position, raw, 1.5)
                    end
                end
                if model then
                    units[step.i] = model
                    return true
                end
                waker.sleep(1)   -- เงินขยับ / ยูนิตโผล่ / ครบ 1 วิ แล้วลองใหม่
            end
            return false
        end

        local function upgrade(step)
            local model = units[step.i]
            local info = model and AA.MineInfo[model]
            local target = tonumber(step.lvl) or 0
            for _ = 1, 10 do
                if not alive() or not (info and info.upgrade and model.Parent) then
                    return false
                end
                if info.upgrade.Value >= target then
                    return true
                end
                if not AA.UpgradeUnit(model, 1.2) then
                    waker.sleep(1)
                end
            end
            return info.upgrade.Value >= target
        end

        local function perform(step)
            local kind = step.a
            if kind == "place" then
                return place(step)
            elseif kind == "upgrade" then
                return upgrade(step)
            end
            local model = units[step.i]
            if kind == "sell" then
                if model and model.Parent then
                    return AA.SellUnit(model)
                end
                return true
            elseif kind == "skill" then
                if model and model.Parent then
                    AA.UseSkill(model)
                end
                return true
            elseif kind == "call" and type(step.n) == "string" and type(step.args) == "table" then
                local args = decodeArgs(step.args, units)
                task.spawn(AA.Call, step.n, table.unpack(args, 1, args.n))
                return true
            end
            return true
        end

        task.spawn(function()
            local total = #steps
            for index, step in ipairs(steps) do
                report(T("aa_macro_playing") .. name .. "  " .. (index - 1) .. "/" .. total)
                while alive() do
                    local ok, remain = ready(step)
                    if ok then
                        break
                    end
                    waker.sleep(remain)
                end
                if not alive() then
                    return
                end
                if not perform(step) and alive() then
                    Notify(T("aa_macro_step_fail") .. index .. " (" .. tostring(step.a) .. ")", 3)
                end
            end
            if alive() then
                -- ครบแล้ว: ยังล็อกต่อจนจบรอบ หรือจนกดหยุด
                report(T("aa_macro_done") .. "  " .. total .. "/" .. total)
            end
        end)
        return true
    end

    -- รันสคริปซ้ำตอนมาโครเล่นอยู่: ตัวเก่าปลดล็อก + ถอดตัวดักของตัวเองก่อนตัวใหม่เริ่ม
    table.insert(AA.Shutdown, function()
        Macro.Stop("user")
        AA.Net.Stop()
        AA.Lock.Off()
    end)
end

----------------------------------------------------------
-- 🤖 Auto Play : วาง / อัปเกรด / ใช้สกิล
--   งานเบื้องหลัง 1 ตัว หลับอยู่จนกว่าจะมีเหตุการณ์ (เงินถึงราคาที่รออยู่ / ยูนิตโผล่ / ยูนิตหาย / เวฟเปลี่ยน)
--   ราคา  : จากข้อมูลของเกม (Data.Units) x ตัวคูณของด่าน แล้วปรับตามเงินที่ลดจริงหลังทำสำเร็จ
--   จุดวาง: ข้างทางเดินของศัตรู -> ทางเดินจาก workspace._BASES (ถ้ามี) / ไฟล์ที่จำไว้ / ดูจากศัตรูตัวแรกที่เดินผ่าน
--           วางไม่ได้ (เซิร์ฟไม่สร้างยูนิต) = ข้ามจุดนั้นไปจุดถัดไป
----------------------------------------------------------
do
    local Auto = AA.Auto
    local flags = AA.Flags
    local PATH_FILE = "XEPHEX HUB/aa_paths.json"

    local waker = AA.Waker()
    local workerId = 0
    local needMoney = math.huge   -- เงินขั้นต่ำที่ทำอะไรต่อได้ (เงินยังไม่ถึง = ไม่ต้องปลุกงาน)
    local path, pathKey, learning = nil, nil, false
    local spots                   -- จุดวางของรอบนี้ { list, hill, bad }
    local shift = 0               -- เลื่อนจุดวางไปตามทางเดินเมื่อจุดรอบๆ เต็ม
    local blocked = {}            -- ลองแล้วไม่สำเร็จ: key -> { money, time } รอเงินเพิ่ม / รอเวลาก่อนลองใหม่
    local fails = {}
    local scaleOf = {}            -- uuid -> ตัวคูณราคาจริง (วัดจากเงินที่ลด)
    local levelScale = 1
    local teamTries, warned = 0, {}

    function Auto.Wake()
        waker.wake()
    end

    function Auto.Reset(keepCenter)
        spots, shift, blocked, fails, warned, teamTries = nil, 0, {}, {}, {}, 0
        if not keepCenter then
            Auto.center = nil
        end
    end

    local function warnOnce(key)
        if not warned[key] then
            warned[key] = true
            Notify(T(key), 4)
        end
    end

    ------------------------------------------------------
    -- ทางเดินของศัตรู
    ------------------------------------------------------
    local function lanePath()
        local bases = workspace:FindFirstChild("_BASES")
        if not bases then
            return nil
        end
        local pve = bases:FindFirstChild("pve")
        local lanes = (pve and pve:FindFirstChild("LANES")) or bases:FindFirstChild("LANES", true)
        local lane = lanes and (lanes:FindFirstChild("1") or lanes:GetChildren()[1])
        if not lane then
            return nil
        end
        local points = {}
        for _, part in ipairs(lane:GetDescendants()) do
            if part:IsA("BasePart") then
                local rank = tonumber(part.Name) or (part.Name == "spawn" and 0) or (part.Name == "final" and math.huge)
                if rank then
                    points[#points + 1] = { rank = rank, position = part.Position }
                end
            end
        end
        if #points < 2 then
            return nil
        end
        table.sort(points, function(a, b)
            return a.rank < b.rank
        end)
        local out = {}
        for index, point in ipairs(points) do
            out[index] = point.position
        end
        return out
    end

    local function savePath()
        if not (pathKey and path) then
            return
        end
        local all = AA.ReadJSON(PATH_FILE) or {}
        local list = {}
        for index, point in ipairs(path) do
            list[index] = { math.floor(point.X * 10) / 10, math.floor(point.Y * 10) / 10, math.floor(point.Z * 10) / 10 }
        end
        all[pathKey] = list
        AA.WriteJSON(PATH_FILE, all)
    end

    local function loadPath()
        local level = AA.Level()
        pathKey = level and tostring(level.map or level.id or level.name or "") or nil
        if pathKey == "" then
            pathKey = nil
        end
        local all = pathKey and AA.ReadJSON(PATH_FILE)
        local saved = all and all[pathKey]
        if type(saved) ~= "table" or #saved < 2 then
            return nil
        end
        local points = {}
        for index, point in ipairs(saved) do
            points[index] = Vector3.new(point[1], point[2], point[3])
        end
        return points
    end

    -- ยังไม่รู้ทางเดิน: ตามศัตรูตัวแรก 1 ตัว จดตำแหน่งทุกครึ่งวิ (ไม่เกิน 30 วิ) แล้วจำลงไฟล์ รอบหน้าไม่ต้องทำอีก
    local function learnPath(model)
        if learning or (path and #path >= 2) then
            return
        end
        learning = true
        task.spawn(function()
            local root = AA.RootOf(model) or model:WaitForChild("HumanoidRootPart", 2)
            if root and not root:IsA("BasePart") then
                root = nil
            end
            local points = {}
            local deadline = os.clock() + 30
            while root and root.Parent and model.Parent and os.clock() < deadline and #points < 60 do
                local position = root.Position
                local last = points[#points]
                if not last or (position - last).Magnitude > 3 then
                    points[#points + 1] = position
                    if #points == 3 then
                        path, spots = points, nil   -- รู้ช่วงต้นทางแล้ว เริ่มวางได้เลย
                        waker.wake()
                    end
                end
                task.wait(0.5)
            end
            learning = false
            if #points >= 3 then
                path = points
                savePath()
            end
        end)
    end

    local function pathPoint(percent)
        local lengths, total = {}, 0
        for index = 1, #path - 1 do
            local length = (path[index + 1] - path[index]).Magnitude
            lengths[index] = length
            total = total + length
        end
        local target = total * math.clamp(percent, 0, 100) / 100
        for index = 1, #path - 1 do
            if target <= lengths[index] or index == #path - 1 then
                local alpha = lengths[index] > 0 and math.clamp(target / lengths[index], 0, 1) or 0
                return path[index]:Lerp(path[index + 1], alpha)
            end
            target = target - lengths[index]
        end
        return path[1]
    end

    -- ใกล้เส้นทางเดินเกินไปไหม (วัดแนวราบ) : บนถนนวางยูนิตไม่ได้
    local function onPath(position, limit)
        for index = 1, #path - 1 do
            local a, b = path[index], path[index + 1]
            local ab = Vector3.new(b.X - a.X, 0, b.Z - a.Z)
            local ap = Vector3.new(position.X - a.X, 0, position.Z - a.Z)
            local lengthSq = ab:Dot(ab)
            local alpha = lengthSq > 0 and math.clamp(ap:Dot(ab) / lengthSq, 0, 1) or 0
            if (ap - ab * alpha).Magnitude < limit then
                return true
            end
        end
        return false
    end

    ------------------------------------------------------
    -- จุดวาง
    ------------------------------------------------------
    local function buildSpots()
        local center, usePath
        if flags.placeMode == "My Position" then
            center = Auto.center
            if not center then
                local root = LocalPlr.Character and LocalPlr.Character:FindFirstChild("HumanoidRootPart")
                center = root and root.Position
                Auto.center = center
            end
        else
            path = path or lanePath()
            if not path or #path < 2 then
                return nil
            end
            usePath = true
            center = pathPoint((flags.pathPercent or 30) + shift)
        end
        if not center then
            return nil
        end

        -- วงแหวนรอบจุดกลาง จากใกล้ไปไกล
        local list = {}
        for ring = 1, 5 do
            local radius = 3 + ring * 3.5
            local count = 6 + ring * 2
            for index = 1, count do
                local angle = (index / count) * math.pi * 2 + ring * 0.4
                local candidate = center + Vector3.new(math.cos(angle) * radius, 0, math.sin(angle) * radius)
                if not usePath or not onPath(candidate, 3.5) then
                    list[#list + 1] = candidate
                end
            end
        end
        return { list = list, center = center, bad = {} }
    end

    local function hillFolder()
        local terrain = workspace:FindFirstChild("_terrain")
        return terrain and terrain:FindFirstChild("hill") or nil
    end

    -- ยูนิตที่ต้องวางบนที่สูง: ใช้ผิวบนของชิ้นส่วนที่สูง เรียงจากใกล้จุดกลาง
    local function hillSpots(center)
        local hill = hillFolder()
        if not hill then
            return nil
        end
        local list = {}
        for _, part in ipairs(hill:GetDescendants()) do
            if part:IsA("BasePart") then
                local top = part.Position + Vector3.new(0, part.Size.Y / 2, 0)
                list[#list + 1] = top
                if part.Size.X > 8 or part.Size.Z > 8 then
                    list[#list + 1] = top + Vector3.new(3, 0, 0)
                    list[#list + 1] = top + Vector3.new(-3, 0, 0)
                    list[#list + 1] = top + Vector3.new(0, 0, 3)
                    list[#list + 1] = top + Vector3.new(0, 0, -3)
                end
                if #list >= 200 then
                    break
                end
            end
        end
        table.sort(list, function(a, b)
            return (a - center).Magnitude < (b - center).Magnitude
        end)
        return list
    end

    local function groundAt(candidate, wantHill)
        local hit = AA.GroundBelow(candidate, 25)
        if not hit then
            return nil
        end
        local road = workspace:FindFirstChild("_road")
        if road and hit.Instance:IsDescendantOf(road) then
            return nil
        end
        local hill = hillFolder()
        if hill and wantHill ~= nil and hit.Instance:IsDescendantOf(hill) ~= wantHill then
            return nil
        end
        return hit.Position
    end

    local function isFree(position)
        for _, model in ipairs(AA.Mine) do
            local root = AA.RootOf(model)
            if root then
                local offset = root.Position - position
                if offset.X * offset.X + offset.Z * offset.Z < 6.25 then
                    return false
                end
            end
        end
        return true
    end

    -- คืน ตำแหน่ง, ชุดจุดที่ใช้ไม่ได้, เลขจุด  (nil = ยังไม่มีจุด / จุดหมด)
    local function nextSpot(data)
        spots = spots or buildSpots()
        if not spots then
            return nil
        end
        local wantHill, kind = false, "ground"
        if data.hybrid_placement then
            wantHill, kind = nil, "any"
        elseif data.hill_unit then
            wantHill, kind = true, "hill"
        end
        local list = spots.list
        if wantHill then
            spots.hill = spots.hill or hillSpots(spots.center) or list
            list = spots.hill
        end
        local bad = spots.bad[kind]
        if not bad then
            bad = {}
            spots.bad[kind] = bad
        end
        for index, candidate in ipairs(list) do
            if not bad[index] then
                local position = groundAt(candidate, wantHill)
                if position and isFree(position) then
                    return position, bad, index
                end
                bad[index] = true   -- ไม่มีพื้น / อยู่บนถนน / มียูนิตยืนอยู่แล้ว
            end
        end
        return nil
    end

    ------------------------------------------------------
    -- เลือกงานถัดไป
    ------------------------------------------------------
    local function selectedUnits()
        local team = AA.Equipped()
        local chosen = flags.unitTitles
        if type(chosen) ~= "table" or #chosen == 0 then
            return team, false
        end
        local out = {}
        for _, unit in ipairs(team) do
            if table.find(chosen, unit.title) then
                out[#out + 1] = unit
            end
        end
        if #out == 0 then
            return team, false   -- ทีมเปลี่ยนไปแล้ว (ชื่อที่เลือกไว้ไม่ตรง) = ใช้ทุกตัว
        end
        return out, true
    end

    local function eligible(key, money)
        local block = blocked[key]
        if not block then
            return true
        end
        local remain = block.time - os.clock()
        if remain > 0 then
            return false, remain
        end
        if money and block.money and money <= block.money then
            return false
        end
        blocked[key] = nil
        return true
    end

    local function block(key)
        blocked[key] = { money = AA.Money(), time = os.clock() + 3 }
    end

    local function learnScale(uuid, baseCost, before)
        local after = AA.Money()
        if before and after and baseCost and baseCost > 0 and before > after then
            local scale = (before - after) / baseCost
            if scale > 0.2 and scale < 6 then
                scaleOf[uuid] = scale
            end
        end
    end

    -- ทำงาน 1 อย่าง: คืน true ถ้าได้ลงมือทำ / false + วินาทีที่ควรตื่นมาดูใหม่ (ถ้ามี)
    local function step()
        local money = AA.Money()
        local need, wait = math.huge, nil
        local saving = false   -- กำลังเก็บเงินวางยูนิตอยู่ (ยังไม่อัปเกรด)

        local function later(seconds)
            if seconds and (not wait or seconds < wait) then
                wait = seconds
            end
        end

        local function waitMoney(key)
            local info = blocked[key]
            if info and info.money then
                need = math.min(need, info.money + 1)
            end
        end

        local units, explicit = selectedUnits()

        if flags.autoPlace then
            if #units == 0 then
                -- ยังอ่านทีมไม่ได้ (เกมยังโหลดไม่เสร็จ) : ลองใหม่ห่างๆ ไม่กี่ครั้ง
                teamTries = teamTries + 1
                if teamTries <= 6 then
                    AA.Equipped(true)
                    later(teamTries * 2)
                else
                    warnOnce("aa_need_team")
                end
            end

            local counts = {}
            for _, model in ipairs(AA.Mine) do
                local info = AA.MineInfo[model]
                if info then
                    counts[info.id] = (counts[info.id] or 0) + 1
                end
            end

            for _, unit in ipairs(units) do
                local data = unit.data or {}
                local cap = math.min(tonumber(data.spawn_cap) or 6, flags.placeCap or 6)
                if (counts[unit.id] or 0) < cap then
                    local key = "place:" .. unit.uuid
                    local baseCost = tonumber(data.cost) or 0
                    local cost = math.ceil(baseCost * (scaleOf[unit.uuid] or levelScale))
                    local ok, remain = eligible(key, money)
                    if not ok then
                        later(remain)
                        waitMoney(key)
                    elseif money and money < cost then
                        need = math.min(need, cost)
                        saving = true
                    else
                        local position, bad, index = nextSpot(data)
                        if position then
                            local model = AA.PlaceUnit(unit.uuid, position)
                            bad[index] = true
                            if model then
                                learnScale(unit.uuid, baseCost, money)
                                fails[key] = 0
                            else
                                fails[key] = (fails[key] or 0) + 1
                                if fails[key] % 3 == 0 then
                                    block(key)   -- 3 จุดติดแล้วยังไม่ได้ = ไม่ใช่เรื่องจุดวาง รอเงินเพิ่มก่อน
                                end
                            end
                            return true
                        elseif spots then
                            -- จุดรอบๆ หมดแล้ว: เลื่อนไปตามทางเดิน (ไม่เกิน 3 ครั้ง)
                            if flags.placeMode ~= "My Position" and shift < 36 then
                                shift, spots = shift + 12, nil
                                return true
                            end
                            warnOnce("aa_place_stuck")
                            block(key)
                        end
                    end
                end
            end
        end

        if flags.autoUpgrade and not saving then
            local cap = flags.upgradeCap or 0
            local bySlot = flags.upgradeOrder == "Slot Order"
            local wanted, slotOf
            if explicit then
                wanted = {}
                for _, unit in ipairs(units) do
                    wanted[unit.id] = true
                end
            end
            if bySlot then
                slotOf = {}
                for rank, unit in ipairs(AA.Equipped()) do
                    slotOf[unit.id] = rank
                end
            end

            local best, bestScore, bestCost, bestBase
            for _, model in ipairs(AA.Mine) do
                local info = AA.MineInfo[model]
                if info and info.upgrade and (not wanted or wanted[info.id]) then
                    local baseCost, level = AA.UpgradeCost(info)
                    if baseCost and (cap == 0 or level < cap) then
                        local ok, remain = eligible(model, money)
                        if not ok then
                            later(remain)
                            waitMoney(model)
                        else
                            local cost = math.ceil(baseCost * (scaleOf[info.uuid] or levelScale))
                            local score = bySlot and ((slotOf[info.id] or 99) * 10000 + info.order) or cost
                            if not best or score < bestScore then
                                best, bestScore, bestCost, bestBase = model, score, cost, baseCost
                            end
                        end
                    end
                end
            end

            if best then
                if money and money < bestCost then
                    need = math.min(need, bestCost)
                else
                    local info = AA.MineInfo[best]
                    if AA.UpgradeUnit(best) then
                        learnScale(info.uuid, bestBase, money)
                    else
                        block(best)
                    end
                    return true
                end
            end
        end

        needMoney = need
        return false, wait
    end

    local function worker(id)
        AA.TrackUnits()
        levelScale = AA.CostScale()
        path = path or loadPath()
        local offs = {
            AA.On("money", function(money)
                if (tonumber(money) or 0) >= needMoney then
                    waker.wake()
                end
            end),
            AA.On("unit", waker.wake),
            AA.On("unitRemoved", function(model)
                blocked[model] = nil
                waker.wake()
            end),
            AA.On("wave", waker.wake),
            AA.On("enemy", learnPath),
            AA.On("matchStart", function()
                Auto.Reset(true)
                waker.wake()
            end),
        }
        while workerId == id and AA.Alive() do
            local acted, wait = false, nil
            if AA.Macro.playing or AA.Finished() or Auto.sold then
                needMoney = math.huge
            else
                acted, wait = step()
            end
            if not acted then
                waker.sleep(wait)
            end
        end
        for _, off in ipairs(offs) do
            off()
        end
    end

    -- เรียกทุกครั้งที่ค่าใน UI เปลี่ยน: เปิด / ปิดงานเบื้องหลังให้ตรงกับสวิตช์
    function Auto.Refresh()
        local need = AA.InMatch and (flags.autoPlace or flags.autoUpgrade) and true or false
        if need and not Auto.running then
            Auto.running = true
            workerId = workerId + 1
            task.spawn(worker, workerId)
        elseif not need and Auto.running then
            Auto.running = false
            workerId = workerId + 1
        end
        waker.wake()
    end

    ------------------------------------------------------
    -- สกิล: ตั้งเวลาตามคูลดาวน์ของยูนิตแต่ละตัว (ไม่วนเช็กทุกตัวตลอดเวลา)
    ------------------------------------------------------
    local skillTokens, skillWatch, skillOffs = {}, {}, nil

    local function unwatchSkill(model)
        local conn = skillWatch[model]
        if conn then
            conn:Disconnect()
            skillWatch[model] = nil
        end
    end

    local function armSkill(model)
        if skillTokens[model] then
            return
        end
        local info = AA.MineInfo[model]
        if not info then
            return
        end
        local cooldown = AA.SkillCooldown(info)
        if not cooldown then
            -- ยังไม่มีสกิลที่เลเวลนี้ แต่เลเวลสูงขึ้นมี: รอค่าเลเวลของยูนิตตัวนี้เปลี่ยน แล้วค่อยเริ่มใช้ (ไม่วนเช็ก)
            if info.upgrade and not skillWatch[model] and AA.SkillCooldown(info, true) then
                skillWatch[model] = info.upgrade.Changed:Connect(function()
                    armSkill(model)
                end)
            end
            return
        end
        unwatchSkill(model)
        local token = {}
        skillTokens[model] = token
        local function fire()
            if skillTokens[model] ~= token then
                return
            end
            if not flags.autoSkill or not model.Parent or not AA.Alive() then
                skillTokens[model] = nil
                return
            end
            if AA.Started() and not AA.Finished() then
                AA.UseSkill(model)
            end
            task.delay(cooldown + 0.5, fire)
        end
        task.delay(1, fire)
    end

    function Auto.SetSkill(on)
        if skillOffs then
            for _, off in ipairs(skillOffs) do
                off()
            end
            skillOffs = nil
        end
        skillTokens = {}
        for model in pairs(skillWatch) do
            unwatchSkill(model)
        end
        if not on or not AA.InMatch then
            return
        end
        AA.TrackUnits()
        skillOffs = {
            AA.On("unit", armSkill),
            AA.On("unitRemoved", function(model)
                skillTokens[model] = nil
                unwatchSkill(model)
            end),
        }
        for _, model in ipairs(AA.Mine) do
            armSkill(model)
        end
    end
end

----------------------------------------------------------
-- 🎮 Tab Main : Anime Adventures
----------------------------------------------------------
Yield()
do
    local flags = AA.Flags
    local Macro, Auto = AA.Macro, AA.Auto

    -- ค่าที่ Dropdown ส่งมา เป็นได้ทั้งข้อความ และตาราง { Title = ..., Icon = รูป }
    local function titleOf(value)
        if type(value) == "table" then
            return value.Title
        end
        return value
    end

    -- ตัวเลือกของ Dropdown: มีรูปจริงก็ใส่รูป ไม่มีก็เป็นข้อความเปล่าๆ (ไม่ใส่ไอคอนแทน)
    local function option(title, image)
        if image then
            return { Title = title, Icon = image, IconSize = 24 }
        end
        return title
    end

    local function setDesc(element, text)
        pcall(function()
            element:SetDesc(text)
        end)
    end

    local function setToggle(element, state)
        pcall(function()
            element:Set(state)
        end)
    end

    ------------------------------------------------------
    -- Auto Play
    ------------------------------------------------------
    local PlaySec = TabMain:Section({
        Title = "loc:aa_sec_play",
        Icon = "swords",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    local StatusPara = PlaySec:Paragraph({
        Title = "loc:aa_status_title",
        Desc = "..."
    })

    local function refreshStatus()
        local lines = {}
        if not AA.Supported then
            lines[1] = T("aa_st_unsupported")
        else
            lines[#lines + 1] = (AA.IsLobby and T("aa_st_lobby")) or (AA.IsTimeMachine and T("aa_st_afk")) or T("aa_st_match")
            local team = AA.Equipped()
            lines[#lines + 1] = #team > 0 and (T("aa_st_team") .. #team .. T("aa_st_units")) or T("aa_st_team_none")
            lines[#lines + 1] = AA.Endpoints() and T("aa_st_remote_ok") or T("aa_st_remote_missing")
            lines[#lines + 1] = AA.Net.CanSee() and T("aa_st_hook_yes") or T("aa_st_hook_no")
        end
        setDesc(StatusPara, table.concat(lines, "\n"))
    end

    -- เริ่มเกม: โหวตเริ่มทันทีที่เซิร์ฟพร้อม ยังไม่เริ่มก็ส่งใหม่ห่างขึ้นเรื่อยๆ (งานโหวตตัวเดียวกับของมาโคร: AA.VoteStart)
    local function autoStart()
        if flags.autoStart then
            AA.VoteStart("auto", function()
                return flags.autoStart == true
            end)
        end
    end

    local TogStart = PlaySec:Toggle({
        Title = "loc:aa_start_title",
        Icon = "play",
        Desc = "loc:aa_start_desc",
        Value = false,
        Callback = function(state)
            flags.autoStart = state
            autoStart()
        end
    })
    MyConfig:Register("AA_AutoStart", TogStart)

    -- ข้ามเวฟ: ทางหลัก = เปิดการตั้งค่า autoskip_waves ของเกมเอง (Data.Settings) เกมข้ามให้ทุกเวฟ ไม่ต้องส่งคำสั่งซ้ำ
    --   เปิดแล้วดูค่าจริงว่าติดไหม (AA.SetSetting) / ไม่ติด = โหวตข้ามเองตอนเวฟเปลี่ยน
    --   เกมไม่มีทั้งสองทาง = แจ้งให้รู้ (ไม่ปล่อยสวิตช์เปิดค้างแบบไม่ทำอะไร)
    local skipOff, skipChanged
    local skipRun = 0

    local function applySkip(on)
        skipRun = skipRun + 1
        local run = skipRun
        if skipOff then
            skipOff()
            skipOff = nil
        end
        if not AA.InMatch then
            return
        end
        task.spawn(function()
            local value = AA.SettingValue("autoskip_waves", 15)
            if run ~= skipRun then
                return
            end
            if not on then
                if skipChanged and AA.ValueOf(value) == true then
                    skipChanged = false
                    AA.SetSetting("autoskip_waves", false)
                end
                return
            end
            if value and value.Value ~= true and AA.SetSetting("autoskip_waves", true) then
                skipChanged = true
            end
            if run ~= skipRun or not AA.Alive() then
                -- สวิตช์ถูกปิดไประหว่างที่กำลังเปิดการตั้งค่าให้: คืนค่าเดิม
                if skipChanged and not flags.autoSkip and AA.Alive() then
                    skipChanged = false
                    AA.SetSetting("autoskip_waves", false)
                end
                return
            end
            local canVote = AA.Remote("vote_wave_skip") ~= nil
            if AA.ValueOf(value) ~= true and not canVote then
                Notify(T("aa_skip_unavailable"), 6)
                return
            end
            -- เกมข้ามให้เองอยู่ (การตั้งค่าเปิดติด) / ยังไม่เริ่มเกม / จบรอบแล้ว = ไม่ต้องโหวต
            local function vote()
                if run == skipRun and AA.ValueOf(value) ~= true and AA.Started() and not AA.Finished() then
                    AA.Call("vote_wave_skip")
                end
            end
            skipOff = AA.On("wave", function()
                if canVote and AA.ValueOf(value) ~= true then
                    task.delay(1, vote)
                end
            end)
            if canVote then
                vote()   -- เปิดสวิตช์กลางเวฟ: โหวตข้ามเวฟที่กำลังเล่นอยู่ด้วย
            end
        end)
    end

    local TogSkip = PlaySec:Toggle({
        Title = "loc:aa_skip_title",
        Icon = "skip-forward",
        Desc = "loc:aa_skip_desc",
        Value = false,
        Callback = function(state)
            flags.autoSkip = state
            applySkip(state)
        end
    })
    MyConfig:Register("AA_AutoSkip", TogSkip)

    local UnitDropdown = PlaySec:Dropdown({
        Title = "loc:aa_units_title",
        Desc = "loc:aa_units_desc",
        Values = {},
        Value = {},
        Multi = true,
        AllowNone = true,
        Callback = function(selected)
            local titles = {}
            if type(selected) == "table" then
                for _, item in ipairs(selected) do
                    titles[#titles + 1] = titleOf(item)
                end
            end
            flags.unitTitles = titles
            Auto.Wake()
        end
    })
    MyConfig:Register("AA_Units", UnitDropdown)

    local function refreshUnits(force)
        local values = {}
        for _, unit in ipairs(AA.Equipped(force)) do
            values[#values + 1] = option(unit.title, AA.Image(unit.data))
        end
        if #values > 0 then
            pcall(function()
                UnitDropdown:Refresh(values)
            end)
        end
        refreshStatus()
        return #values
    end

    PlaySec:Button({
        Title = "loc:aa_units_refresh",
        Desc = "loc:aa_units_refresh_desc",
        Callback = function()
            local count = refreshUnits(true)
            if count > 0 then
                Auto.Reset(true)
                Auto.Wake()
                Notify(T("aa_units_loaded") .. count .. T("aa_st_units"), 3)
            else
                Notify(T("aa_need_team"), 4)
            end
        end
    })

    local PlaceModeDropdown = PlaySec:Dropdown({
        Title = "loc:aa_placemode_title",
        Desc = "loc:aa_placemode_desc",
        Values = { "Path", "My Position" },
        Value = "Path",
        Callback = function(selected)
            flags.placeMode = titleOf(selected) or "Path"
            Auto.Reset()
            Auto.Wake()
        end
    })
    MyConfig:Register("AA_PlaceMode", PlaceModeDropdown)

    local PathSlider = PlaySec:Slider({
        Title = "loc:aa_pathpct_title",
        Desc = "loc:aa_pathpct_desc",
        Step = 5,
        Value = { Min = 0, Max = 100, Default = 30 },
        Callback = function(value)
            flags.pathPercent = tonumber(value) or 30
            Auto.Reset(true)
            Auto.Wake()
        end
    })
    MyConfig:Register("AA_PathPercent", PathSlider)

    local CapSlider = PlaySec:Slider({
        Title = "loc:aa_cap_title",
        Desc = "loc:aa_cap_desc",
        Step = 1,
        Value = { Min = 1, Max = 10, Default = 6 },
        Callback = function(value)
            flags.placeCap = tonumber(value) or 6
            Auto.Wake()
        end
    })
    MyConfig:Register("AA_PlaceCap", CapSlider)

    local TogPlace = PlaySec:Toggle({
        Title = "loc:aa_place_title",
        Icon = "map-pin",
        Desc = "loc:aa_place_desc",
        Value = false,
        Callback = function(state)
            flags.autoPlace = state
            if state then
                Auto.Reset()
            end
            Auto.Refresh()
        end
    })
    MyConfig:Register("AA_AutoPlace", TogPlace)

    local OrderDropdown = PlaySec:Dropdown({
        Title = "loc:aa_uporder_title",
        Desc = "loc:aa_uporder_desc",
        Values = { "Cheapest", "Slot Order" },
        Value = "Cheapest",
        Callback = function(selected)
            flags.upgradeOrder = titleOf(selected) or "Cheapest"
            Auto.Wake()
        end
    })
    MyConfig:Register("AA_UpgradeOrder", OrderDropdown)

    local UpgradeCapSlider = PlaySec:Slider({
        Title = "loc:aa_upcap_title",
        Desc = "loc:aa_upcap_desc",
        Step = 1,
        Value = { Min = 0, Max = 15, Default = 0 },
        Callback = function(value)
            flags.upgradeCap = tonumber(value) or 0
            Auto.Wake()
        end
    })
    MyConfig:Register("AA_UpgradeCap", UpgradeCapSlider)

    local TogUpgrade = PlaySec:Toggle({
        Title = "loc:aa_upgrade_title",
        Icon = "trending-up",
        Desc = "loc:aa_upgrade_desc",
        Value = false,
        Callback = function(state)
            flags.autoUpgrade = state
            Auto.Refresh()
        end
    })
    MyConfig:Register("AA_AutoUpgrade", TogUpgrade)

    local TogSkill = PlaySec:Toggle({
        Title = "loc:aa_skill_title",
        Icon = "zap",
        Desc = "loc:aa_skill_desc",
        Value = false,
        Callback = function(state)
            flags.autoSkill = state
            Auto.SetSkill(state)
        end
    })
    MyConfig:Register("AA_AutoSkill", TogSkill)

    local EndDropdown = PlaySec:Dropdown({
        Title = "loc:aa_end_title",
        Desc = "loc:aa_end_desc",
        Values = { "None", "Replay", "Next Story", "Lobby" },
        Value = "None",
        Callback = function(selected)
            flags.endAction = titleOf(selected) or "None"
        end
    })
    MyConfig:Register("AA_EndAction", EndDropdown)

    local LeaveInput = PlaySec:Input({
        Title = "loc:aa_leave_title",
        Desc = "loc:aa_leave_desc",
        Placeholder = "0",
        Value = "",
        Callback = function(value)
            flags.leaveWave = tonumber(value) or 0
        end
    })
    MyConfig:Register("AA_LeaveWave", LeaveInput)

    local SellInput = PlaySec:Input({
        Title = "loc:aa_sellwave_title",
        Desc = "loc:aa_sellwave_desc",
        Placeholder = "0",
        Value = "",
        Callback = function(value)
            flags.sellWave = tonumber(value) or 0
            if flags.sellWave > 0 then
                AA.TrackUnits()   -- ต้องรู้จักยูนิตของเราก่อนถึงเวฟที่จะขาย
            end
        end
    })
    MyConfig:Register("AA_SellWave", SellInput)

    if AA.InMatch then
        -- จบรอบ: รอหน้าสรุปผลขึ้นก่อน แล้วโหวตตามที่เลือกไว้ (ครั้งเดียว + ลองซ้ำอีก 1 ครั้งถ้ายังค้างหน้าเดิม)
        AA.On("matchEnd", function()
            local action = flags.endAction
            if not action or action == "None" then
                return
            end
            local function act(fallback)
                if not AA.Finished() or not AA.Alive() or flags.endAction ~= action then
                    return
                end
                if action == "Lobby" then
                    AA.ToLobby()
                elseif action == "Next Story" and not fallback then
                    AA.Call("set_game_finished_vote", "next_story")
                else
                    AA.Call("set_game_finished_vote", "replay")   -- ไม่มีด่านถัดไปให้ไป = เล่นซ้ำ
                end
            end
            task.delay(3, act)
            task.delay(11, function()
                act(true)
            end)
        end)

        AA.On("wave", function(wave)
            local limit = flags.leaveWave or 0
            if limit > 0 and (tonumber(wave) or 0) >= limit and not AA.Finished() then
                task.spawn(AA.ToLobby)
            end
        end)

        -- ขายยูนิตทั้งหมดเมื่อถึงเวฟที่ตั้งไว้ (รอบละครั้ง) แล้วหยุดวาง / อัปเกรดจนกว่าจะเริ่มรอบใหม่
        AA.On("wave", function(wave)
            local limit = flags.sellWave or 0
            if limit <= 0 or Auto.sold or (tonumber(wave) or 0) < limit or AA.Finished() then
                return
            end
            Auto.sold = true
            task.spawn(function()
                for _, model in ipairs(table.clone(AA.Mine)) do
                    if not AA.Alive() or AA.Finished() or not Auto.sold then
                        return
                    end
                    if model.Parent then
                        AA.SellUnit(model)
                    end
                end
            end)
        end)

        AA.On("matchStart", function()
            Auto.sold = false
            autoStart()
            refreshStatus()
        end)
    end

    ------------------------------------------------------
    -- มาโคร
    ------------------------------------------------------
    Yield()
    local MacroSec = TabMain:Section({
        Title = "loc:aa_sec_macro",
        Icon = "clapperboard",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    local MacroPara = MacroSec:Paragraph({
        Title = "loc:aa_macro_status_title",
        Desc = "loc:aa_macro_idle"
    })

    local MacroDropdown, TogRecord, TogMacroPlay

    local function refreshMacros(select)
        local values = { "Auto" }
        for _, name in ipairs(Macro.List()) do
            values[#values + 1] = name
        end
        pcall(function()
            MacroDropdown:Refresh(values)
            if select then
                MacroDropdown:Select(select)
            end
        end)
    end

    MacroSec:Input({
        Title = "loc:aa_macro_name_title",
        Desc = "loc:aa_macro_name_desc",
        Placeholder = "...",
        Value = "",
        Callback = function(value)
            flags.macroName = value or ""
        end
    })

    TogRecord = MacroSec:Toggle({
        Title = "loc:aa_macro_record_title",
        Icon = "disc",
        Desc = "loc:aa_macro_record_desc",
        Value = false,
        Callback = function(state)
            if state then
                if Macro.recording then
                    return
                end
                if not AA.InMatch then
                    Notify(T("aa_macro_need_match"), 4)
                    setToggle(TogRecord, false)
                    return
                end
                if Macro.playing then
                    Notify(T("aa_macro_busy"), 4)
                    setToggle(TogRecord, false)
                    return
                end
                Macro.StartRecord(function(count)
                    setDesc(MacroPara, T("aa_macro_recording") .. count .. T("aa_macro_steps"))
                end)
                setDesc(MacroPara, T("aa_macro_recording") .. "0" .. T("aa_macro_steps"))
                Notify(T("aa_macro_rec_started"), 3)
            elseif Macro.recording then
                task.spawn(function()
                    local count, name = Macro.StopRecord(flags.macroName)
                    if name then
                        setDesc(MacroPara, T("aa_macro_saved") .. name .. " (" .. count .. T("aa_macro_steps") .. ")")
                        Notify(T("aa_macro_saved") .. name, 4)
                        if not AA.CanFiles then
                            Notify(T("aa_macro_nofile"), 6)
                        end
                        refreshMacros(name)
                    else
                        setDesc(MacroPara, T("aa_macro_empty"))
                        Notify(T("aa_macro_empty"), 3)
                    end
                end)
            end
        end
    })

    MacroDropdown = MacroSec:Dropdown({
        Title = "loc:aa_macro_file_title",
        Desc = "loc:aa_macro_file_desc",
        Values = { "Auto" },
        Value = "Auto",
        Callback = function(selected)
            flags.macroFile = titleOf(selected) or "Auto"
        end
    })
    MyConfig:Register("AA_MacroFile", MacroDropdown)

    MacroSec:Button({
        Title = "loc:aa_macro_refresh",
        Callback = function()
            refreshMacros()
        end
    })

    local SyncDropdown = MacroSec:Dropdown({
        Title = "loc:aa_macro_sync_title",
        Desc = "loc:aa_macro_sync_desc",
        Values = { "Wave + Time", "Money" },
        Value = "Wave + Time",
        Callback = function(selected)
            flags.macroSync = titleOf(selected) or "Wave + Time"
        end
    })
    MyConfig:Register("AA_MacroSync", SyncDropdown)

    local TogLock = MacroSec:Toggle({
        Title = "loc:aa_macro_lock_title",
        Icon = "lock",
        Desc = "loc:aa_macro_lock_desc",
        Value = true,
        Callback = function(state)
            flags.macroLock = state
        end
    })
    MyConfig:Register("AA_MacroLock", TogLock)

    -- เปิดสวิตช์ค้างไว้ = เล่นให้ทุกรอบ (เริ่มรอบใหม่เมื่อไหร่เล่นใหม่ตั้งแต่ต้น)
    local function startMacro()
        if not (flags.macroPlay and AA.InMatch) or Macro.playing or Macro.recording or AA.Finished() then
            return
        end
        task.spawn(function()
            local name = flags.macroFile
            if not name or name == "Auto" then
                name = AA.MapKey()
            end
            local data = name and Macro.Load(name)
            if not flags.macroPlay or Macro.playing then
                return
            end
            if type(data) ~= "table" or type(data.steps) ~= "table" or #data.steps == 0 then
                setDesc(MacroPara, T("aa_macro_missing") .. tostring(name or "?"))
                Notify(T("aa_macro_missing") .. tostring(name or "?"), 4)
                return
            end
            Macro.Play(name, data, {
                sync = flags.macroSync,
                lock = flags.macroLock ~= false,
                onStop = function()
                    setToggle(TogMacroPlay, false)
                end,
                status = function(text, reason)
                    if text then
                        setDesc(MacroPara, text)
                        return
                    end
                    setDesc(MacroPara, T(reason == "end" and "aa_macro_done" or "aa_macro_stopped"))
                    Auto.Wake()
                end,
            })
        end)
    end

    TogMacroPlay = MacroSec:Toggle({
        Title = "loc:aa_macro_play_title",
        Icon = "circle-play",
        Desc = "loc:aa_macro_play_desc",
        Value = false,
        Callback = function(state)
            flags.macroPlay = state
            if state then
                if Macro.recording then
                    Notify(T("aa_macro_busy"), 4)
                    setToggle(TogMacroPlay, false)
                elseif not AA.InMatch then
                    if not loading then
                        Notify(T("aa_macro_wait_match"), 4)
                    end
                else
                    startMacro()
                end
            else
                Macro.Stop("user")
            end
        end
    })
    MyConfig:Register("AA_MacroPlay", TogMacroPlay)

    MacroSec:Button({
        Title = "loc:aa_macro_delete",
        Callback = function()
            local name = flags.macroFile
            if not name or name == "Auto" then
                return
            end
            Macro.Delete(name)
            refreshMacros("Auto")
            Notify(T("aa_macro_deleted") .. name, 3)
        end
    })

    if AA.InMatch then
        AA.On("matchStart", startMacro)
    end
    table.insert(AfterLoad, function()
        refreshMacros()
    end)

    ------------------------------------------------------
    -- เข้าด่านอัตโนมัติ (ล็อบบี้)
    --   รายชื่อแมพ / ด่าน มาจากข้อมูลของเกม: Data.WorldLevelOrder + Data.Worlds + Data.Levels
    --   ห้องในล็อบบี้: หาห้องที่ Owner ว่าง -> request_join_lobby -> request_lock_level -> request_start_game
    ------------------------------------------------------
    Yield()
    local JoinSec = TabMain:Section({
        Title = "loc:aa_sec_join",
        Icon = "door-open",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    local LOBBY_PATHS = {
        Story = { "_LOBBIES", "Story" },
        Infinite = { "_LOBBIES", "Story" },
        ["Legend Stage"] = { "_LOBBIES", "Story" },
        Raid = { "_RAID", "Raid" },
        Challenge = { "_CHALLENGES", "Challenges" },
    }
    local worldIds, actIds = {}, {}   -- ชื่อที่แสดง -> ไอดีของเกม
    local WorldDropdown, ActDropdown

    local function worldList(mode)
        local values, ids = {}, {}
        local order = AA.Data("WorldLevelOrder") or {}
        local worlds = AA.Data("Worlds") or {}
        local list = (mode == "Legend Stage" and order.LEGEND_WORLD_ORDER) or (mode == "Raid" and order.RAID_WORLD_ORDER) or order.WORLD_ORDER
        for _, id in ipairs(type(list) == "table" and list or {}) do
            local world = worlds[id]
            if type(world) == "table" and (mode ~= "Infinite" or type(world.infinite) == "table") then
                local name = tostring(world.name or id)
                if ids[name] then
                    name = name .. " (" .. tostring(id) .. ")"
                end
                ids[name] = id
                values[#values + 1] = option(name, AA.MapImage(world.map))
            end
        end
        return values, ids
    end

    local function actList(mode, worldId)
        local values, ids = {}, {}
        local worlds = AA.Data("Worlds") or {}
        local world = worlds[worldId]
        if type(world) ~= "table" then
            return values, ids
        end
        if mode == "Infinite" then
            local id = type(world.infinite) == "table" and world.infinite.id
            if id then
                values[1], ids["Infinite"] = "Infinite", id
            end
            return values, ids
        end
        local levels = AA.Data("Levels") or {}
        local list = {}
        for key, entry in pairs(type(world.levels) == "table" and world.levels or {}) do
            if type(entry) == "table" and entry.id then
                list[#list + 1] = { number = tonumber(key) or 0, id = entry.id }
            end
        end
        table.sort(list, function(a, b)
            return a.number < b.number
        end)
        for _, item in ipairs(list) do
            local level = safe(function()
                return levels[item.id]
            end)
            local name = tostring(type(level) == "table" and level.name or ("Act " .. item.number))
            if ids[name] then
                name = name .. " (" .. item.number .. ")"
            end
            ids[name] = item.id
            values[#values + 1] = name
        end
        return values, ids
    end

    -- Refresh ของ Dropdown จะเรียก Callback ด้วยค่าที่เลือกอยู่ -> flags อัปเดตเองก่อนบรรทัดถัดไป
    local function syncActs()
        if not AA.IsLobby then
            return
        end
        local values
        values, actIds = actList(flags.joinMode or "Story", worldIds[flags.joinWorld or ""])
        pcall(function()
            ActDropdown:Refresh(values)
            if #values > 0 and not actIds[flags.joinAct or ""] then
                ActDropdown:Select(values[1])
            end
        end)
    end

    local function syncWorlds()
        if not AA.IsLobby then
            return
        end
        local values
        values, worldIds = worldList(flags.joinMode or "Story")
        pcall(function()
            WorldDropdown:Refresh(values)
            if #values > 0 and not worldIds[flags.joinWorld or ""] then
                WorldDropdown:Select(values[1])
            end
        end)
        syncActs()
    end

    local ModeDropdown = JoinSec:Dropdown({
        Title = "loc:aa_joinmode_title",
        Desc = "loc:aa_joinmode_desc",
        Values = { "Story", "Infinite", "Legend Stage", "Raid", "Challenge" },
        Value = "Story",
        Callback = function(selected)
            local mode = titleOf(selected) or "Story"
            if flags.joinMode ~= mode then
                flags.joinMode = mode
                syncWorlds()
            end
        end
    })
    MyConfig:Register("AA_JoinMode", ModeDropdown)

    WorldDropdown = JoinSec:Dropdown({
        Title = "loc:aa_joinworld_title",
        Desc = "loc:aa_joinworld_desc",
        Values = {},
        Callback = function(selected)
            local world = titleOf(selected)
            if flags.joinWorld ~= world then
                flags.joinWorld = world
                syncActs()
            end
        end
    })
    MyConfig:Register("AA_JoinWorld", WorldDropdown)

    ActDropdown = JoinSec:Dropdown({
        Title = "loc:aa_joinact_title",
        Desc = "loc:aa_joinact_desc",
        Values = {},
        Callback = function(selected)
            flags.joinAct = titleOf(selected)
        end
    })
    MyConfig:Register("AA_JoinAct", ActDropdown)

    local DifficultyDropdown = JoinSec:Dropdown({
        Title = "loc:aa_joindiff_title",
        Desc = "loc:aa_joindiff_desc",
        Values = { "Normal", "Hard", "Insane" },
        Value = "Normal",
        Callback = function(selected)
            flags.joinDifficulty = titleOf(selected) or "Normal"
        end
    })
    MyConfig:Register("AA_JoinDifficulty", DifficultyDropdown)

    local TogFriends = JoinSec:Toggle({
        Title = "loc:aa_joinfriends_title",
        Icon = "users",
        Desc = "loc:aa_joinfriends_desc",
        Value = true,
        Callback = function(state)
            flags.joinFriends = state
        end
    })
    MyConfig:Register("AA_JoinFriends", TogFriends)

    -- ค่า Owner ของห้อง เป็นได้ทั้งตัวผู้เล่น และชื่อผู้เล่น
    local function ownedByMe(owner)
        local value = owner.Value
        return value == LocalPlr or (value ~= nil and tostring(value) == LocalPlr.Name)
    end

    -- ห้องที่จะใช้: ห้องที่เราเป็นเจ้าของอยู่แล้วก่อน (รอบก่อนเข้าไว้แต่ยังไม่ได้ย้าย) ไม่มีก็ห้องว่างห้องแรก
    local function freeLobby(mode)
        local container = workspace
        for _, name in ipairs(LOBBY_PATHS[mode] or LOBBY_PATHS.Story) do
            container = container and container:FindFirstChild(name)
        end
        if not container then
            return nil
        end
        local free, freeOwner
        for _, owner in ipairs(container:GetDescendants()) do
            if owner.Name == "Owner" and owner:IsA("ValueBase") then
                local lobby = owner.Parent
                if ownedByMe(owner) then
                    return lobby, owner
                end
                if not free and (owner.Value == nil or owner.Value == "") and AA.ValueOf(lobby:FindFirstChild("Teleporting")) ~= true then
                    free, freeOwner = lobby, owner
                end
            end
        end
        return free, freeOwner
    end

    local joinRun = 0

    local function autoJoin()
        joinRun = joinRun + 1
        if not (flags.autoJoin and AA.IsLobby) then
            return
        end
        local id = joinRun
        task.spawn(function()
            local function live()
                return id == joinRun and flags.autoJoin and AA.Alive()
            end
            local ready = workspace:FindFirstChild("SERVER_READY") or workspace:WaitForChild("SERVER_READY", 30)
            if ready and AA.ValueOf(ready) == false then
                AA.Await(60, function(resolve)
                    local conn = ready.Changed:Connect(function(value)
                        if value then
                            resolve(true)
                        end
                    end)
                    return function()
                        conn:Disconnect()
                    end
                end)
            end
            task.wait(2)   -- ให้ค่าที่เซฟไว้ใน Config ลงครบ + ตัวละครโหลดเสร็จ

            for attempt = 1, 6 do
                if not live() then
                    return
                end
                local mode = flags.joinMode or "Story"
                local levelId = actIds[flags.joinAct or ""]
                if mode ~= "Challenge" and not levelId then
                    Notify(T("aa_join_nolevel"), 4)
                    return
                end
                local lobby, owner = freeLobby(mode)
                if lobby then
                    Notify(T("aa_join_going") .. tostring(mode == "Challenge" and mode or levelId), 3)
                    if not ownedByMe(owner) then
                        AA.CallWait(8, "request_join_lobby", lobby.Name)
                    end
                    if not ownedByMe(owner) then
                        AA.Await(3, function(resolve)
                            local conn = owner.Changed:Connect(function()
                                if ownedByMe(owner) then
                                    resolve(true)
                                end
                            end)
                            return function()
                                conn:Disconnect()
                            end
                        end)
                    end
                    if not live() then
                        return
                    end
                    -- ไปยืนที่ประตูห้องด้วย (เกมดูว่าใครอยู่ในห้องจากตำแหน่งตัวละคร)
                    local door = lobby:FindFirstChild("Door")
                    local root = LocalPlr.Character and LocalPlr.Character:FindFirstChild("HumanoidRootPart")
                    if door and door:IsA("BasePart") and root and root:IsA("BasePart") then
                        root.CFrame = door.CFrame
                    end
                    if mode ~= "Challenge" then
                        -- ความยาก: ด่านที่เกมกำหนดไว้ตายตัว ใช้ค่าของเกม (Data.Levels.<ด่าน>._MATCHMAKING.difficulty)
                        --   ในข้อมูลของเกม ด่าน Infinite / Legend Stage / Raid ทุกด่านเป็น "Hard" ส่วนด่าน Story ธรรมดาไม่มีค่านี้ = ใช้ที่ผู้เล่นเลือก
                        local level = safe(function()
                            return AA.Data("Levels")[levelId]
                        end)
                        local fixed = type(level) == "table" and type(level._MATCHMAKING) == "table" and level._MATCHMAKING.difficulty
                        local difficulty = (type(fixed) == "string" and fixed) or (mode ~= "Story" and "Hard") or flags.joinDifficulty or "Normal"
                        AA.CallWait(8, "request_lock_level", lobby.Name, levelId, flags.joinFriends ~= false, difficulty)
                    end
                    AA.CallWait(8, "request_start_game", lobby.Name)
                else
                    Notify(T("aa_join_nolobby"), 3)
                end

                -- เซิร์ฟจะย้ายเราเข้าด่านเอง: ยังอยู่ที่เดิมค่อยลองใหม่ (ห่างขึ้นทุกครั้ง)
                task.wait(10 + attempt * 5)
                local teleporting = lobby and lobby:FindFirstChild("Teleporting")
                if AA.ValueOf(teleporting) == true and ownedByMe(owner) then
                    task.wait(45)   -- ห้องกำลังย้ายเราอยู่ (เน็ตช้า) : รอต่อ ไม่ออกจากห้อง
                end
                if not live() then
                    return
                end
                if lobby and AA.Remote("request_leave_lobby") then
                    AA.CallWait(5, "request_leave_lobby", lobby.Name)   -- ไม่มีคำสั่งนี้ก็ไม่เป็นไร: รอบถัดไปใช้ห้องเดิมที่เราเป็นเจ้าของต่อ
                end
                Notify(T("aa_join_failed"), 3)
            end
        end)
    end

    local TogJoin = JoinSec:Toggle({
        Title = "loc:aa_autojoin_title",
        Icon = "log-in",
        Desc = "loc:aa_autojoin_desc",
        Value = false,
        Callback = function(state)
            flags.autoJoin = state
            autoJoin()
        end
    })
    MyConfig:Register("AA_AutoJoin", TogJoin)

    -- รันสคริปเองหลังย้ายเซิร์ฟ (ล็อบบี้ <-> ด่าน) : ต้องมีลิงก์ของสคริป + ตัวรันต้องมี queue_on_teleport
    local queueTeleport = safe(function()
        return queue_on_teleport or (syn and syn.queue_on_teleport) or (fluxus and fluxus.queue_on_teleport)
    end)

    local ExecInput = JoinSec:Input({
        Title = "loc:aa_execlink_title",
        Desc = "loc:aa_execlink_desc",
        Placeholder = "https://...",
        Value = "",
        Callback = function(value)
            flags.execLink = tostring(value or ""):match("^%s*(.-)%s*$")
        end
    })
    MyConfig:Register("AA_ExecLink", ExecInput)

    local TogExec = JoinSec:Toggle({
        Title = "loc:aa_autoexec_title",
        Icon = "repeat",
        Desc = "loc:aa_autoexec_desc",
        Value = false,
        Callback = function(state)
            flags.autoExec = state
            if state and not loading and type(queueTeleport) ~= "function" then
                Notify(T("aa_exec_unsupported"), 4)
            end
        end
    })
    MyConfig:Register("AA_AutoExec", TogExec)

    LocalPlr.OnTeleport:Connect(function(state)
        local link = flags.execLink
        if state ~= Enum.TeleportState.Started or not flags.autoExec or type(queueTeleport) ~= "function" then
            return
        end
        if type(link) == "string" and link:match("^https?://%S+$") then
            pcall(queueTeleport, ("loadstring(game:HttpGet(%q))()"):format(link))
        end
    end)

    ------------------------------------------------------
    -- ของรางวัลและกาชา
    ------------------------------------------------------
    Yield()
    local RewardSec = TabMain:Section({
        Title = "loc:aa_sec_reward",
        Icon = "gift",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    -- ไข่ (ReplicatedStorage._TheHatch) : เซิร์ฟบอกตอนไข่โผล่ (Remotes.Spawn) -> ไปแตะแล้วเก็บทันที ไม่มีลูปเดินหา
    local eggConn

    local function setEgg(on)
        if eggConn then
            eggConn:Disconnect()
            eggConn = nil
        end
        if not on then
            return
        end
        local hatch = ReplicatedStorage:FindFirstChild("_TheHatch")
        local remotes = hatch and hatch:FindFirstChild("Remotes")
        local spawnEvent = remotes and remotes:FindFirstChild("Spawn")
        local pickup = remotes and remotes:FindFirstChild("Pickup")
        if not (spawnEvent and pickup) then
            if not loading then
                Notify(T("aa_egg_none"), 3)
            end
            return
        end

        local busy = false
        local function collect(position)
            if busy then
                return
            end
            busy = true
            task.spawn(function()
                local root = LocalPlr.Character and LocalPlr.Character:FindFirstChild("HumanoidRootPart")
                local back = root and root.CFrame
                if root and position then
                    root.CFrame = CFrame.new(position + Vector3.new(0, 3, 0))   -- เกมให้เก็บตอนตัวละครแตะไข่
                    task.wait(0.2)
                end
                pcall(AA.InvokeRemote, pickup)
                task.wait(0.2)
                if root and back and root.Parent then
                    root.CFrame = back
                end
                busy = false
            end)
        end

        eggConn = spawnEvent.OnClientEvent:Connect(function(_, position)
            collect(typeof(position) == "Vector3" and position or nil)
        end)

        -- ไข่ที่โผล่ไว้ก่อนเปิดสวิตช์ (เกมวางไข่ไว้ใน workspace โดยใช้ชื่อเดียวกับโมเดลใน _TheHatch.Models)
        local models = hatch:FindFirstChild("Models")
        if models then
            for _, child in ipairs(workspace:GetChildren()) do
                if child:IsA("MeshPart") and models:FindFirstChild(child.Name) then
                    collect(child.Position)
                    break
                end
            end
        end
    end

    local TogEgg = RewardSec:Toggle({
        Title = "loc:aa_egg_title",
        Icon = "egg",
        Desc = "loc:aa_egg_desc",
        Value = false,
        Callback = function(state)
            flags.autoEgg = state
            setEgg(state)
        end
    })
    MyConfig:Register("AA_Egg", TogEgg)

    local dailyDone = false

    local TogDaily = RewardSec:Toggle({
        Title = "loc:aa_daily_title",
        Icon = "calendar-check",
        Desc = "loc:aa_daily_desc",
        Value = false,
        Callback = function(state)
            flags.autoDaily = state
            if state and AA.IsLobby and not dailyDone then
                dailyDone = true
                task.delay(5, function()
                    if flags.autoDaily then
                        AA.CallWait(10, "claim_daily_reward")
                    end
                end)
            end
        end
    })
    MyConfig:Register("AA_Daily", TogDaily)

    local BannerDropdown = RewardSec:Dropdown({
        Title = "loc:aa_banner_title",
        Desc = "loc:aa_banner_desc",
        Values = {},
        Callback = function(selected)
            flags.banner = titleOf(selected)
        end
    })
    MyConfig:Register("AA_Banner", BannerDropdown)

    local MethodDropdown = RewardSec:Dropdown({
        Title = "loc:aa_method_title",
        Desc = "loc:aa_method_desc",
        Values = { "gems", "gems10", "ticket" },
        Value = "gems10",
        Callback = function(selected)
            flags.summonMethod = titleOf(selected) or "gems10"
        end
    })
    MyConfig:Register("AA_SummonMethod", MethodDropdown)

    local SummonSlider = RewardSec:Slider({
        Title = "loc:aa_summon_count_title",
        Desc = "loc:aa_summon_count_desc",
        Step = 1,
        Value = { Min = 1, Max = 100, Default = 10 },
        Callback = function(value)
            flags.summonCount = tonumber(value) or 10
        end
    })
    MyConfig:Register("AA_SummonCount", SummonSlider)

    -- สุ่มตามจำนวนครั้งที่ตั้งไว้แล้วปิดสวิตช์เอง (ไม่ได้เซฟสวิตช์นี้ จะได้ไม่สุ่มเองตอนรันสคริป)
    local summonRun = 0
    local TogSummon

    TogSummon = RewardSec:Toggle({
        Title = "loc:aa_summon_title",
        Icon = "sparkles",
        Desc = "loc:aa_summon_desc",
        Value = false,
        Callback = function(state)
            summonRun = summonRun + 1
            if not state or loading then
                return
            end
            if not AA.IsLobby or not flags.banner then
                Notify(T(AA.IsLobby and "aa_summon_nobanner" or "aa_only_lobby"), 3)
                setToggle(TogSummon, false)
                return
            end
            local id = summonRun
            task.spawn(function()
                local failed = 0
                for _ = 1, flags.summonCount or 10 do
                    if id ~= summonRun or not AA.Alive() then
                        return
                    end
                    local ok = AA.CallWait(12, "buy_from_banner", flags.banner, flags.summonMethod or "gems10")
                    failed = ok and 0 or failed + 1
                    if failed >= 3 then
                        break
                    end
                    task.wait(1.6)   -- รอแอนิเมชันสุ่มของเกม
                end
                if id == summonRun then
                    Notify(T("aa_summon_done"), 3)
                    setToggle(TogSummon, false)
                end
            end)
        end
    })

    ------------------------------------------------------
    -- ลดแลค
    ------------------------------------------------------
    Yield()
    local PerfSec = TabMain:Section({
        Title = "loc:aa_sec_perf",
        Icon = "gauge",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    -- การตั้งค่าลดแลคของเกมเอง (ชื่อจาก Data.Settings) : เปิดให้ทีละค่า แล้วดูค่าจริงว่าติดไหม (AA.SetSetting)
    --   ปิดสวิตช์ = คืนเฉพาะค่าที่เราเปิดให้ / เปิดไม่ติดสักค่า = แจ้งให้รู้
    --   low_quality_shadows กับ low_quality_textures ไม่อยู่ในรายการ: Data.Settings ระบุ dont_replicate
    --   (ค่าอยู่ที่เครื่องผู้เล่นอย่างเดียว สั่งผ่านเซิร์ฟไม่ได้) เงากับลายพื้นผิวใช้สวิตช์ "ลดกราฟิก" ข้างล่างแทน
    local FX_SETTINGS = { "low_quality", "disable_kill_fx", "disable_other_fx", "disable_effects", "hide_other_damage_text", "hide_other_pets" }
    local fxChanged = {}
    local fxWanted, fxBusy = false, false

    -- งานเดียวทำทีละรอบ: สวิตช์ถูกกดสลับระหว่างทำ = จบรอบนี้แล้วทำอีกรอบตามค่าล่าสุด (ไม่มีสองงานแก้ค่าชนกัน)
    local function applyLowFx(on)
        fxWanted = on
        if fxBusy then
            return
        end
        fxBusy = true
        task.spawn(function()
            AA.SettingValue(FX_SETTINGS[1], 15)   -- รอโฟลเดอร์ _settings ของเกม (ตอนเพิ่งเข้าเซิร์ฟ)
            local target
            repeat
                target = fxWanted
                local active = 0
                for _, id in ipairs(FX_SETTINGS) do
                    local value = AA.SettingValue(id)
                    if value and target then
                        if value.Value == true then
                            active = active + 1   -- เปิดอยู่แล้ว (ผู้เล่นเปิดเอง = ไม่ถือว่าเราเปิด ตอนปิดสวิตช์ไม่ปิดให้)
                        elseif AA.SetSetting(id, true) then
                            fxChanged[id] = true
                            active = active + 1
                        end
                    elseif value and fxChanged[id] then
                        if value.Value ~= true or AA.SetSetting(id, false) then
                            fxChanged[id] = nil
                        end
                    end
                end
                if target and active == 0 and fxWanted and AA.Alive() then
                    Notify(T("aa_unavailable"), 4)
                end
            until fxWanted == target or not AA.Alive()
            fxBusy = false
        end)
    end

    local TogLowFx = PerfSec:Toggle({
        Title = "loc:aa_lowfx_title",
        Icon = "sparkle",
        Desc = "loc:aa_lowfx_desc",
        Value = false,
        Callback = function(state)
            if AA.Supported and (state or fxBusy or next(fxChanged)) then
                applyLowFx(state)
            end
        end
    })
    MyConfig:Register("AA_LowFx", TogLowFx)

    -- ลดกราฟิก: ไล่ทีละช่วงสั้นๆ (ไม่ค้าง) ทำครั้งเดียวต่อเซิร์ฟ
    local boosted = false

    local function boost()
        if boosted then
            return
        end
        boosted = true
        pcall(function()
            settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
        end)
        LightOverride.set("aa_boost", { GlobalShadows = false })
        task.spawn(function()
            for _, effect in ipairs(Lighting:GetChildren()) do
                if effect:IsA("PostEffect") then
                    effect.Enabled = false
                end
            end
            local count = 0
            for _, object in ipairs(workspace:GetDescendants()) do
                if object:IsA("BasePart") then
                    object.Material = Enum.Material.SmoothPlastic
                    object.Reflectance = 0
                    object.CastShadow = false
                elseif object:IsA("Decal") or object:IsA("Texture") then
                    object.Transparency = 1
                elseif object:IsA("ParticleEmitter") or object:IsA("Trail") or object:IsA("Beam") then
                    object.Enabled = false
                end
                count = count + 1
                if count % 300 == 0 then
                    task.wait()
                end
            end
        end)
    end

    local TogBoost = PerfSec:Toggle({
        Title = "loc:aa_boost_title",
        Icon = "image-off",
        Desc = "loc:aa_boost_desc",
        Value = false,
        Callback = function(state)
            if state then
                boost()
            end
        end
    })
    MyConfig:Register("AA_Boost", TogBoost)

    local TogRender = PerfSec:Toggle({
        Title = "loc:aa_norender_title",
        Icon = "monitor-off",
        Desc = "loc:aa_norender_desc",
        Value = false,
        Callback = function(state)
            pcall(function()
                RunService:Set3dRenderingEnabled(not state)
            end)
        end
    })
    MyConfig:Register("AA_NoRender", TogRender)

    local fpsTouched = false

    local FpsSlider = PerfSec:Slider({
        Title = "loc:aa_fps_title",
        Desc = "loc:aa_fps_desc",
        Step = 5,
        Value = { Min = 0, Max = 60, Default = 0 },
        Callback = function(value)
            value = tonumber(value) or 0
            if type(setfpscap) ~= "function" or (value == 0 and not fpsTouched) then
                return
            end
            fpsTouched = true
            pcall(setfpscap, value > 0 and value or 60)
        end
    })
    MyConfig:Register("AA_FpsCap", FpsSlider)

    -- บันทึกโครงสร้างของเกมลงไฟล์ (ไว้ส่งให้คนทำสคริปตอนเกมอัปเดตแล้วฟังก์ชันไม่ทำงาน)
    PerfSec:Button({
        Title = "loc:aa_debug_title",
        Desc = "loc:aa_debug_desc",
        Callback = function()
            task.spawn(function()
                local lines = {}
                local function add(text)
                    lines[#lines + 1] = tostring(text)
                end
                local function children(label, parent, depth)
                    add("[" .. label .. "]")
                    if not parent then
                        add("  (missing)")
                        return
                    end
                    for _, child in ipairs(parent:GetChildren()) do
                        add("  " .. child.Name .. " : " .. child.ClassName)
                        if depth and depth > 1 then
                            for _, sub in ipairs(child:GetChildren()) do
                                add("    " .. sub.Name .. " : " .. sub.ClassName)
                            end
                        end
                    end
                end
                local function keys(label, tbl)
                    add("[" .. label .. "]")
                    if type(tbl) ~= "table" then
                        add("  (missing)")
                        return
                    end
                    local names = {}
                    for key, value in pairs(tbl) do
                        names[#names + 1] = tostring(key) .. " : " .. type(value)
                        if #names >= 80 then
                            break
                        end
                    end
                    table.sort(names)
                    add("  " .. table.concat(names, "\n  "))
                end

                add("XEPHEX HUB game info")
                add("place " .. tostring(game.PlaceId) .. " / lobby " .. tostring(AA.IsLobby) .. " / match " .. tostring(AA.InMatch))
                add("executor " .. tostring(safe(function() return identifyexecutor() end)))
                add("hook " .. tostring(AA.Net.CanHook) .. " / files " .. tostring(AA.CanFiles))
                add("shape spawn=" .. tostring(AA.Shape.spawn) .. " unit=" .. tostring(AA.Shape.unit))
                children("endpoints.client_to_server", AA.Endpoints())
                add("[workspace]")
                for _, child in ipairs(workspace:GetChildren()) do
                    if child.Name:sub(1, 1) == "_" or child:IsA("ValueBase") then
                        add("  " .. child.Name .. " : " .. child.ClassName)
                    end
                end
                children("workspace._DATA", workspace:FindFirstChild("_DATA"))
                children("workspace._BASES", workspace:FindFirstChild("_BASES"), 2)
                children("workspace._terrain", workspace:FindFirstChild("_terrain"))
                children("workspace._LOBBIES", workspace:FindFirstChild("_LOBBIES"), 2)
                children("LocalPlayer", LocalPlr)
                children("LocalPlayer._stats", LocalPlr:FindFirstChild("_stats"))
                children("LocalPlayer._settings", LocalPlr:FindFirstChild("_settings"))
                children("PlayerGui", LocalPlr:FindFirstChildOfClass("PlayerGui"))
                local unit = AA.Mine[1] or safe(function() return workspace._UNITS:GetChildren()[1] end)
                if unit then
                    add("unit name " .. unit.Name)
                    children("unit", unit)
                    children("unit._stats", unit:FindFirstChild("_stats"))
                end
                local session = AA.Session()
                keys("session", session)
                keys("session.collection", session and session.collection)
                keys("session.collection.collection_profile_data", safe(function() return session.collection.collection_profile_data end))
                keys("level data", AA.InMatch and AA.Level() or nil)
                keys("EndpointsClient", AA.Service("EndpointsClient"))

                local text = table.concat(lines, "\n")
                local path = "XEPHEX HUB/aa_game_info.txt"
                local saved = pcall(function()
                    if isfolder and makefolder and not isfolder("XEPHEX HUB") then
                        makefolder("XEPHEX HUB")
                    end
                    writefile(path, text)
                end)
                pcall(function()
                    setclipboard(text)
                end)
                Notify(saved and (T("aa_debug_saved") .. path) or T("aa_debug_copied"), 5)
            end)
        end
    })

    ------------------------------------------------------
    -- หลังสร้าง UI ครบ: ใส่รายการที่มาจากข้อมูลของเกม (ก่อนโหลด Config ค่าที่เซฟไว้จะได้เลือกเจอ)
    ------------------------------------------------------
    table.insert(AfterLoad, function()
        if refreshUnits(true) == 0 and AA.Supported then
            -- เกมยังสร้าง session ไม่เสร็จ: ลองใหม่ห่างขึ้นเรื่อยๆ ไม่กี่ครั้ง แล้วเลิก
            task.spawn(function()
                for attempt = 1, 5 do
                    task.wait(attempt * 3)
                    if not AA.Alive() or refreshUnits(true) > 0 then
                        Auto.Wake()
                        return
                    end
                end
            end)
        end
    end)

    table.insert(AfterLoad, function()
        if not AA.IsLobby then
            return
        end
        syncWorlds()
        local banners = AA.Data("Banners")
        local values = {}
        for id, banner in pairs(type(banners) == "table" and banners or {}) do
            if type(banner) == "table" and banner.active then
                values[#values + 1] = option(tostring(banner.id or id), AA.Image(banner))
            end
        end
        table.sort(values, function(a, b)
            return titleOf(a) < titleOf(b)
        end)
        pcall(function()
            BannerDropdown:Refresh(values)
        end)
    end)
end

----------------------------------------------------------
-- 🎨 Tab Settings : ธีมสี
----------------------------------------------------------
local syncCustomFromPickers   -- ใช้ตอนโหลด Config (ประกาศไว้ตรงนี้ ให้ส่วนท้ายสุดเรียกได้)

Yield()
do
    local ThemeSec = TabSettings:Section({
        Title = "loc:sec_theme",
        Icon = "palette",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    local CustomColors = {
        Background = Color3.fromHex("#101010"),
        Accent = Color3.fromHex("#18181b"),
        Text = Color3.fromHex("#ffffff"),
        Icon = Color3.fromHex("#a1a1aa"),
        Button = Color3.fromHex("#52525b"),
        Toggle = Color3.fromHex("#3b82f6"),
    }

    -- สร้างธีม Custom จากสีที่เลือกไว้
    local function buildCustomTheme()
        local theme = {}
        for k, v in pairs(WindUI:GetThemes().Dark or {}) do
            theme[k] = v
        end
        theme.Name = "Custom"
        theme.Background = CustomColors.Background
        theme.Accent = CustomColors.Accent
        theme.Text = CustomColors.Text
        theme.Icon = CustomColors.Icon
        theme.Button = CustomColors.Button
        theme.Toggle = CustomColors.Toggle
        theme.Slider = CustomColors.Toggle
        theme.Checkbox = CustomColors.Toggle
        WindUI:AddTheme(theme)
    end

    buildCustomTheme()

    local currentTheme = WindUI:GetCurrentTheme()

    local themeNames = {}
    for name in pairs(WindUI:GetThemes()) do
        table.insert(themeNames, name)
    end
    table.sort(themeNames)

    -- เปลี่ยนธีม = WindUI ไล่ทาสีของทุกชิ้นใน UI ใหม่หมด (หลายพันชิ้น) -> ทำเฉพาะตอนธีมเปลี่ยนจริงๆ
    --   ตอนโหลด Config ยังไม่ทาสี (สีที่เซฟไว้ยังมาไม่ครบ) ไปทาทีเดียวตอนท้ายใน syncCustomFromPickers
    --   (เดิมโหลด Config ทีไรทาสีทั้ง UI ใหม่ 1-2 รอบเสมอ แม้ธีมเดิม = กระตุกตอนโหลดเสร็จ)
    local ThemeDropdown = ThemeSec:Dropdown({
        Title = "loc:theme_title",
        Desc = "loc:theme_desc",
        Values = themeNames,
        Value = currentTheme,
        Callback = function(selected)
            currentTheme = selected
            if loading then
                return
            end
            if selected == "Custom" then
                buildCustomTheme()
            elseif selected == WindUI:GetCurrentTheme() then
                return
            end
            WindUI:SetTheme(selected)
        end
    })
    MyConfig:Register("Theme", ThemeDropdown)

    -- เลือกสี = สลับเป็นธีม Custom ให้เอง
    local function applyCustomColor(key, color)
        CustomColors[key] = color
        buildCustomTheme()
        currentTheme = "Custom"
        WindUI:SetTheme("Custom")
        pcall(function()
            ThemeDropdown:Select({ "Custom" })
        end)
    end

    local PickerBackground = ThemeSec:Colorpicker({
        Title = "loc:color_background",
        Desc = "loc:color_desc",
        Default = CustomColors.Background,
        Callback = function(color) applyCustomColor("Background", color) end
    })
    MyConfig:Register("Color_Background", PickerBackground)

    local PickerAccent = ThemeSec:Colorpicker({
        Title = "loc:color_accent",
        Desc = "loc:color_desc",
        Default = CustomColors.Accent,
        Callback = function(color) applyCustomColor("Accent", color) end
    })
    MyConfig:Register("Color_Accent", PickerAccent)

    local PickerText = ThemeSec:Colorpicker({
        Title = "loc:color_text",
        Desc = "loc:color_desc",
        Default = CustomColors.Text,
        Callback = function(color) applyCustomColor("Text", color) end
    })
    MyConfig:Register("Color_Text", PickerText)

    local PickerIcon = ThemeSec:Colorpicker({
        Title = "loc:color_icon",
        Desc = "loc:color_desc",
        Default = CustomColors.Icon,
        Callback = function(color) applyCustomColor("Icon", color) end
    })
    MyConfig:Register("Color_Icon", PickerIcon)

    local PickerButton = ThemeSec:Colorpicker({
        Title = "loc:color_button",
        Desc = "loc:color_desc",
        Default = CustomColors.Button,
        Callback = function(color) applyCustomColor("Button", color) end
    })
    MyConfig:Register("Color_Button", PickerButton)

    local PickerToggle = ThemeSec:Colorpicker({
        Title = "loc:color_toggle",
        Desc = "loc:color_desc",
        Default = CustomColors.Toggle,
        Callback = function(color) applyCustomColor("Toggle", color) end
    })
    MyConfig:Register("Color_Toggle", PickerToggle)

    local AllPickers = {
        Background = PickerBackground,
        Accent = PickerAccent,
        Text = PickerText,
        Icon = PickerIcon,
        Button = PickerButton,
        Toggle = PickerToggle,
    }

    -- หลังโหลด Config: ดึงสีที่เซฟไว้กลับมาใส่ธีม Custom แล้วทาสีทีเดียว (เฉพาะตอนที่ธีมต่างจากที่ใช้อยู่ / ธีม Custom)
    syncCustomFromPickers = function()
        for key, picker in pairs(AllPickers) do
            if typeof(picker.Default) == "Color3" then
                CustomColors[key] = picker.Default
            end
        end
        buildCustomTheme()
        if currentTheme == "Custom" or currentTheme ~= WindUI:GetCurrentTheme() then
            WindUI:SetTheme(currentTheme)
        end
    end
end

----------------------------------------------------------
-- 🖼️ Tab Settings : รูปพื้นหลัง
----------------------------------------------------------
local bgLink = ""   -- ลิงก์รูปที่ผู้เล่นใส่ไว้ (ใช้ตอนโหลด Config)
local applyBackground

Yield()
do
    local BgSec = TabSettings:Section({
        Title = "loc:sec_background",
        Icon = "image",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    local lastBackground

    -- ลบรูปพื้นหลังแบบเก่า (สคริปรุ่นก่อนเซฟรูปใหม่ทุกครั้งที่รัน ไฟล์เลยเยอะจนรกเครื่อง)
    task.spawn(function()
        pcall(function()
            if not (listfiles and delfile and isfolder and isfolder("XEPHEX HUB")) then
                return
            end
            for _, file in ipairs(listfiles("XEPHEX HUB")) do
                if tostring(file):match("bg_%d+_%d+%.png$") then
                    delfile(file)
                end
            end
        end)
    end)

    -- แปลงลิงก์/ไอดี เป็นรูปที่ใช้ได้ (ไม่ได้ = nil)
    local function resolveImage(url)
        if url:match("^%d+$") then
            return "rbxassetid://" .. url
        end
        if url:match("^rbxassetid://") or url:match("^rbxasset://") then
            return url
        end
        if not url:match("^https?://") then
            return nil
        end
        if not (writefile and getcustomasset) then
            return nil
        end
        if not downloadBackground(url) then
            return nil
        end

        local okAsset, asset = pcall(getcustomasset, backgroundPath(url))
        if okAsset then
            return asset
        end
        return nil
    end

    applyBackground = function(url)
        url = tostring(url or ""):match("^%s*(.-)%s*$")
        if url == "" or url == lastBackground then
            return
        end

        local image = resolveImage(url)
        if image and pcall(Window.SetBackgroundImage, Window, image) then
            lastBackground = url
            Notify(T("bg_applied"), 2)
        else
            Notify(T("bg_failed"), 4)
        end
    end

    local BgInput = BgSec:Input({
        Title = "loc:bg_link_title",
        Desc = "loc:bg_link_desc",
        Placeholder = "https://...",
        Default = "",
        Value = "",
        Callback = function(Value)
            bgLink = Value or ""
            applyBackground(bgLink)
        end
    })
    MyConfig:Register("BackgroundLink", BgInput)

    local BgTransparency = BgSec:Slider({
        Title = "loc:bg_transparency",
        Step = 0.05,
        Value = { Min = 0, Max = 1, Default = 0 },
        Callback = function(value)
            pcall(Window.SetBackgroundImageTransparency, Window, value)
        end
    })
    MyConfig:Register("BackgroundTransparency", BgTransparency)

    BgSec:Button({
        Title = "loc:bg_reset",
        Desc = "loc:bg_reset_desc",
        Callback = function()
            bgLink = ""
            lastBackground = nil
            pcall(function()
                BgInput:Set("")
            end)
            applyBackground(DefaultBackground)
        end
    })
end

----------------------------------------------------------
-- 🌐 Tab Settings : ภาษา
----------------------------------------------------------
Yield()
do
    local LangSec = TabSettings:Section({
        Title = "loc:sec_language",
        Icon = "languages",
        Box = true,
        TextSize = 18,
        Opened = false
    })

    local LangDropdown = LangSec:Dropdown({
        Title = "loc:language_title",
        Desc = "loc:language_desc",
        Values = { "ไทย", "English" },
        Value = "ไทย",
        Callback = function(selected)
            local newLang = "en"
            if selected == "ไทย" then
                newLang = "th"
            end
            if newLang == currentLang then
                return
            end
            currentLang = newLang
            WindUI:SetLanguage(currentLang)
        end
    })
    MyConfig:Register("Language", LangDropdown)
end

----------------------------------------------------------
-- ⌨️ Tab Settings : Keybind
----------------------------------------------------------
Yield()
do
    local Keybind = TabSettings:Keybind({
        Title = "loc:keybind_title",
        Desc = "loc:keybind_desc",
        Value = "F",
        Callback = function(v)
            Window:SetToggleKey(Enum.KeyCode[v])
        end
    })
    MyConfig:Register("Keybind", Keybind)
end

----------------------------------------------------------
-- 🔗 Tab Settings : JobId Tools
----------------------------------------------------------
Yield()
do
    -- แจ้งเตือนพร้อมไอคอน
    local function notifyIcon(text)
        WindUI:Notify({
            Title = "XEPHEX HUB",
            Content = text,
            Duration = 5,
            Icon = "rbxassetid://80283328189076"
        })
    end

    local JobId = ""

    TabSettings:Section({ Title = "loc:sec_jobid" })

    TabSettings:Button({
        Title = "loc:join_link_title",
        Desc = "loc:join_link_desc",
        Callback = function()
            local placeId = game.PlaceId
            local jobId = game.JobId

            if jobId and jobId ~= "" then
                local joinLink = string.format(
                    "https://www.roblox.com/games/start?placeId=%s&launchData=%s/%s",
                    placeId, placeId, jobId
                )
                setclipboard(joinLink)
                notifyIcon(T("link_copied"))
            else
                notifyIcon(T("jobid_missing"))
            end
        end
    })

    TabSettings:Button({
        Title = "loc:copy_jobid_title",
        Desc = "loc:copy_jobid_desc",
        Callback = function()
            setclipboard(tostring(game.JobId))
            notifyIcon(T("jobid_copied"))
        end
    })

    TabSettings:Input({
        Title = "loc:jobid_input_title",
        Desc = "loc:jobid_input_desc",
        Placeholder = "...",
        Default = "",
        Callback = function(Value)
            JobId = Value or ""
        end
    })

    TabSettings:Button({
        Title = "loc:teleport_title",
        Desc = "loc:teleport_desc",
        Callback = function()
            if JobId ~= "" then
                game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, JobId)
            else
                notifyIcon(T("jobid_required"))
            end
        end
    })
end

----------------------------------------------------------
-- 💾 Config Load / Save
--   ทำต่อทันทีที่สร้าง UI ครบ (เดิมรอเฉยๆ 1.5 วิ ก่อนโหลด Config แล้วรออีก 4 วิ ก่อนใส่รูปพื้นหลัง)
--   โหลดทีละชิ้น: เดิม MyConfig:Load() ใส่ค่าทุกชิ้น + เปิดออโต้ทุกตัวพร้อมกันในเฟรมเดียว = เกมกระตุกตอนโหลดเสร็จ
--     แบบใหม่ใส่ค่าทีละชิ้น พักให้เกมวาดจอเป็นช่วงๆ ด้วย Yield() เหมือนตอนสร้าง UI
--     ใส่ค่าที่ไม่ใช่สวิตช์ก่อน (ดรอปดาวน์ / ช่องพิมพ์ / สไลเดอร์ ...) แล้วค่อยเปิดสวิตช์
--     ออโต้จะได้เห็นค่าที่เลือกไว้ครบตั้งแต่เริ่ม (เดิมลำดับสุ่ม บางทีสวิตช์มาก่อนค่าที่เลือก)
--   อ่านไฟล์เองไม่ได้ = ให้ WindUI โหลดแบบเดิม
----------------------------------------------------------
local function loadConfigSliced(config)
    local parser = type(ConfigManager) == "table" and ConfigManager.Parser
    if type(parser) ~= "table" or type(config.Elements) ~= "table" or not (readfile and isfile) then
        return config:Load()
    end

    local okFile, data = pcall(function()
        if not isfile(config.Path) then
            return false
        end
        return HttpService:JSONDecode(readfile(config.Path))
    end)
    if not okFile then
        return config:Load()
    end
    if type(data) ~= "table" then
        return   -- ยังไม่เคยเซฟ
    end
    if not data.__version then
        data = { __elements = data, __custom = {} }
    end

    -- ชิ้นที่ใส่ Flag ไว้ (WindUI ลงทะเบียนให้เองตอนโหลด)
    if type(Window.PendingFlags) == "table" then
        for name, element in pairs(Window.PendingFlags) do
            config:Register(name, element)
        end
    end

    local toggles = {}
    local function apply(element, saved)
        Yield()
        task.spawn(function()
            local ok, err = pcall(parser[saved.__type].Load, element, saved)
            if not ok then
                warn("[XEPHEX HUB] config: " .. tostring(err))
            end
        end)
    end
    for name, saved in pairs(type(data.__elements) == "table" and data.__elements or {}) do
        local element = config.Elements[name]
        if element and type(saved) == "table" and parser[saved.__type] then
            if saved.__type == "Toggle" then
                table.insert(toggles, { element, saved })
            else
                apply(element, saved)
            end
        end
    end
    for _, item in ipairs(toggles) do
        apply(item[1], item[2])
    end

    config.CustomData = type(data.__custom) == "table" and data.__custom or {}
    return config.CustomData
end

task.spawn(function()
    -- ใส่รายการดรอปดาวน์ที่รอไว้ก่อน ค่าที่เซฟไว้ใน Config จะได้เลือกเจอครบ
    for _, job in ipairs(AfterLoad) do
        pcall(job)
        Yield()
    end

    local okLoad, loadErr = pcall(loadConfigSliced, MyConfig)
    if not okLoad then
        warn("[XEPHEX HUB] config: " .. tostring(loadErr))
    end

    pcall(syncCustomFromPickers)

    loading = false   -- โหลดเสร็จแล้ว

    Notify(T("config_loaded"), 1)

    pcall(function()
        if bgLink ~= "" then
            applyBackground(bgLink)
        else
            applyBackground(DefaultBackground)
        end
    end)
end)

-- เซฟ Config ทุก 20 วินาที
task.spawn(function()
    while task.wait(60) do
        pcall(function()
            MyConfig:Save()
        end)
    end
end)

Window:OnClose(function()
    pcall(function()
        MyConfig:Save()
    end)
end)

LocalPlr.OnTeleport:Connect(function()
    pcall(function()
        MyConfig:Save()
    end)
end)
