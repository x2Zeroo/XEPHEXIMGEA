'use strict';

// เจนเสียง — ตัวเตรียมข้อความสำหรับเครื่องสังเคราะห์เสียง
// ไม่มี dependency ไม่เรียกบริการภายนอก ไม่ใช้ API key
// POST /api/general  { "text": "..." }  ->  { ok, chunks: [{ text, pauseMs }], ... }

const MAX_CHARS = 3000;
const MAX_BODY_BYTES = 64 * 1024;
const MAX_CHUNK = 140;

const PAUSE = { paragraph: 420, sentence: 300, clause: 180, wrap: 240, hard: 40 };

const DIGIT = ['ศูนย์', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
const PLACE = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน'];

function readGroup(g) {
  let out = '';
  const n = g.length;
  for (let i = 0; i < n; i++) {
    const d = Number(g[i]);
    const pos = n - i - 1;
    if (!d) continue;
    if (pos === 1) out += (d === 1 ? '' : d === 2 ? 'ยี่' : DIGIT[d]) + 'สิบ';
    else if (pos === 0) out += d === 1 && n > 1 ? 'เอ็ด' : DIGIT[d];
    else out += DIGIT[d] + PLACE[pos];
  }
  return out;
}

function readDigits(s) {
  let out = '';
  for (const ch of s) if (ch >= '0' && ch <= '9') out += DIGIT[Number(ch)];
  return out;
}

function readInt(s) {
  s = s.replace(/^0+(?=\d)/, '');
  if (s === '0') return DIGIT[0];
  const groups = [];
  while (s.length > 6) {
    groups.unshift(s.slice(-6));
    s = s.slice(0, -6);
  }
  groups.unshift(s);
  let out = '';
  groups.forEach((g, i) => {
    const trimmed = g.replace(/^0+/, '');
    if (trimmed) out += readGroup(trimmed);
    if (i < groups.length - 1) out += 'ล้าน';
  });
  return out;
}

function readNumber(token) {
  const clean = token.replace(/,/g, '');
  const [int, frac] = clean.split('.');
  const spellOut = (int.length > 1 && int[0] === '0') || int.length > 15;
  let out = spellOut ? readDigits(int) : readInt(int);
  if (frac) out += 'จุด' + readDigits(frac);
  return out;
}

const NUM = '\\d+(?:,\\d{3})*(?:\\.\\d+)?';

const UNITS = {
  'กม.': 'กิโลเมตร', 'กก.': 'กิโลกรัม', 'ซม.': 'เซนติเมตร', 'มม.': 'มิลลิเมตร', 'ชม.': 'ชั่วโมง', 'ม.': 'เมตร',
  km: 'กิโลเมตร', kg: 'กิโลกรัม', cm: 'เซนติเมตร', mm: 'มิลลิเมตร', ml: 'มิลลิลิตร', gb: 'กิกะไบต์', mb: 'เมกะไบต์',
  m: 'เมตร', g: 'กรัม', l: 'ลิตร', '°c': 'องศาเซลเซียส', '°': 'องศา',
};
const UNIT_RE = new RegExp(
  '(' + NUM + ')\\s*(' +
    Object.keys(UNITS).sort((a, b) => b.length - a.length).map((u) => u.replace(/[.°]/g, '\\$&')).join('|') +
    ')(?![A-Za-z\\u0E00-\\u0E7F])',
  'gi'
);

const ABBREVIATIONS = [
  ['ฯลฯ', 'และอื่นๆ'], ['พ.ศ.', 'พอสอ'], ['ค.ศ.', 'คอสอ'], ['น.ส.', 'นางสาว'], ['ด.ช.', 'เด็กชาย'], ['ด.ญ.', 'เด็กหญิง'],
  ['ดร.', 'ด็อกเตอร์'], ['กทม.', 'กรุงเทพมหานคร'], ['รพ.', 'โรงพยาบาล'],
];

const SYMBOLS = { '&': 'และ', '+': 'บวก', '=': 'เท่ากับ', '@': 'แอท', '%': 'เปอร์เซ็นต์', '×': 'คูณ', '÷': 'หาร' };

const LETTERS = {
  a: 'เอ', b: 'บี', c: 'ซี', d: 'ดี', e: 'อี', f: 'เอฟ', g: 'จี', h: 'เอช', i: 'ไอ', j: 'เจ', k: 'เค', l: 'แอล', m: 'เอ็ม',
  n: 'เอ็น', o: 'โอ', p: 'พี', q: 'คิว', r: 'อาร์', s: 'เอส', t: 'ที', u: 'ยู', v: 'วี', w: 'ดับเบิลยู', x: 'เอ็กซ์', y: 'วาย', z: 'แซด',
};

const WORDS = {
  roblox: 'โรบล็อกซ์', tiktok: 'ติ๊กต็อก', youtube: 'ยูทูบ', facebook: 'เฟซบุ๊ก', google: 'กูเกิล', line: 'ไลน์',
  ok: 'โอเค', okay: 'โอเค', hello: 'เฮลโล', hi: 'ไฮ', bye: 'บาย', game: 'เกม', games: 'เกม', live: 'ไลฟ์', like: 'ไลก์',
  share: 'แชร์', subscribe: 'ซับสไครบ์', online: 'ออนไลน์', internet: 'อินเทอร์เน็ต', wifi: 'ไวไฟ', email: 'อีเมล',
  app: 'แอป', web: 'เว็บ', website: 'เว็บไซต์', click: 'คลิก', link: 'ลิงก์', video: 'วิดีโอ', clip: 'คลิป', free: 'ฟรี',
  top: 'ท็อป', sale: 'เซล', shop: 'ช็อป', team: 'ทีม', boss: 'บอส', level: 'เลเวล', item: 'ไอเทม',
  server: 'เซิร์ฟเวอร์', admin: 'แอดมิน', bot: 'บอต', chat: 'แชต', comment: 'คอมเมนต์', post: 'โพสต์', story: 'สตอรี่',
  test: 'เทสต์', the: 'เดอะ', and: 'แอนด์', version: 'เวอร์ชัน', update: 'อัปเดต', download: 'ดาวน์โหลด',
  upload: 'อัปโหลด', file: 'ไฟล์', computer: 'คอมพิวเตอร์', robot: 'โรบอต', super: 'ซูเปอร์', happy: 'แฮปปี้',
};

// คำซ้ำหลายพยางค์ที่เดาขอบเขตพยางค์ไม่ได้ ต้องระบุเอง
const REPEAT_WORDS = [
  'ธรรมดา', 'ทั้งหลาย', 'ละเอียด', 'ประมาณ', 'สบาย', 'สนุก', 'อร่อย', 'ระวัง', 'สะอาด', 'ตลก', 'ฉลาด', 'ขนาด',
  'เหมือน', 'คล้าย', 'สะดวก', 'เฉย', 'เสมอ', 'แปลก', 'ตรง', 'พร้อม', 'กลม', 'กลาง',
];

const LEAD_VOWELS = 'เแโใไ';
const isConsonant = (c) => c >= '\u0E01' && c <= '\u0E2E';
const isMark = (c) => (c >= '\u0E30' && c <= '\u0E3A') || (c >= '\u0E47' && c <= '\u0E4D');
const CLUSTER_FIRST = 'กขคตปผพทบดจสศฟ';

function leadsCluster(first, second) {
  if (first === 'ห') return 'งญนมยรลว'.includes(second);
  if (first === 'อ') return second === 'ย';
  return 'รลว'.includes(second) && CLUSTER_FIRST.includes(first);
}

function lastSyllableStart(s) {
  const n = s.length;
  if (n <= 3) return 0;
  let anchor = -1;
  for (let i = n - 1; i >= 0; i--) {
    if (isMark(s[i])) {
      anchor = i;
      break;
    }
  }
  let start;
  if (anchor < 0 || n - 1 - anchor > 2) {
    start = n - 2;
    if (n >= 3 && leadsCluster(s[n - 3], s[n - 2])) start = n - 3;
  } else {
    start = anchor;
    while (start > 0 && !isConsonant(s[start])) start--;
    if (start > 0 && leadsCluster(s[start - 1], s[start])) start--;
  }
  if (start > 0 && LEAD_VOWELS.includes(s[start - 1])) start--;
  return start;
}

function expandRepeats(text) {
  let out = '';
  for (const ch of text) {
    if (ch !== 'ๆ') {
      out += ch;
      continue;
    }
    const body = out.replace(/\s+$/, '');
    const run = (body.match(/[\u0E01-\u0E4D]+$/) || [''])[0];
    if (!run) continue;
    const known = REPEAT_WORDS.find((w) => run.endsWith(w));
    out = body + (known || run.slice(lastSyllableStart(run)));
  }
  return out;
}

function spellLatin(word) {
  const lower = word.toLowerCase();
  if (WORDS[lower]) return WORDS[lower];
  let out = '';
  for (const ch of lower) out += LETTERS[ch] || '';
  return out;
}

function normalize(input) {
  let t = String(input).normalize('NFC');
  t = t.replace(/[\u200B-\u200D\uFEFF]/g, '');
  t = t.replace(/\r\n?/g, '\n').replace(/[\t\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ');
  t = t.replace(/[๐-๙]/g, (d) => String(d.charCodeAt(0) - 0x0e50));

  for (const [abbr, full] of ABBREVIATIONS) t = t.split(abbr).join(full);

  t = t.replace(/(\d{1,2})[:.](\d{2})\s*น\./g, (m, h, mm) => timeWords(h, mm) || m);
  t = t.replace(/(^|[^\d:])(\d{1,2}):(\d{2})(?![\d:])/g, (m, pre, h, mm) => (timeWords(h, mm) ? pre + timeWords(h, mm) : m));

  t = t.replace(/\b0\d{1,2}-\d{3,4}-\d{4}\b/g, (m) => readDigits(m));
  t = t.replace(/(^|[\s(])[-−](?=\d)/g, '$1ลบ');
  // เว้นวรรครอบตัวเลขเป็นธรรมเนียมการเขียน ไม่ใช่จังหวะหยุด โมเดลจะหยุดทุกช่องว่างจึงต้องเอาออก
  t = t.replace(/([\u0E01-\u0E4D]) +(?=[\d฿$])/g, '$1').replace(/([\d%฿]) +(?=[\u0E01-\u0E4D])/g, '$1');
  t = t.replace(new RegExp('฿\\s*(' + NUM + ')', 'g'), (m, n) => readNumber(n) + 'บาท');
  t = t.replace(new RegExp('(' + NUM + ')\\s*฿', 'g'), (m, n) => readNumber(n) + 'บาท');
  t = t.replace(new RegExp('\\$\\s*(' + NUM + ')', 'g'), (m, n) => readNumber(n) + 'ดอลลาร์');
  t = t.replace(new RegExp('(' + NUM + ')\\s*%', 'g'), (m, n) => readNumber(n) + 'เปอร์เซ็นต์');
  t = t.replace(UNIT_RE, (m, n, unit) => readNumber(n) + UNITS[unit.toLowerCase()]);

  t = t.replace(/(\d)\s*\/\s*(?=\d)/g, '$1ทับ');
  t = t.replace(/(\d)\s*[-–—]\s*(?=\d)/g, '$1ถึง');
  t = t.replace(new RegExp(NUM, 'g'), (m) => readNumber(m));

  t = t.replace(/[&+=@%×÷]/g, (s) => SYMBOLS[s]);
  t = t.replace(/[A-Za-z]+/g, (w) => spellLatin(w));
  t = expandRepeats(t);
  t = t.replace(/ฃ/g, 'ข').replace(/ฅ/g, 'ค').replace(/ๅ/g, 'า');
  return t;
}

function timeWords(h, mm) {
  const hour = Number(h);
  const minute = Number(mm);
  if (hour > 24 || minute > 59) return '';
  return readInt(String(hour)) + 'นาฬิกา' + (minute ? readInt(String(minute)) + 'นาที' : '');
}

const SPEAKABLE = /[^\u0E01-\u0E2E\u0E30-\u0E39\u0E40-\u0E44\u0E47-\u0E4D ]/g;

function cleanChunk(s) {
  return s.replace(SPEAKABLE, ' ').replace(/ +/g, ' ').trim();
}

function safeCut(s, limit) {
  const floor = Math.floor(limit / 2);
  for (let i = limit; i > floor; i--) if (LEAD_VOWELS.includes(s[i])) return i;
  for (let i = limit; i > floor; i--) {
    if (isConsonant(s[i]) && !LEAD_VOWELS.includes(s[i - 1])) return i;
  }
  return limit;
}

function wrap(text, pause) {
  const out = [];
  let rest = text;
  while (rest.length > MAX_CHUNK) {
    const space = rest.lastIndexOf(' ', MAX_CHUNK);
    if (space > MAX_CHUNK / 3) {
      out.push({ text: rest.slice(0, space), pauseMs: PAUSE.wrap });
      rest = rest.slice(space + 1);
    } else {
      const cut = safeCut(rest, MAX_CHUNK);
      out.push({ text: rest.slice(0, cut), pauseMs: PAUSE.hard });
      rest = rest.slice(cut);
    }
  }
  if (rest) out.push({ text: rest, pauseMs: pause });
  return out;
}

function prepare(input) {
  const normalized = normalize(input);
  const chunks = [];
  const re = /([^\n.!?…。,;:،、]*)([\n.!?…。,;:،、]+|$)/g;
  let m;
  while ((m = re.exec(normalized)) !== null) {
    if (m[0] === '') {
      if (re.lastIndex >= normalized.length) break;
      re.lastIndex++;
      continue;
    }
    const text = cleanChunk(m[1]);
    const delim = m[2];
    const pause = delim.includes('\n') ? PAUSE.paragraph : /[.!?…。]/.test(delim) ? PAUSE.sentence : PAUSE.clause;
    if (!text) {
      if (chunks.length) chunks[chunks.length - 1].pauseMs = Math.max(chunks[chunks.length - 1].pauseMs, pause);
      continue;
    }
    chunks.push(...wrap(text, pause));
  }
  if (chunks.length) chunks[chunks.length - 1].pauseMs = 0;
  const speakable = chunks.reduce((n, c) => n + c.text.length, 0);
  return {
    chunks,
    normalized: chunks.map((c) => c.text).join(' '),
    charCount: speakable,
    estimatedSeconds: Math.round(speakable * 0.078 * 10) / 10,
  };
}

function readBody(req) {
  if (req.body !== undefined && req.body !== null) {
    if (typeof req.body === 'string') return Promise.resolve(JSON.parse(req.body || '{}'));
    if (Buffer.isBuffer(req.body)) return Promise.resolve(JSON.parse(req.body.toString('utf8') || '{}'));
    return Promise.resolve(req.body);
  }
  return new Promise((resolve, reject) => {
    const parts = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        const err = new Error('ข้อความยาวเกินไป');
        err.status = 413;
        reject(err);
        req.destroy();
        return;
      }
      parts.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(parts).toString('utf8') || '{}'));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function send(res, status, payload) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.end(JSON.stringify(payload));
}

async function handler(req, res) {
  if (req.method === 'GET' || req.method === 'HEAD') {
    return send(res, 200, { ok: true, service: 'jen-siang-text', maxChars: MAX_CHARS, usage: 'POST { "text": "..." }' });
  }
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'GET, POST');
    return send(res, 405, { ok: false, error: 'รองรับเฉพาะ GET และ POST' });
  }
  let body;
  try {
    body = await readBody(req);
  } catch (e) {
    return send(res, e.status || 400, { ok: false, error: e.status ? e.message : 'รูปแบบข้อมูลไม่ถูกต้อง (ต้องเป็น JSON)' });
  }
  const text = body && typeof body.text === 'string' ? body.text : '';
  if (!text.trim()) return send(res, 400, { ok: false, error: 'กรุณาใส่ข้อความ' });
  if (text.length > MAX_CHARS) {
    return send(res, 413, { ok: false, error: 'ข้อความยาวเกิน ' + MAX_CHARS + ' ตัวอักษร' });
  }
  const result = prepare(text);
  if (!result.chunks.length) {
    return send(res, 422, { ok: false, error: 'ไม่พบข้อความภาษาไทยที่อ่านออกเสียงได้' });
  }
  return send(res, 200, Object.assign({ ok: true }, result));
}

module.exports = handler;
module.exports.prepare = prepare;
module.exports.normalize = normalize;
