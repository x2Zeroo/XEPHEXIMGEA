'use strict';

// เจนเสียง — จัดการ API key
//
//   GET  /api/keys                     ตรวจว่า key ที่ส่งมาใช้ได้หรือไม่ และเป็นกุญแจระดับใด
//   POST /api/keys  { name, days? }    ออก API key ใหม่ (ต้องยืนยันด้วย ADMIN_KEY) days = 0 คือไม่หมดอายุ

const auth = require('./_lib/auth.js');
const { httpError, cors, sendJson, sendError, query, readBody } = require('./_lib/http.js');

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }
  try {
    const { query: q } = query(req);
    if (req.method === 'GET') {
      const who = auth.authenticate(req, q);
      return sendJson(res, 200, { ok: true, auth: auth.mode(), role: who.role, name: who.name, id: who.id, expiresAt: who.expiresAt });
    }
    if (req.method !== 'POST') {
      res.setHeader('Allow', 'GET, POST, OPTIONS');
      throw httpError(405, 'รองรับเฉพาะ GET และ POST');
    }
    auth.requireAdmin(req, q);
    const body = (await readBody(req)).json || {};
    return sendJson(res, 200, Object.assign({ ok: true }, auth.mint(body)));
  } catch (e) {
    return sendError(res, e);
  }
};
