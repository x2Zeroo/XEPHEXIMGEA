'use strict';

// เจนเสียง — API สังเคราะห์เสียงและโคลนเสียง (ทำงานบนเซิร์ฟเวอร์ทั้งหมด)
//
//   GET  /api/tts                    สถานะระบบ (ใส่ ?warm=1 เพื่ออุ่นโมเดลล่วงหน้า)
//   POST /api/tts   { text, voice?, speed?, pitch?, brightness?, match?, format?, stream? }  ->  เสียง WAV
//   POST /api/clone (ไฟล์เสียงเป็น application/octet-stream หรือ JSON { audio: base64 })     ->  รหัสเสียง 3 แบบ
//
// ถ้าตั้ง ADMIN_KEY ไว้ ทุกคำขอต้องส่ง API key ในเฮดเดอร์ Authorization: Bearer <key>

const general = require('./general.js');
const dsp = require('./_lib/dsp.js');
const engine = require('./_lib/engine.js');
const voices = require('./_lib/voice.js');
const cloner = require('./_lib/cloner.js');
const auth = require('./_lib/auth.js');
const { httpError, cors, sendJson, sendError, query, readBody } = require('./_lib/http.js');

const VERSION = '2.0.0';
const MAX_CHARS = 3000;
// เกินขนาดนี้ต้องส่งแบบสตรีม เพราะ Vercel จำกัดคำตอบแบบก้อนเดียวไว้ที่ 4.5 MB
const BUFFERED_LIMIT = 4.2 * 1024 * 1024;
const SAMPLE_TEXT = general.prepare(cloner.SAMPLE_TEXT).chunks.map((c) => c.text).join(' ');

let cold = true;

// เริ่มโหลดโมเดลเสียงมาตรฐานทันทีที่ instance เริ่มทำงาน ไม่รอคำขอแรก
engine.warm(['female']).catch(() => undefined);

function number(value, fallback, lo, hi, name) {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  if (!Number.isFinite(n)) throw httpError(400, 'ค่า ' + name + ' ต้องเป็นตัวเลข');
  return dsp.clamp(n, lo, hi);
}

function flag(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  return !/^(0|false|no|off)$/i.test(String(value));
}

async function handleStatus(req, res, q) {
  let role = null;
  try {
    role = auth.authenticate(req, q).role;
  } catch (e) {
    role = null;
  }
  if (q.warm && role) {
    const names = q.warm === 'clone' ? ['female', 'refenc', 'conv'] : q.warm === 'male' ? ['male'] : ['female'];
    await engine.warm(names);
  }
  sendJson(res, 200, {
    ok: true,
    service: 'jen-siang',
    version: VERSION,
    auth: auth.mode(),
    authorized: !!role,
    sampleRate: dsp.SR,
    maxChars: MAX_CHARS,
    voices: Object.keys(voices.BUILTIN),
    sampleText: SAMPLE_TEXT,
    engine: engine.status(),
  });
}

async function handleTts(req, res, q, wasCold) {
  const started = Date.now();
  auth.authenticate(req, q);
  const body = req.method === 'POST' ? (await readBody(req)).json || {} : {};
  const p = Object.assign({}, q, body);
  const text = typeof p.text === 'string' ? p.text : '';
  if (!text.trim()) throw httpError(400, 'กรุณาใส่ข้อความ (text)');
  if (text.length > MAX_CHARS) throw httpError(413, 'ข้อความยาวเกิน ' + MAX_CHARS + ' ตัวอักษร');
  const voice = voices.resolve(p.voice);
  const ui = {
    speed: number(p.speed, 1, 0.5, 2, 'speed'),
    semitones: number(p.pitch, 0, -6, 6, 'pitch'),
    brightness: number(p.brightness, 0, -6, 6, 'brightness'),
    match: flag(p.match, true),
  };
  const format = String(p.format || 'wav').toLowerCase();
  if (format !== 'wav' && format !== 'json' && format !== 'pcm') throw httpError(400, 'format ต้องเป็น wav, pcm หรือ json');
  const stream = format !== 'json' && flag(p.stream, false);
  const prepared = general.prepare(text);
  if (!prepared.chunks.length) throw httpError(422, 'ไม่พบข้อความภาษาไทยที่อ่านออกเสียงได้');

  // โหลดโมเดลที่ต้องใช้ทั้งหมดพร้อมกัน (โมเดลแปลงโทนดาวน์โหลดระหว่างที่เสียงฐานกำลังสังเคราะห์)
  engine.warm(engine.modelsFor(voice)).catch(() => undefined);

  let aborted = false;
  res.on('close', () => {
    if (!res.writableEnded) aborted = true;
  });

  const type = format === 'pcm' ? 'audio/L16; rate=' + dsp.SR + '; channels=1' : 'audio/wav';
  const baseHeaders = () => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Jen-Cold', wasCold ? '1' : '0');
    res.setHeader('X-Jen-Chunks', String(prepared.chunks.length));
  };

  const parts = [];
  const marks = [];
  let samples = 0;
  let headerSent = false;
  for (let i = 0; i < prepared.chunks.length && !aborted; i++) {
    const chunk = prepared.chunks[i];
    const pcm = await engine.synthChunk(voice, chunk.text, ui);
    if (!pcm.length) continue;
    const last = i === prepared.chunks.length - 1;
    const gap = last ? 0 : Math.round(((chunk.pauseMs || 0) / 1000 / ui.speed) * dsp.SR);
    marks.push({ start: samples / dsp.SR, end: (samples + pcm.length) / dsp.SR, text: chunk.text });
    samples += pcm.length + gap;
    const bytes = dsp.pcm16Buffer(pcm);
    const piece = gap ? Buffer.concat([bytes, Buffer.alloc(gap * 2)]) : bytes;
    if (!stream) {
      parts.push(piece);
      continue;
    }
    if (!headerSent) {
      headerSent = true;
      res.statusCode = 200;
      res.setHeader('Content-Type', type);
      baseHeaders();
      if (format === 'wav') res.write(dsp.writeWavHeader(Buffer.alloc(44), 0xffffffff - 36, dsp.SR));
    }
    res.write(piece);
  }
  if (aborted) return res.end();
  if (!samples) throw httpError(422, 'สร้างเสียงไม่สำเร็จ ลองใช้ข้อความอื่น');
  if (stream) return res.end();

  const elapsedMs = Date.now() - started;
  const pcmBytes = Buffer.concat(parts);
  const audio = format === 'pcm' ? pcmBytes : Buffer.concat([dsp.writeWavHeader(Buffer.alloc(44), pcmBytes.length, dsp.SR), pcmBytes]);
  const duration = pcmBytes.length / 2 / dsp.SR;
  if (format === 'json') {
    return sendJson(res, 200, {
      ok: true,
      sampleRate: dsp.SR,
      duration: Math.round(duration * 1000) / 1000,
      elapsedMs,
      cold: wasCold,
      chunks: marks.map((m) => ({ start: Math.round(m.start * 1000) / 1000, end: Math.round(m.end * 1000) / 1000, text: m.text })),
      audio: audio.toString('base64'),
    });
  }
  res.statusCode = 200;
  res.setHeader('Content-Type', type);
  baseHeaders();
  res.setHeader('X-Jen-Duration', duration.toFixed(3));
  res.setHeader('X-Jen-Elapsed-Ms', String(elapsedMs));
  res.setHeader('Content-Disposition', 'inline; filename="jen-siang.' + (format === 'pcm' ? 'pcm' : 'wav') + '"');
  if (audio.length <= BUFFERED_LIMIT) {
    res.setHeader('Content-Length', String(audio.length));
    return res.end(audio);
  }
  for (let offset = 0; offset < audio.length; offset += 65536) res.write(audio.subarray(offset, offset + 65536));
  return res.end();
}

async function handleClone(req, res, q) {
  if (req.method !== 'POST') throw httpError(405, 'ใช้ POST พร้อมไฟล์เสียง');
  auth.authenticate(req, q);
  const body = await readBody(req);
  let buffer = body.buffer || null;
  let hint = { format: q.format, sampleRate: q.sampleRate };
  if (!buffer && body.json && typeof body.json.audio === 'string') {
    buffer = Buffer.from(body.json.audio.replace(/^data:[^,]*,/, ''), 'base64');
    hint = { format: body.json.format || q.format, sampleRate: body.json.sampleRate || q.sampleRate };
  }
  sendJson(res, 200, await cloner.clone(buffer, hint, SAMPLE_TEXT));
}

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }
  const wasCold = cold;
  cold = false;
  try {
    if (req.method !== 'GET' && req.method !== 'POST') {
      res.setHeader('Allow', 'GET, POST, OPTIONS');
      throw httpError(405, 'รองรับเฉพาะ GET และ POST');
    }
    const { path, query: q } = query(req);
    const action = q.action || (/\/clone\/?$/.test(path) ? 'clone' : 'tts');
    if (action === 'clone') return await handleClone(req, res, q);
    if (req.method === 'GET' && q.text === undefined) return await handleStatus(req, res, q);
    return await handleTts(req, res, q, wasCold);
  } catch (e) {
    return sendError(res, e);
  }
};
