'use strict';

// โคลนเสียง: ถอดรหัสไฟล์เสียง -> วิเคราะห์เสียงต้นฉบับ -> จูนกับเสียงฐานแต่ละแบบ -> ได้รหัสเสียง 3 แบบให้เลือก

const dsp = require('./dsp.js');
const engine = require('./engine.js');
const voices = require('./voice.js');
const { httpError } = require('./http.js');

const SAMPLE_TEXT = 'สวัสดี นี่คือเสียงที่โคลนจากไฟล์ของคุณ ลองฟังดูว่าใกล้เคียงต้นฉบับแค่ไหน';
const MAX_INPUT_SECONDS = 180;
const MAX_SPEECH_SECONDS = 60;
const MIN_SPEECH_SECONDS = 3;
const SEGMENT_FRAMES = Math.round((10 * dsp.SR) / dsp.HOP);
const MIN_SEGMENT_FRAMES = Math.round(dsp.SR / dsp.HOP);
// ต่ำกว่านี้ถือเป็นช่วงเสียงผู้ชาย (ค่ากลางเชิงเรขาคณิตของเสียงฐานชาย ~119 Hz และหญิง ~229 Hz)
const BASE_SPLIT_HZ = 165;
const BASE_LABEL = { female: 'หญิง', male: 'ชาย' };

function looksLikeMp3(buf) {
  if (buf.length < 4) return false;
  if (buf[0] === 0x49 && buf[1] === 0x44 && buf[2] === 0x33) return true;
  return buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0;
}

async function decodeMp3(buf) {
  const { MPEGDecoder } = require('mpg123-decoder');
  const decoder = new MPEGDecoder();
  await decoder.ready;
  try {
    const { channelData, samplesDecoded, sampleRate } = decoder.decode(new Uint8Array(buf.buffer, buf.byteOffset, buf.length));
    if (!samplesDecoded || !sampleRate) throw httpError(422, 'ถอดรหัส MP3 ไม่สำเร็จ');
    const pcm = new Float32Array(samplesDecoded);
    for (const channel of channelData) {
      for (let i = 0; i < samplesDecoded; i++) pcm[i] += channel[i] / channelData.length;
    }
    return { pcm, sampleRate };
  } finally {
    decoder.free();
  }
}

// รับ WAV, MP3 หรือ PCM 16 บิตดิบ (เมื่อระบุ format=pcm_s16le) หน้าเว็บจะแปลงไฟล์ทุกชนิดเป็น WAV ให้ก่อนส่งเสมอ
async function decodeAudio(buf, hint) {
  if (!buf || buf.length < 64) throw httpError(400, 'ไม่พบไฟล์เสียงในคำขอ');
  if (dsp.isWav(buf)) {
    try {
      return dsp.decodeWav(buf);
    } catch (e) {
      throw httpError(422, e.message);
    }
  }
  if (hint && hint.format === 'pcm_s16le') {
    const sampleRate = Math.round(Number(hint.sampleRate)) || dsp.SR;
    if (sampleRate < 8000 || sampleRate > 192000) throw httpError(400, 'sampleRate ต้องอยู่ระหว่าง 8000 ถึง 192000');
    const pcm = new Float32Array(buf.length >> 1);
    for (let i = 0; i < pcm.length; i++) pcm[i] = buf.readInt16LE(i * 2) / 32768;
    return { pcm, sampleRate };
  }
  if (looksLikeMp3(buf)) return decodeMp3(buf);
  throw httpError(415, 'API รับไฟล์ WAV หรือ MP3 เท่านั้น (ไฟล์ชนิดอื่นให้อัปโหลดผ่านหน้าเว็บ ซึ่งจะดึงเสียงออกมาให้อัตโนมัติ)');
}

async function analyze(pcm, sampleRate) {
  const seconds = pcm.length / sampleRate;
  const limited = pcm.subarray(0, Math.round(MAX_INPUT_SECONDS * sampleRate));
  let clipped = 0;
  for (let i = 0; i < limited.length; i++) {
    if (limited[i] >= 0.999 || limited[i] <= -0.999) clipped++;
  }
  const resampled = dsp.resampleRate(limited, sampleRate, dsp.SR);
  const x = resampled === limited ? Float32Array.from(limited) : resampled;
  dsp.filter(x, dsp.biquad('highpass', 50, 0, 0.707));
  const peak = dsp.peakOf(x);
  if (!peak) throw httpError(422, 'ไฟล์นี้ไม่มีเสียง');
  const gain = 0.95 / peak;
  for (let i = 0; i < x.length; i++) x[i] *= gain;
  const trimmed = dsp.trimSilence(x, 30);
  if (trimmed.speechSeconds < MIN_SPEECH_SECONDS) {
    throw httpError(422, 'เสียงพูดสั้นเกินไป (พบ ' + trimmed.speechSeconds.toFixed(1) + ' วินาที ต้องมีอย่างน้อย ' + MIN_SPEECH_SECONDS + ' วินาที แนะนำ 15–60 วินาที)');
  }
  const speech = trimmed.pcm.subarray(0, MAX_SPEECH_SECONDS * dsp.SR);
  const spec = dsp.spectrogram(speech);
  const tone = new Float32Array(256);
  let segments = 0;
  for (let start = 0; start < spec.frames; start += SEGMENT_FRAMES) {
    const end = Math.min(spec.frames, start + SEGMENT_FRAMES);
    if (segments && end - start < MIN_SEGMENT_FRAMES) break;
    const part = await engine.embed(spec.data.subarray(start * dsp.BINS, end * dsp.BINS), end - start);
    for (let i = 0; i < 256; i++) tone[i] += part[i];
    segments++;
  }
  for (let i = 0; i < 256; i++) tone[i] /= segments;
  const f0 = dsp.estimateF0(speech, 30);
  const warnings = [];
  if (trimmed.speechSeconds < 10) warnings.push('เสียงพูดค่อนข้างสั้น ถ้ามี 15–60 วินาทีจะได้เสียงที่ใกล้เคียงขึ้น');
  if (f0.voiced < 0.3) warnings.push('จับเสียงพูดได้น้อย ไฟล์อาจมีดนตรีหรือเสียงรบกวนมาก ควรใช้ช่วงที่มีแต่เสียงพูดคนเดียว');
  if (clipped > limited.length * 0.002) warnings.push('เสียงต้นฉบับดังจนแตก (clipping) อาจทำให้เสียงโคลนเพี้ยน');
  return {
    tone,
    f0,
    levels: dsp.bandLevels(spec),
    seconds,
    speechSeconds: Math.min(trimmed.speechSeconds, MAX_SPEECH_SECONDS),
    warnings,
  };
}

// สังเคราะห์ประโยคทดสอบด้วยเสียงฐานนี้ แล้ววัดว่าผลลัพธ์ต่างจากต้นฉบับเท่าไร (ระดับเสียงและโทน)
async function calibrate(base, analysis, sampleText) {
  const draft = voices.decode(voices.encode({ base, pitch: 1, alpha: 0, tone: analysis.tone }));
  const converted = await engine.convertedSpeech(draft, sampleText, { speed: 1, semitones: 0 });
  // ตัวแปลงโทนเสียงปรับช่วงระดับเสียงเข้าหาต้นฉบับให้เองอยู่แล้ว (จากการวัดคลาดเคลื่อนไม่เกิน ~10%)
  // ค่าที่วัดจากประโยคเดียวแกว่งตามวรรณยุกต์ของประโยค จึงชดเชยเฉพาะเมื่อห่างกันชัดเจน และชดเชยเพียงบางส่วน
  const produced = dsp.estimateF0(converted, 20).median;
  let pitch = 1;
  if (produced > 0 && analysis.f0.median > 0) {
    const ratio = analysis.f0.median / produced;
    if (Math.abs(Math.log(ratio)) > Math.log(1.12)) pitch = dsp.clamp(Math.pow(ratio, 0.75), 0.8, 1.25);
  }
  const eq = dsp.matchGains(analysis.levels, dsp.bandLevels(dsp.spectrogram(converted)), 9);
  return { pitch, eq, tone: draft.tone };
}

async function clone(buf, hint, sampleText) {
  const started = Date.now();
  // เริ่มโหลดโมเดลที่ต้องใช้ทั้งหมดไปพร้อมกับการถอดรหัสไฟล์
  const ready = engine.warm(['refenc', 'conv', 'female', 'male']);
  ready.catch(() => undefined);
  const { pcm, sampleRate } = await decodeAudio(buf, hint);
  await engine.load('refenc');
  const analysis = await analyze(pcm, sampleRate);
  const near = analysis.f0.median > 0 && analysis.f0.median < BASE_SPLIT_HZ ? 'male' : 'female';
  const other = near === 'female' ? 'male' : 'female';
  const calNear = await calibrate(near, analysis, sampleText);
  const calOther = await calibrate(other, analysis, sampleText);
  const tone = calNear.tone;
  const candidates = [
    {
      id: 'A',
      label: 'แบบ A · ฐานเสียง' + BASE_LABEL[near],
      note: 'ใช้จังหวะการพูดของเสียงฐาน' + BASE_LABEL[near] + ' ซึ่งช่วงเสียงใกล้ต้นฉบับที่สุด',
      recommended: true,
      base: near,
      voice: voices.encode({ base: near, pitch: calNear.pitch, alpha: 0, tone }),
    },
    {
      id: 'B',
      label: 'แบบ B · ฐานเสียง' + BASE_LABEL[other],
      note: 'โทนเสียงเดียวกัน แต่ใช้จังหวะและลีลาการพูดของเสียงฐาน' + BASE_LABEL[other],
      recommended: false,
      base: other,
      voice: voices.encode({ base: other, pitch: calOther.pitch, alpha: 0, tone }),
    },
    {
      id: 'C',
      label: 'แบบ C · โทนตามไฟล์ต้นฉบับ',
      note: 'เหมือนแบบ A แต่ปรับความทุ้ม-แหลมให้ตรงกับเสียงในไฟล์ที่อัปโหลด (รวมลักษณะของไมค์และห้อง)',
      recommended: false,
      base: near,
      voice: voices.encode({ base: near, pitch: calNear.pitch, alpha: 0, tone, eq: calNear.eq }),
    },
  ];
  return {
    ok: true,
    analysis: {
      seconds: Math.round(analysis.seconds * 10) / 10,
      speechSeconds: Math.round(analysis.speechSeconds * 10) / 10,
      pitchHz: Math.round(analysis.f0.median),
      warnings: analysis.warnings,
    },
    sampleText,
    candidates,
    elapsedMs: Date.now() - started,
  };
}

module.exports = { SAMPLE_TEXT, decodeAudio, analyze, calibrate, clone };
