'use strict';

// รันอัตโนมัติตอน build บน Vercel (สคริปต์ "vercel-build")
// ดาวน์โหลดโมเดลเสียงมาตรฐานกับตัวเข้ารหัสโทนเสียง "ครั้งเดียว" แล้วฝังไปกับฟังก์ชัน
// ทำให้ตอนใช้งานจริงไม่ต้องดาวน์โหลดอีก และเปิดโมเดลได้เร็วขึ้นเพราะปรับกราฟไว้ล่วงหน้าแล้ว
// ถ้าขั้นตอนนี้ล้มเหลว build จะยังผ่าน และระบบจะดาวน์โหลดโมเดลตอนใช้งานครั้งแรกแทน

const fs = require('fs');
const path = require('path');

async function main() {
  const ort = require('onnxruntime-node');
  const engine = require('./engine.js');
  fs.mkdirSync(engine.BUNDLE_DIR, { recursive: true });
  for (const name of ['refenc', 'female']) {
    const target = path.join(engine.BUNDLE_DIR, name + '.onnx');
    if (fs.existsSync(target)) continue;
    const started = Date.now();
    const bytes = await engine.download(name);
    const tmp = target + '.' + process.pid + '.part';
    if (name === 'female') {
      // บันทึกกราฟที่ปรับแล้วระดับ extended (ไม่ผูกกับรุ่น CPU) ส่วนที่เหลือจะปรับตอนเปิดใช้งานจริง
      const session = await ort.InferenceSession.create(bytes, Object.assign({}, engine.SESSION_OPTIONS, { graphOptimizationLevel: 'extended', optimizedModelFilePath: tmp }));
      await session.release();
    } else {
      fs.writeFileSync(tmp, bytes);
    }
    fs.renameSync(tmp, target);
    console.log('[jen] ฝังโมเดล ' + name + ' แล้ว (' + (fs.statSync(target).size / 1048576).toFixed(1) + ' MB, ' + (Date.now() - started) + ' ms)');
  }
}

main()
  .catch((e) => console.warn('[jen] ข้ามการฝังโมเดลตอน build: ' + (e && e.message) + ' — ระบบจะดาวน์โหลดตอนใช้งานแทน'))
  .finally(() => process.exit(0));
