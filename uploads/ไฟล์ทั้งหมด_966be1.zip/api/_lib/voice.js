'use strict';

// รหัสเสียง (voice ID): เสียงโคลนทั้งก้อนถูกเข้ารหัสอยู่ในสตริงเดียว จึงไม่ต้องมีฐานข้อมูล
// โครงสร้างไบต์: [เวอร์ชัน][ฐาน][pitch u16][alpha][จำนวนย่าน EQ][สเกล f32][โทน 256 x int8][EQ x int8][checksum u16]

const { EQ_BANDS } = require('./dsp.js');

const PREFIX = 'jv1_';
const BASES = ['female', 'male'];
const TONE_DIM = 256;
const HEADER = 10;

const BUILTIN = {
  female: { kind: 'builtin', id: 'female', base: 'female', label: 'เสียงผู้หญิง (มาตรฐาน)' },
  male: { kind: 'builtin', id: 'male', base: 'male', label: 'เสียงผู้ชาย (มาตรฐาน)' },
};
const ALIASES = { '': 'female', default: 'female', female: 'female', male: 'male', หญิง: 'female', ชาย: 'male' };

function checksum(bytes, end) {
  let a = 1, b = 0;
  for (let i = 0; i < end; i++) {
    a = (a + bytes[i]) % 251;
    b = (b + a) % 251;
  }
  return (b << 8) | a;
}

function hashOf(bytes) {
  let h = 0x811c9dc5;
  for (let i = 0; i < bytes.length; i++) {
    h ^= bytes[i];
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(36);
}

function encode(voice) {
  const eq = voice.eq || null;
  const bytes = Buffer.alloc(HEADER + TONE_DIM + (eq ? EQ_BANDS.length : 0) + 2);
  bytes[0] = 1;
  bytes[1] = Math.max(0, BASES.indexOf(voice.base));
  bytes.writeUInt16LE(Math.round(Math.min(6, Math.max(0.1, voice.pitch || 1)) * 10000), 2);
  bytes[4] = Math.round(Math.min(2.5, Math.max(0, voice.alpha || 0)) * 100);
  bytes[5] = eq ? EQ_BANDS.length : 0;
  let scale = 0;
  for (let i = 0; i < TONE_DIM; i++) scale = Math.max(scale, Math.abs(voice.tone[i]));
  scale = scale || 1;
  bytes.writeFloatLE(scale, 6);
  for (let i = 0; i < TONE_DIM; i++) bytes.writeInt8(Math.round((voice.tone[i] / scale) * 127), HEADER + i);
  if (eq) {
    for (let b = 0; b < EQ_BANDS.length; b++) {
      bytes.writeInt8(Math.max(-127, Math.min(127, Math.round(eq[b] * 8))), HEADER + TONE_DIM + b);
    }
  }
  bytes.writeUInt16LE(checksum(bytes, bytes.length - 2), bytes.length - 2);
  return PREFIX + bytes.toString('base64url');
}

function decode(token) {
  const fail = () => {
    const err = new Error('รหัสเสียง (voice) ไม่ถูกต้องหรือไม่ครบ');
    err.status = 400;
    return err;
  };
  const text = String(token).trim();
  if (!text.startsWith(PREFIX) || !/^[A-Za-z0-9_-]+$/.test(text.slice(PREFIX.length))) throw fail();
  const bytes = Buffer.from(text.slice(PREFIX.length), 'base64url');
  if (bytes.length < HEADER + TONE_DIM + 2 || bytes[0] !== 1) throw fail();
  const bands = bytes[5];
  if ((bands !== 0 && bands !== EQ_BANDS.length) || bytes.length !== HEADER + TONE_DIM + bands + 2) throw fail();
  if (bytes.readUInt16LE(bytes.length - 2) !== checksum(bytes, bytes.length - 2)) throw fail();
  const base = BASES[bytes[1]];
  const scale = bytes.readFloatLE(6);
  if (!base || !Number.isFinite(scale) || scale <= 0 || scale > 100) throw fail();
  const tone = new Float32Array(TONE_DIM);
  for (let i = 0; i < TONE_DIM; i++) tone[i] = (bytes.readInt8(HEADER + i) / 127) * scale;
  let eq = null;
  if (bands) {
    eq = new Float32Array(bands);
    for (let b = 0; b < bands; b++) eq[b] = bytes.readInt8(HEADER + TONE_DIM + b) / 8;
  }
  return {
    kind: 'clone',
    base,
    pitch: Math.min(1.6, Math.max(0.625, bytes.readUInt16LE(2) / 10000)),
    alpha: bytes[4] / 100,
    tone,
    eq,
    hash: hashOf(bytes.subarray(HEADER, HEADER + TONE_DIM)),
  };
}

// แปลงค่าพารามิเตอร์ voice ของ API ให้เป็นเสียงที่พร้อมใช้
function resolve(value) {
  const text = value === undefined || value === null ? '' : String(value).trim();
  const alias = ALIASES[text.toLowerCase()];
  if (alias) return BUILTIN[alias];
  if (text.startsWith(PREFIX)) return decode(text);
  const err = new Error('ไม่รู้จักเสียง "' + text.slice(0, 40) + '" (ใช้ female, male หรือรหัสเสียงที่ขึ้นต้นด้วย ' + PREFIX + ')');
  err.status = 400;
  throw err;
}

module.exports = { PREFIX, BASES, BUILTIN, encode, decode, resolve };
