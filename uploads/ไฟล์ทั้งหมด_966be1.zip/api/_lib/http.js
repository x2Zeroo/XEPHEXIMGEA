'use strict';

// ตัวช่วย HTTP ที่ใช้ร่วมกันทุก endpoint: CORS, อ่าน body, ตอบ JSON

const MAX_BODY_BYTES = 4.6 * 1024 * 1024;

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

// API เรียกได้จากทุกโดเมน (ยืนยันตัวด้วย API key ไม่ใช้คุกกี้ จึงเปิด * ได้อย่างปลอดภัย)
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
  res.setHeader('Access-Control-Expose-Headers', 'X-Jen-Duration, X-Jen-Elapsed-Ms, X-Jen-Chunks, X-Jen-Cold');
  res.setHeader('Access-Control-Max-Age', '86400');
}

function sendJson(res, status, payload) {
  if (res.headersSent) return res.end();
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.end(JSON.stringify(payload));
}

function sendError(res, err) {
  const status = err && err.status >= 400 && err.status < 600 ? err.status : 500;
  if (status >= 500) console.error('[jen]', err);
  sendJson(res, status, { ok: false, error: status === 500 ? 'เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์ ลองใหม่อีกครั้ง' : err.message });
}

function query(req) {
  const url = new URL(req.url || '/', 'http://localhost');
  const out = {};
  for (const [key, value] of url.searchParams) out[key] = value;
  return { path: url.pathname, query: out };
}

function readStream(req) {
  return new Promise((resolve, reject) => {
    const parts = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(httpError(413, 'ข้อมูลใหญ่เกินไป (สูงสุดประมาณ 4.5 MB ต่อคำขอ)'));
        req.destroy();
        return;
      }
      parts.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}

// คืน { json } สำหรับ JSON หรือ { buffer } สำหรับข้อมูลไบนารี
// บน Vercel ตัว runtime อ่าน body ไว้ให้แล้วใน req.body (Buffer เมื่อเป็น application/octet-stream)
async function readBody(req) {
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  let parsed;
  try {
    parsed = req.body;
  } catch (e) {
    throw httpError(400, 'รูปแบบข้อมูลไม่ถูกต้อง (JSON ไม่สมบูรณ์)');
  }
  let buffer = null;
  if (Buffer.isBuffer(parsed)) buffer = parsed;
  else if (typeof parsed === 'string') buffer = Buffer.from(parsed, 'utf8');
  else if (parsed && typeof parsed === 'object') return { json: parsed };
  else if (!req.readableEnded) buffer = await readStream(req);
  if (!buffer || !buffer.length) {
    if (type && type !== 'application/json' && type !== 'application/octet-stream') {
      throw httpError(415, 'ส่งไฟล์ด้วย Content-Type: application/octet-stream หรือส่ง JSON');
    }
    return { json: {} };
  }
  if (buffer.length > MAX_BODY_BYTES) throw httpError(413, 'ข้อมูลใหญ่เกินไป (สูงสุดประมาณ 4.5 MB ต่อคำขอ)');
  if (type === 'application/json' || (type !== 'application/octet-stream' && buffer[0] === 0x7b)) {
    try {
      return { json: JSON.parse(buffer.toString('utf8')) };
    } catch (e) {
      throw httpError(400, 'รูปแบบข้อมูลไม่ถูกต้อง (JSON ไม่สมบูรณ์)');
    }
  }
  return { buffer };
}

module.exports = { MAX_BODY_BYTES, httpError, cors, sendJson, sendError, query, readBody };
