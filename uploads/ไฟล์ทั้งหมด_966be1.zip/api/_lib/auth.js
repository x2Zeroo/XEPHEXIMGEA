'use strict';

// ระบบ API key แบบไม่ต้องมีฐานข้อมูล
// - ADMIN_KEY (ตั้งใน Environment Variables ของ Vercel) คือกุญแจหลัก ใช้เรียก API ได้และใช้ออกกุญแจย่อย
// - กุญแจย่อย (jsk_...) เซ็นด้วย HMAC จาก ADMIN_KEY ตรวจสอบได้โดยไม่ต้องเก็บไว้ที่ใด
// - ยกเลิกกุญแจย่อยรายตัวด้วย REVOKED_KEYS (รหัสกุญแจคั่นด้วยจุลภาค) หรือเปลี่ยน ADMIN_KEY เพื่อยกเลิกทั้งหมด

const crypto = require('crypto');
const { httpError } = require('./http.js');

const KEY_PREFIX = 'jsk_';
const MIN_ADMIN_LENGTH = 16;
const MAX_DAYS = 3650;

function adminKey() {
  return String(process.env.ADMIN_KEY || '').trim();
}

// open = ยังไม่ตั้ง ADMIN_KEY (ใครก็เรียกได้), key = ต้องใช้กุญแจ, weak = ตั้งไว้สั้นเกินไป
function mode() {
  const key = adminKey();
  if (!key) return 'open';
  return key.length < MIN_ADMIN_LENGTH ? 'weak' : 'key';
}

function digest(value) {
  return crypto.createHash('sha256').update(String(value)).digest();
}

function sameSecret(a, b) {
  return crypto.timingSafeEqual(digest(a), digest(b));
}

// ยืดกุญแจหลักด้วย scrypt ก่อนใช้เซ็น เพื่อให้การเดา ADMIN_KEY จากกุญแจย่อยที่หลุดออกไปทำได้ยากมาก
let signingKey = null;
let signingFor = null;
function getSigningKey() {
  const key = adminKey();
  if (signingFor !== key) {
    signingKey = crypto.scryptSync(key, 'jen-siang/api-key/v1', 32, { N: 16384, r: 8, p: 1 });
    signingFor = key;
  }
  return signingKey;
}

function sign(payload) {
  return crypto.createHmac('sha256', getSigningKey()).update(payload).digest().subarray(0, 18).toString('base64url');
}

function revoked() {
  return String(process.env.REVOKED_KEYS || '')
    .split(/[\s,]+/)
    .filter(Boolean);
}

function presented(req, queryParams) {
  const header = String(req.headers.authorization || '');
  const bearer = /^Bearer\s+(.+)$/i.exec(header);
  if (bearer) return bearer[1].trim();
  if (req.headers['x-api-key']) return String(req.headers['x-api-key']).trim();
  const q = queryParams || {};
  return String(q.key || q.api_key || '').trim();
}

function requireConfigured() {
  if (mode() === 'weak') {
    throw httpError(500, 'ADMIN_KEY สั้นเกินไป ต้องยาวอย่างน้อย ' + MIN_ADMIN_LENGTH + ' ตัวอักษร แก้ใน Environment Variables แล้ว Redeploy');
  }
}

// ตรวจกุญแจของคำขอ คืน { role: 'open' | 'admin' | 'key', name, id, expiresAt }
function authenticate(req, queryParams) {
  requireConfigured();
  if (mode() === 'open') return { role: 'open', name: null, id: null, expiresAt: null };
  const key = presented(req, queryParams);
  if (!key) throw httpError(401, 'ต้องใช้ API key (ส่งในเฮดเดอร์ Authorization: Bearer <key>)');
  if (sameSecret(key, adminKey())) return { role: 'admin', name: 'admin', id: null, expiresAt: null };
  const match = /^jsk_([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(key);
  if (!match || !sameSecret(match[2], sign(match[1]))) throw httpError(401, 'API key ไม่ถูกต้อง');
  let info;
  try {
    info = JSON.parse(Buffer.from(match[1], 'base64url').toString('utf8'));
  } catch (e) {
    throw httpError(401, 'API key ไม่ถูกต้อง');
  }
  if (info.e && info.e * 1000 < Date.now()) throw httpError(401, 'API key หมดอายุแล้ว');
  if (revoked().includes(info.i)) throw httpError(401, 'API key นี้ถูกยกเลิกแล้ว');
  return { role: 'key', name: info.n || '', id: info.i, expiresAt: info.e ? new Date(info.e * 1000).toISOString() : null };
}

function requireAdmin(req, queryParams) {
  requireConfigured();
  if (mode() === 'open') {
    throw httpError(409, 'ยังไม่ได้ตั้งค่า ADMIN_KEY จึงยังออก API key ไม่ได้ ตั้งค่าใน Environment Variables ของ Vercel แล้ว Redeploy');
  }
  const who = authenticate(req, queryParams);
  if (who.role !== 'admin') throw httpError(403, 'ต้องใช้กุญแจหลัก (ADMIN_KEY) ในการออก API key');
  return who;
}

function mint(input) {
  const name = String((input && input.name) || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 40);
  if (!name) throw httpError(400, 'กรุณาตั้งชื่อ API key');
  const days = Math.round(Number(input.days) || 0);
  if (days < 0 || days > MAX_DAYS) throw httpError(400, 'อายุของ key ต้องอยู่ระหว่าง 0 (ไม่หมดอายุ) ถึง ' + MAX_DAYS + ' วัน');
  const id = crypto.randomBytes(5).toString('hex');
  const expires = days ? Math.floor(Date.now() / 1000) + days * 86400 : 0;
  const payload = Buffer.from(JSON.stringify({ i: id, n: name, e: expires }), 'utf8').toString('base64url');
  return {
    key: KEY_PREFIX + payload + '.' + sign(payload),
    id,
    name,
    expiresAt: expires ? new Date(expires * 1000).toISOString() : null,
  };
}

module.exports = { MIN_ADMIN_LENGTH, mode, authenticate, requireAdmin, mint };
