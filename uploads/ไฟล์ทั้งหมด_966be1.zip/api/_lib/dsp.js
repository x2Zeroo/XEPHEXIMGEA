'use strict';

// เจนเสียง — ประมวลผลสัญญาณเสียงฝั่งเซิร์ฟเวอร์ (ไม่มี dependency)
// ส่วนแรกย้ายมาจาก JenDSP ในหน้าเว็บเดิม ส่วนหลังเพิ่มสำหรับการโคลนเสียง

const SR = 22050;
const VOCAB = "\u0e32\u0e19\u0e48\u0e23\u0e40\u0e49\u0e2d\u0e07\u0e01\u0e27\u0e30\u0e31\u0e21\u0e17\u0e1e\u0e22\u0e25\u0e08\u0e35\u0e04\u0e15\u0e14\u0e2b\u0e02\u0e34\u0e41\u0e2a\u0e1a\u0e1b\u0e44\u0e39\u0e43\u0e47\u0e37\u0e4c\u0e0a\u0e38\u0e36\u0e4d\u0e42\u0e1c\u0e16\u0e0d\u0e0b\u0e18\u0e28\u0e13\u0e29\u0e1f\u0e20\u0e09\u0e1d\u0e10\u0e24\u0e0f\u0e2e\u0e06\u0e4b\u0e0e'0\u0e4a\u0e11142-\u0e2c\u0e12\u0e0c ";
const BLANK = 0;

// ค่าที่วัดจากคลิปต้นแบบเทียบกับเสียงดิบของโมเดล (เสียงมาตรฐานหญิง)
const PROFILE = {
  pitchRatio: 1.035,
  articulation: 1.05,
  maxPause: 0.24,
  noiseScale: 0.667,
  noiseW: 0.8,
  brightnessHz: 1700,
  // [ชนิด, ความถี่ Hz, เกน dB, Q]
  eq: [
    ['highpass', 85, 0, 0.707],
    ['lowshelf', 300, -5],
    ['peaking', 800, 1.5, 1.1],
    ['highshelf', 1500, 8.5],
    ['peaking', 1900, 2, 1.2],
    ['highshelf', 5000, -4],
  ],
};

function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

function options(ui) {
  const match = !!ui.match;
  const speed = clamp(Number(ui.speed) || 1, 0.5, 2);
  const pitchRatio = (match ? PROFILE.pitchRatio : 1) * Math.pow(2, (Number(ui.semitones) || 0) / 12);
  const articulation = match ? PROFILE.articulation : 1;
  const bright = Number(ui.brightness) || 0;
  const eq = match ? PROFILE.eq.slice() : [];
  if (bright) eq.push(['highshelf', PROFILE.brightnessHz, bright]);
  return {
    pitchRatio,
    speed,
    lengthScale: clamp(pitchRatio / (articulation * speed), 0.55, 1.7),
    maxPause: (match ? PROFILE.maxPause : 0.6) / speed,
    noiseScale: PROFILE.noiseScale,
    noiseW: PROFILE.noiseW,
    eq,
    dynamics: match,
  };
}

function tokenize(text) {
  const ids = [BLANK];
  const src = String(text).replace(/\u0e33/g, '\u0e4d\u0e32');
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (ch === "'" || ch === '-' || (ch >= '0' && ch <= '9')) continue;
    const id = VOCAB.indexOf(ch);
    if (id < 0) continue;
    ids.push(id, BLANK);
  }
  return ids;
}

function biquad(type, hz, db, q) {
  const A = Math.pow(10, db / 40);
  const w = (2 * Math.PI * hz) / SR;
  const cs = Math.cos(w);
  const sn = Math.sin(w);
  let b0, b1, b2, a0, a1, a2, al, k;
  if (type === 'highpass') {
    al = sn / (2 * q);
    b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = (1 + cs) / 2; a0 = 1 + al; a1 = -2 * cs; a2 = 1 - al;
  } else if (type === 'peaking') {
    al = sn / (2 * q);
    b0 = 1 + al * A; b1 = -2 * cs; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * cs; a2 = 1 - al / A;
  } else {
    al = (sn / 2) * Math.SQRT2;
    k = 2 * Math.sqrt(A) * al;
    if (type === 'lowshelf') {
      b0 = A * ((A + 1) - (A - 1) * cs + k); b1 = 2 * A * ((A - 1) - (A + 1) * cs); b2 = A * ((A + 1) - (A - 1) * cs - k);
      a0 = (A + 1) + (A - 1) * cs + k; a1 = -2 * ((A - 1) + (A + 1) * cs); a2 = (A + 1) + (A - 1) * cs - k;
    } else {
      b0 = A * ((A + 1) + (A - 1) * cs + k); b1 = -2 * A * ((A - 1) + (A + 1) * cs); b2 = A * ((A + 1) + (A - 1) * cs - k);
      a0 = (A + 1) - (A - 1) * cs + k; a1 = 2 * ((A - 1) - (A + 1) * cs); a2 = (A + 1) - (A - 1) * cs - k;
    }
  }
  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];
}

function filter(x, c) {
  let z1 = 0, z2 = 0;
  const b0 = c[0], b1 = c[1], b2 = c[2], a1 = c[3], a2 = c[4];
  for (let i = 0; i < x.length; i++) {
    const v = x[i];
    const y = b0 * v + z1;
    z1 = b1 * v - a1 * y + z2;
    z2 = b2 * v - a2 * y;
    x[i] = y;
  }
}

function applyEq(x, eq) {
  for (let i = 0; i < eq.length; i++) {
    const f = eq[i];
    filter(x, biquad(f[0], f[1], f[2], f[3] || 0.707));
  }
}

function peakOf(x) {
  let p = 0;
  for (let i = 0; i < x.length; i++) {
    const a = x[i] < 0 ? -x[i] : x[i];
    if (a > p) p = a;
  }
  return p;
}

function trim(x, threshold) {
  let a = 0, b = x.length - 1;
  const pad = Math.round(0.012 * SR);
  while (a < b && Math.abs(x[a]) < threshold) a++;
  while (b > a && Math.abs(x[b]) < threshold) b--;
  return x.subarray(Math.max(0, a - pad), Math.min(x.length, b + pad + 1));
}

// ย่อช่วงเงียบที่ยาวเกิน maxLen ให้เหลือ maxLen
function capPauses(x, maxLen, threshold) {
  const frame = Math.round(0.01 * SR);
  const n = Math.floor(x.length / frame);
  const cuts = [];
  let runStart = -1;
  for (let f = 0; f <= n; f++) {
    let silent = false;
    if (f < n) {
      silent = true;
      for (let i = f * frame, e = i + frame; i < e; i++) {
        if (x[i] > threshold || x[i] < -threshold) { silent = false; break; }
      }
    }
    if (silent) { if (runStart < 0) runStart = f; continue; }
    if (runStart >= 0) {
      const len = (f - runStart) * frame;
      if (len > maxLen) {
        const keep = maxLen >> 1;
        cuts.push([runStart * frame + keep, f * frame - (maxLen - keep)]);
      }
      runStart = -1;
    }
  }
  let removed = 0;
  for (let c = 0; c < cuts.length; c++) removed += cuts[c][1] - cuts[c][0];
  const out = new Float32Array(x.length - removed);
  let pos = 0, from = 0;
  for (let c = 0; c < cuts.length; c++) {
    out.set(x.subarray(from, cuts[c][0]), pos);
    pos += cuts[c][0] - from;
    from = cuts[c][1];
  }
  out.set(x.subarray(from), pos);
  return out;
}

function fadeEdges(x) {
  const n = Math.min(Math.round(0.006 * SR), x.length >> 1);
  for (let i = 0; i < n; i++) {
    const g = i / n;
    x[i] *= g;
    x[x.length - 1 - i] *= g;
  }
}

// Resample แบบ windowed-sinc: อ่านอินพุตด้วยก้าว ratio (ratio > 1 = สั้นลง/เสียงสูงขึ้น)
// ใช้ตารางเคอร์เนลแทนการคำนวณ sin/cos ทุกแท็ป จึงเร็วกว่าเวอร์ชันในเบราว์เซอร์เดิมหลายเท่า
const KERNEL_HALF = 12;
const KERNEL_RES = 256;
const kernelCache = new Map();

function kernelTable(fc) {
  const key = Math.round(fc * 4096);
  let table = kernelCache.get(key);
  if (table) return table;
  const size = 2 * KERNEL_HALF * KERNEL_RES + 2;
  table = new Float32Array(size);
  for (let i = 0; i < size; i++) {
    const u = i / KERNEL_RES - KERNEL_HALF;
    if (u <= -KERNEL_HALF || u >= KERNEL_HALF) continue;
    const a = Math.PI * u * fc;
    const s = a === 0 ? 1 : Math.sin(a) / a;
    table[i] = s * (0.5 + 0.5 * Math.cos((Math.PI * u) / KERNEL_HALF)) * fc;
  }
  if (kernelCache.size > 64) kernelCache.clear();
  kernelCache.set(key, table);
  return table;
}

function resample(x, ratio) {
  if (Math.abs(ratio - 1) < 1e-4) return x;
  const fc = Math.min(1, 1 / ratio) * 0.97;
  const table = kernelTable(fc);
  const len = x.length;
  const n = Math.floor(len / ratio);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i * ratio;
    const k0 = Math.floor(t);
    const frac = t - k0;
    let jLo = -KERNEL_HALF + 1, jHi = KERNEL_HALF;
    if (k0 + jLo < 0) jLo = -k0;
    if (k0 + jHi >= len) jHi = len - 1 - k0;
    let acc = 0;
    let pos = (jLo - frac + KERNEL_HALF) * KERNEL_RES;
    for (let j = jLo; j <= jHi; j++, pos += KERNEL_RES) {
      const p0 = pos | 0;
      const w = table[p0] + (table[p0 + 1] - table[p0]) * (pos - p0);
      acc += x[k0 + j] * w;
    }
    out[i] = acc;
  }
  return out;
}

function resampleRate(x, fromRate, toRate) {
  return fromRate === toRate ? x : resample(x, fromRate / toRate);
}

function compress(x) {
  const thr = -22, ratio = 2.6, knee = 8;
  const att = Math.exp(-1 / (0.004 * SR));
  const rel = Math.exp(-1 / (0.09 * SR));
  const slope = 1 - 1 / ratio;
  let env = 0;
  for (let i = 0; i < x.length; i++) {
    const a = x[i] < 0 ? -x[i] : x[i];
    env = a > env ? att * env + (1 - att) * a : rel * env + (1 - rel) * a;
    if (env < 0.03162) continue; // ต่ำกว่า thr - knee/2 (-30 dB) ไม่ต้องกดเสียง
    const over = 20 * Math.log10(env) - thr;
    let gr = 0;
    if (over > knee / 2) gr = over * slope;
    else if (over > -knee / 2) { const t = over + knee / 2; gr = (slope * t * t) / (2 * knee); }
    if (gr > 0) x[i] *= Math.pow(10, -gr / 20);
  }
}

function normalize(x, targetDb) {
  const frame = Math.round(0.02 * SR);
  const gate = peakOf(x) * 0.05;
  let sum = 0, count = 0;
  for (let s = 0; s + frame <= x.length; s += frame) {
    let e = 0;
    for (let i = s; i < s + frame; i++) e += x[i] * x[i];
    e = Math.sqrt(e / frame);
    if (e > gate) { sum += e * e; count++; }
  }
  if (!count) return;
  const rms = Math.sqrt(sum / count);
  const gain = Math.min(Math.pow(10, targetDb / 20) / rms, 8);
  const knee = 0.82;
  for (let k = 0; k < x.length; k++) {
    let v = x[k] * gain;
    let a = v < 0 ? -v : v;
    if (a > knee) {
      a = knee + (0.97 - knee) * Math.tanh((a - knee) / (0.97 - knee));
      v = v < 0 ? -a : a;
    }
    x[k] = v;
  }
}

// ตัดหัวท้าย ย่อช่วงเงียบ และเฟดขอบของเสียงดิบจากโมเดลหนึ่งช่วง
function tidy(raw, maxPauseSeconds) {
  const level = peakOf(raw);
  if (!level) return new Float32Array(0);
  const x = capPauses(trim(raw, level * 0.02), Math.round(maxPauseSeconds * SR), level * 0.02);
  fadeEdges(x);
  return x;
}

// ---------- WAV ----------

function encodeWav(x, sampleRate) {
  const buf = Buffer.allocUnsafe(44 + x.length * 2);
  writeWavHeader(buf, x.length * 2, sampleRate);
  writePcm16(buf, 44, x);
  return buf;
}

function writeWavHeader(buf, dataBytes, sampleRate) {
  buf.write('RIFF', 0, 'ascii');
  buf.writeUInt32LE(Math.min(0xffffffff, 36 + dataBytes), 4);
  buf.write('WAVEfmt ', 8, 'ascii');
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(sampleRate, 24);
  buf.writeUInt32LE(sampleRate * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write('data', 36, 'ascii');
  buf.writeUInt32LE(Math.min(0xffffffff, dataBytes), 40);
  return buf;
}

function writePcm16(buf, offset, x) {
  for (let i = 0, o = offset; i < x.length; i++, o += 2) {
    const s = x[i] < -1 ? -1 : x[i] > 1 ? 1 : x[i];
    buf.writeInt16LE(Math.round(s * 32767), o);
  }
  return buf;
}

function pcm16Buffer(x) {
  return writePcm16(Buffer.allocUnsafe(x.length * 2), 0, x);
}

function isWav(buf) {
  return buf.length > 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WAVE';
}

// อ่าน WAV (PCM 8/16/24/32 บิต หรือ float 32/64 บิต) แล้วรวมเป็นโมโน
function decodeWav(buf) {
  if (!isWav(buf)) throw new Error('ไม่ใช่ไฟล์ WAV');
  let pos = 12, fmt = null, dataStart = -1, dataLen = 0;
  while (pos + 8 <= buf.length) {
    const id = buf.toString('ascii', pos, pos + 4);
    const size = buf.readUInt32LE(pos + 4);
    const body = pos + 8;
    if (id === 'fmt ' && body + 16 <= buf.length) {
      fmt = {
        format: buf.readUInt16LE(body),
        channels: buf.readUInt16LE(body + 2),
        sampleRate: buf.readUInt32LE(body + 4),
        bits: buf.readUInt16LE(body + 14),
      };
      if (fmt.format === 0xfffe && size >= 26) fmt.format = buf.readUInt16LE(body + 24);
    } else if (id === 'data') {
      dataStart = body;
      dataLen = Math.min(size, buf.length - body);
      break;
    }
    pos = body + size + (size & 1);
  }
  if (!fmt || dataStart < 0) throw new Error('ไฟล์ WAV ไม่สมบูรณ์');
  const { format, channels, bits, sampleRate } = fmt;
  const bytes = bits >> 3;
  if (!channels || !bytes || !sampleRate || (format !== 1 && format !== 3)) throw new Error('ไม่รองรับ WAV รูปแบบนี้ (ต้องเป็น PCM หรือ float)');
  const frames = Math.floor(dataLen / (bytes * channels));
  const out = new Float32Array(frames);
  let o = dataStart;
  for (let i = 0; i < frames; i++) {
    let acc = 0;
    for (let c = 0; c < channels; c++, o += bytes) {
      if (format === 3) acc += bytes === 8 ? buf.readDoubleLE(o) : buf.readFloatLE(o);
      else if (bytes === 2) acc += buf.readInt16LE(o) / 32768;
      else if (bytes === 3) acc += buf.readIntLE(o, 3) / 8388608;
      else if (bytes === 4) acc += buf.readInt32LE(o) / 2147483648;
      else acc += (buf.readUInt8(o) - 128) / 128;
    }
    out[i] = acc / channels;
  }
  return { pcm: out, sampleRate };
}

// ---------- สเปกโตรแกรมสำหรับตัวแปลงโทนเสียง (OpenVoice: n_fft 1024, hop 256, Hann) ----------

const N_FFT = 1024;
const HOP = 256;
const BINS = N_FFT / 2 + 1;
const PAD = (N_FFT - HOP) / 2;
const HANN = new Float32Array(N_FFT);
const COS = new Float64Array(N_FFT / 2);
const SIN = new Float64Array(N_FFT / 2);
const REV = new Uint16Array(N_FFT);
for (let i = 0; i < N_FFT; i++) HANN[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / N_FFT);
for (let i = 0; i < N_FFT / 2; i++) {
  COS[i] = Math.cos((2 * Math.PI * i) / N_FFT);
  SIN[i] = Math.sin((2 * Math.PI * i) / N_FFT);
}
for (let i = 0; i < N_FFT; i++) {
  let r = 0;
  for (let b = 0; b < 10; b++) r |= ((i >> b) & 1) << (9 - b);
  REV[i] = r;
}

// FFT เชิงซ้อน radix-2 ขนาด 1024 แบบแทนที่ (อินพุตต้องเรียงแบบ bit-reversed มาแล้ว)
function fft1024(re, im) {
  for (let size = 2; size <= N_FFT; size <<= 1) {
    const half = size >> 1;
    const step = N_FFT / size;
    for (let start = 0; start < N_FFT; start += size) {
      for (let k = 0, t = 0; k < half; k++, t += step) {
        const wr = COS[t], wi = -SIN[t];
        const a = start + k, b = a + half;
        const xr = re[b] * wr - im[b] * wi;
        const xi = re[b] * wi + im[b] * wr;
        re[b] = re[a] - xr; im[b] = im[a] - xi;
        re[a] += xr; im[a] += xi;
      }
    }
  }
}

function frameCount(samples) {
  return 1 + Math.floor((samples + 2 * PAD - N_FFT) / HOP);
}

// คืนค่าขนาดสเปกตรัมเรียงแบบ [เฟรม][บิน] (T x 513)
function spectrogram(y) {
  let x = y;
  if (x.length < PAD + 2) {
    x = new Float32Array(PAD + 2);
    x.set(y);
  }
  const n = x.length;
  const frames = frameCount(n);
  const data = new Float32Array(frames * BINS);
  const re = new Float64Array(N_FFT);
  const im = new Float64Array(N_FFT);
  for (let f = 0; f < frames; f++) {
    const base = f * HOP - PAD;
    for (let i = 0; i < N_FFT; i++) {
      let idx = base + i;
      if (idx < 0) idx = -idx;
      else if (idx >= n) idx = 2 * (n - 1) - idx;
      const r = REV[i];
      re[r] = x[idx] * HANN[i];
      im[r] = 0;
    }
    fft1024(re, im);
    const row = f * BINS;
    for (let k = 0; k < BINS; k++) data[row + k] = Math.sqrt(re[k] * re[k] + im[k] * im[k] + 1e-6);
  }
  return { frames, data };
}

// [เฟรม][บิน] -> [บิน][เฟรม] ตามที่ตัวแปลงโทนเสียงต้องการ
function transposeSpec(spec) {
  const { frames, data } = spec;
  const out = new Float32Array(data.length);
  for (let f = 0; f < frames; f++) {
    const row = f * BINS;
    for (let k = 0; k < BINS; k++) out[k * frames + f] = data[row + k];
  }
  return out;
}

// ---------- วิเคราะห์เสียงต้นฉบับ ----------

// ตัดช่วงเงียบออก โดยเทียบกับระดับเสียงพูดปกติของไฟล์ (เปอร์เซ็นไทล์ที่ 95 ของความดังรายเฟรม)
// ใช้เปอร์เซ็นไทล์แทนค่าสูงสุด เพื่อไม่ให้เสียงกระแทกดัง ๆ เพียงครั้งเดียวทำให้เสียงพูดถูกตัดทิ้ง
function trimSilence(y, belowDb) {
  const frame = 1024, hop = 256;
  const count = Math.max(1, 1 + Math.floor((y.length - frame) / hop));
  const rms = new Float32Array(count);
  for (let f = 0; f < count; f++) {
    let e = 0;
    const s = f * hop;
    const end = Math.min(y.length, s + frame);
    for (let i = s; i < end; i++) e += y[i] * y[i];
    rms[f] = Math.sqrt(e / frame);
  }
  const reference = Float32Array.from(rms).sort()[Math.floor((count - 1) * 0.95)];
  if (!reference) return { pcm: new Float32Array(0), speechSeconds: 0 };
  const floor = reference * Math.pow(10, -(belowDb || 30) / 20);
  const keep = new Uint8Array(y.length);
  for (let f = 0; f < count; f++) {
    if (rms[f] <= floor) continue;
    const s = f * hop;
    const end = Math.min(y.length, s + frame);
    for (let i = s; i < end; i++) keep[i] = 1;
  }
  let total = 0;
  for (let i = 0; i < y.length; i++) total += keep[i];
  const out = new Float32Array(total);
  for (let i = 0, o = 0; i < y.length; i++) if (keep[i]) out[o++] = y[i];
  return { pcm: out, speechSeconds: total / SR };
}

// ประมาณความถี่มูลฐาน (F0) ด้วย YIN บนสัญญาณที่ลดอัตราสุ่มเหลือ 11025 Hz
function estimateF0(y, maxSeconds) {
  const limit = Math.min(y.length, Math.round((maxSeconds || 30) * SR));
  const x = resample(y.subarray(0, limit), 2);
  const sr = SR / 2;
  const W = 512, hop = 220;
  const tauMin = Math.floor(sr / 450), tauMax = Math.ceil(sr / 62);
  const frames = Math.floor((x.length - W - tauMax) / hop);
  if (frames < 4) return { median: 0, p10: 0, p90: 0, voiced: 0 };
  const energy = new Float32Array(frames);
  for (let f = 0; f < frames; f++) {
    let e = 0;
    for (let i = f * hop, end = i + W; i < end; i++) e += x[i] * x[i];
    energy[f] = e;
  }
  const gate = Float32Array.from(energy).sort()[Math.floor((frames - 1) * 0.9)] * 0.01;
  const d = new Float32Array(tauMax + 2);
  const values = [];
  let loud = 0;
  for (let f = 0; f < frames; f++) {
    if (energy[f] <= gate) continue;
    loud++;
    const s = f * hop;
    let running = 0, best = -1;
    d[0] = 1;
    for (let tau = 1; tau <= tauMax + 1; tau++) {
      let acc = 0;
      for (let i = s, end = s + W; i < end; i++) {
        const v = x[i] - x[i + tau];
        acc += v * v;
      }
      running += acc;
      d[tau] = running ? (acc * tau) / running : 1;
    }
    for (let tau = tauMin; tau <= tauMax; tau++) {
      if (d[tau] < 0.15) {
        while (tau + 1 <= tauMax && d[tau + 1] < d[tau]) tau++;
        best = tau;
        break;
      }
    }
    if (best < 0) {
      // ไม่มีจุดที่ชัดพอ: ยอมรับจุดต่ำสุดถ้ายังมีความเป็นคาบอยู่บ้าง (เสียงต่ำท้ายประโยคมักเป็นแบบนี้)
      let lowest = tauMin;
      for (let tau = tauMin; tau <= tauMax; tau++) if (d[tau] < d[lowest]) lowest = tau;
      if (d[lowest] >= 0.45) continue;
      best = lowest;
    }
    const a = d[best - 1], b = d[best], c = d[best + 1];
    const denom = a - 2 * b + c;
    const shift = denom ? clamp((0.5 * (a - c)) / denom, -1, 1) : 0;
    values.push(sr / (best + shift));
  }
  const voiced = values.length / Math.max(1, loud);
  if (values.length < 4) return { median: 0, p10: 0, p90: 0, voiced };
  values.sort((p, q) => p - q);
  const at = (q) => values[Math.min(values.length - 1, Math.floor(q * values.length))];
  return { median: at(0.5), p10: at(0.1), p90: at(0.9), voiced };
}

// ---------- จับคู่โทน (สเปกตรัมเฉลี่ยระยะยาว) ----------

const EQ_BANDS = [100, 141, 200, 283, 400, 566, 800, 1131, 1600, 2263, 3200, 4525, 6400, 9051];

// พลังงานเฉลี่ยของแต่ละย่านความถี่ (dB) จากสเปกโตรแกรม เฉพาะเฟรมที่มีเสียง
function bandLevels(spec) {
  const { frames, data } = spec;
  const power = new Float64Array(BINS);
  const energy = new Float64Array(frames);
  let maxEnergy = 0;
  for (let f = 0; f < frames; f++) {
    let e = 0;
    const row = f * BINS;
    for (let k = 2; k < BINS; k++) e += data[row + k] * data[row + k];
    energy[f] = e;
    if (e > maxEnergy) maxEnergy = e;
  }
  let used = 0;
  for (let f = 0; f < frames; f++) {
    if (energy[f] < maxEnergy * 0.003) continue;
    const row = f * BINS;
    for (let k = 0; k < BINS; k++) power[k] += data[row + k] * data[row + k];
    used++;
  }
  const hz = SR / N_FFT;
  const out = new Float32Array(EQ_BANDS.length);
  for (let b = 0; b < EQ_BANDS.length; b++) {
    const lo = Math.max(1, Math.round(EQ_BANDS[b] / Math.pow(2, 0.25) / hz));
    const hi = Math.min(BINS - 1, Math.max(lo, Math.round((EQ_BANDS[b] * Math.pow(2, 0.25)) / hz)));
    let acc = 0;
    for (let k = lo; k <= hi; k++) acc += power[k];
    out[b] = 10 * Math.log10(acc / (hi - lo + 1) / Math.max(1, used) + 1e-12);
  }
  return out;
}

// เกนต่อย่าน (dB) ที่ทำให้โทนของ output เข้าใกล้ reference โดยไม่เปลี่ยนความดังรวม
function matchGains(referenceLevels, outputLevels, maxDb) {
  const limit = maxDb || 9;
  const gains = new Float32Array(EQ_BANDS.length);
  let mean = 0, count = 0;
  for (let b = 0; b < EQ_BANDS.length; b++) {
    gains[b] = referenceLevels[b] - outputLevels[b];
    if (EQ_BANDS[b] >= 200 && EQ_BANDS[b] <= 4600) { mean += gains[b]; count++; }
  }
  mean /= count || 1;
  for (let b = 0; b < EQ_BANDS.length; b++) gains[b] = clamp(gains[b] - mean, -limit, limit);
  return gains;
}

// สร้าง FIR เฟสเชิงเส้นจากเกนต่อย่าน แล้วกรองสัญญาณ
function applyBandGains(x, gains) {
  let flat = true;
  for (let b = 0; b < gains.length; b++) if (Math.abs(gains[b]) > 0.2) flat = false;
  if (flat) return x;
  const taps = 255, mid = (taps - 1) / 2, grid = 256;
  const curve = new Float64Array(grid + 1);
  for (let k = 0; k <= grid; k++) {
    const hz = (k / grid) * (SR / 2);
    let db;
    if (hz <= EQ_BANDS[0]) db = gains[0] * clamp(hz / EQ_BANDS[0], 0, 1);
    else if (hz >= EQ_BANDS[EQ_BANDS.length - 1]) db = gains[gains.length - 1];
    else {
      let b = 0;
      while (EQ_BANDS[b + 1] < hz) b++;
      const t = Math.log(hz / EQ_BANDS[b]) / Math.log(EQ_BANDS[b + 1] / EQ_BANDS[b]);
      db = gains[b] + (gains[b + 1] - gains[b]) * t;
    }
    curve[k] = Math.pow(10, db / 20);
  }
  const h = new Float32Array(taps);
  for (let n = 0; n <= mid; n++) {
    let acc = curve[0] + (n % 2 ? -1 : 1) * curve[grid];
    for (let k = 1; k < grid; k++) acc += 2 * curve[k] * Math.cos((Math.PI * k * n) / grid);
    const w = 0.5 + 0.5 * Math.cos((Math.PI * n) / (mid + 1));
    h[mid + n] = h[mid - n] = (acc / (2 * grid)) * w;
  }
  const out = new Float32Array(x.length);
  const len = x.length;
  for (let i = 0; i < len; i++) {
    let acc = h[mid] * x[i];
    for (let n = 1; n <= mid; n++) {
      const a = i - n, b = i + n;
      acc += h[mid + n] * ((a >= 0 ? x[a] : 0) + (b < len ? x[b] : 0));
    }
    out[i] = acc;
  }
  return out;
}

module.exports = {
  SR, BINS, HOP, N_FFT, VOCAB, PROFILE, EQ_BANDS,
  clamp, options, tokenize, biquad, filter, applyEq, peakOf, trim, capPauses, fadeEdges, tidy,
  resample, resampleRate, compress, normalize,
  encodeWav, writeWavHeader, pcm16Buffer, isWav, decodeWav,
  spectrogram, transposeSpec, frameCount, trimSilence, estimateF0,
  bandLevels, matchGains, applyBandGains,
};
