'use strict';

// เซิร์ฟเวอร์สำหรับทดสอบบนเครื่อง (npm run dev) เลียนแบบการทำงานของ Vercel:
// เสิร์ฟ index.html, ส่ง /api/<ชื่อ> ไปที่ api/<ชื่อ>.js, อ่าน body ไว้ให้ใน req.body และทำ rewrites ตาม vercel.json
// ไฟล์นี้ไม่ถูกใช้งานบน Vercel

const fs = require('fs');
const http = require('http');
const path = require('path');

const ROOT = path.join(__dirname, '..', '..');
const PORT = Number(process.env.PORT) || 3000;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };

function rewrites() {
  try {
    return JSON.parse(fs.readFileSync(path.join(ROOT, 'vercel.json'), 'utf8')).rewrites || [];
  } catch (e) {
    return [];
  }
}

function readAll(req) {
  return new Promise((resolve, reject) => {
    const parts = [];
    req.on('data', (chunk) => parts.push(chunk));
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}

// เลียนแบบตัวช่วยของ @vercel/node: body ถูกอ่านจนหมดก่อนเรียก handler และแปลงตาม Content-Type
function parseBody(raw, contentType) {
  const type = String(contentType || '').split(';')[0].trim().toLowerCase();
  if (!type) return undefined;
  if (type === 'application/json') return raw.length ? JSON.parse(raw.toString('utf8')) : {};
  if (type === 'application/octet-stream') return raw;
  if (type === 'application/x-www-form-urlencoded') return Object.fromEntries(new URLSearchParams(raw.toString('utf8')));
  if (type === 'text/plain') return raw.toString('utf8');
  return undefined;
}

function serveStatic(pathname, res) {
  const rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname).replace(/^\/+/, '');
  const file = path.join(ROOT, rel);
  const blocked = rel.split('/').some((part) => part.startsWith('.') || part === 'node_modules' || part === 'api') || /^(package(-lock)?|vercel)\.json$/.test(rel);
  if (blocked || !file.startsWith(ROOT + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.statusCode = 404;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.end('404 Not Found');
  }
  res.statusCode = 200;
  res.setHeader('Content-Type', TYPES[path.extname(file)] || 'application/octet-stream');
  res.setHeader('Cache-Control', 'no-store');
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const started = Date.now();
  let url = new URL(req.url, 'http://localhost');
  for (const rule of rewrites()) {
    if (rule.source === url.pathname) {
      const target = new URL(rule.destination, 'http://localhost');
      for (const [key, value] of url.searchParams) target.searchParams.append(key, value);
      url = target;
      req.url = url.pathname + url.search;
      break;
    }
  }
  res.on('finish', () => console.log(req.method, url.pathname, res.statusCode, Date.now() - started + 'ms'));
  const match = /^\/api\/([A-Za-z0-9-]+)\/?$/.exec(url.pathname);
  if (!match) return serveStatic(url.pathname, res);
  const file = path.join(ROOT, 'api', match[1] + '.js');
  if (!fs.existsSync(file)) {
    res.statusCode = 404;
    return res.end('404 Not Found');
  }
  try {
    const raw = await readAll(req);
    let parsed, parseError;
    try {
      parsed = parseBody(raw, req.headers['content-type']);
    } catch (e) {
      parseError = e;
    }
    Object.defineProperty(req, 'body', {
      get() {
        if (parseError) throw parseError;
        return parsed;
      },
    });
    req.query = Object.fromEntries(url.searchParams);
    res.status = (code) => {
      res.statusCode = code;
      return res;
    };
    res.json = (payload) => {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.end(JSON.stringify(payload));
    };
    res.send = (payload) => res.end(payload);
    await require(file)(req, res);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) res.statusCode = 500;
    res.end('Internal Server Error');
  }
});

server.listen(PORT, () => console.log('เจนเสียง (dev) http://localhost:' + PORT));
