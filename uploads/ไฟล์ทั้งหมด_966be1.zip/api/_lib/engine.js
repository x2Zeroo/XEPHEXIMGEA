'use strict';

// เจนเสียง — เครื่องสังเคราะห์เสียงฝั่งเซิร์ฟเวอร์
// โหลดโมเดลครั้งเดียวต่อ instance แล้วใช้ซ้ำทุกคำขอ (session เก็บไว้ในหน่วยความจำ)

const fs = require('fs');
const os = require('os');
const path = require('path');
const ort = require('onnxruntime-node');
const dsp = require('./dsp.js');

const HF_TTS = 'https://huggingface.co/tranhuyluyen/piper-voices-thai/resolve/3f78c561e47fc5692f369a2ff65ad2139a7e6c3d/';
const HF_OPENVOICE = 'https://huggingface.co/TigreGotico/voiceclonnx-openvoice-v2/resolve/34d010c192c97f763207f488f6057fd07fee42ad/';

const MODELS = {
  female: { url: HF_TTS + 'th_TH-mms_female-medium.onnx', bytes: 114415781 },
  male: { url: HF_TTS + 'th_TH-mms_male-medium.onnx', bytes: 114415773 },
  conv: { url: HF_OPENVOICE + 'tone_converter.onnx', bytes: 128051288 },
  refenc: { url: HF_OPENVOICE + 'tone_ref_encoder.onnx', bytes: 3259275 },
};

const BUNDLE_DIR = path.join(__dirname, '..', '_models');
const ON_VERCEL = !!process.env.VERCEL;
const CACHE_DIR = process.env.JEN_MODEL_DIR || path.join(os.tmpdir(), 'jen-models');
const THREADS = dsp.clamp(Math.round(Number(process.env.JEN_THREADS)) || os.availableParallelism(), 1, 8);

const SESSION_OPTIONS = {
  executionProviders: ['cpu'],
  graphOptimizationLevel: 'all',
  executionMode: 'sequential',
  intraOpNumThreads: THREADS,
  interOpNumThreads: 1,
  logSeverityLevel: 3,
};

const sessions = new Map();
const loadInfo = {};
const bootedAt = Date.now();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function localFile(name) {
  const bundled = path.join(BUNDLE_DIR, name + '.onnx');
  if (fs.existsSync(bundled)) return { file: bundled, source: 'bundle' };
  const cached = path.join(CACHE_DIR, name + '.onnx');
  try {
    if (fs.statSync(cached).size === MODELS[name].bytes) return { file: cached, source: 'cache' };
  } catch (e) {
    return null;
  }
  return null;
}

async function download(name) {
  const model = MODELS[name];
  const headers = process.env.HF_TOKEN ? { authorization: 'Bearer ' + process.env.HF_TOKEN } : {};
  let lastError;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch(model.url, { headers, redirect: 'follow' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const buf = Buffer.allocUnsafe(model.bytes);
      let offset = 0;
      for await (const chunk of res.body) {
        if (offset + chunk.length > model.bytes) throw new Error('ไฟล์ใหญ่กว่าที่คาดไว้');
        buf.set(chunk, offset);
        offset += chunk.length;
      }
      if (offset !== model.bytes) throw new Error('ไฟล์ไม่ครบ (' + offset + ' จาก ' + model.bytes + ' ไบต์)');
      return buf;
    } catch (e) {
      lastError = e;
      await sleep(400 * (attempt + 1));
    }
  }
  const err = new Error('ดาวน์โหลดโมเดล "' + name + '" ไม่สำเร็จ: ' + (lastError && lastError.message));
  err.status = 503;
  throw err;
}

async function createSession(name) {
  const started = Date.now();
  const local = localFile(name);
  let source, session;
  if (local) {
    source = local.source;
    session = await ort.InferenceSession.create(local.file, SESSION_OPTIONS);
  } else {
    const bytes = await download(name);
    source = 'download';
    const fetched = Date.now();
    session = await ort.InferenceSession.create(bytes, SESSION_OPTIONS);
    loadInfo[name] = { downloadMs: fetched - started };
    // นอก Vercel (เช่นตอนพัฒนา) เก็บไฟล์ไว้ใช้รอบหน้า บน Vercel ไม่เขียนดิสก์เพื่อให้เริ่มงานเร็วที่สุด
    if (!ON_VERCEL) {
      try {
        fs.mkdirSync(CACHE_DIR, { recursive: true });
        const tmp = path.join(CACHE_DIR, name + '.' + process.pid + '.part');
        fs.writeFileSync(tmp, bytes);
        fs.renameSync(tmp, path.join(CACHE_DIR, name + '.onnx'));
      } catch (e) {
        // เก็บแคชไม่ได้ก็ยังทำงานต่อได้
      }
    }
  }
  loadInfo[name] = Object.assign(loadInfo[name] || {}, { source, loadMs: Date.now() - started });
  return session;
}

function load(name) {
  if (!MODELS[name]) throw new Error('ไม่รู้จักโมเดล ' + name);
  let pending = sessions.get(name);
  if (!pending) {
    pending = createSession(name);
    pending.catch(() => sessions.delete(name));
    sessions.set(name, pending);
  }
  return pending;
}

function warm(names) {
  return Promise.all(names.map((name) => load(name)));
}

// โมเดลคำนวณทีละงาน: รันพร้อมกันบน CPU เดียวมีแต่จะช้าลงทั้งคู่
let queue = Promise.resolve();
function exclusive(task) {
  const run = queue.then(task, task);
  queue = run.then(
    () => undefined,
    () => undefined
  );
  return run;
}

async function runTts(base, ids, scales) {
  const session = await load(base);
  const input = new BigInt64Array(ids.length);
  for (let i = 0; i < ids.length; i++) input[i] = BigInt(ids[i]);
  const feeds = {
    input: new ort.Tensor('int64', input, [1, ids.length]),
    input_lengths: new ort.Tensor('int64', BigInt64Array.from([BigInt(ids.length)]), [1]),
    scales: new ort.Tensor('float32', Float32Array.from(scales), [3]),
  };
  const out = await exclusive(() => session.run(feeds));
  return out[session.outputNames[0]].data;
}

// โทนเสียง (tone colour embedding 256 มิติ) จากสเปกโตรแกรม [เฟรม][บิน]
async function embed(specData, frames) {
  const session = await load('refenc');
  const feeds = { spec: new ort.Tensor('float32', specData, [1, frames, dsp.BINS]) };
  const out = await exclusive(() => session.run(feeds));
  return Float32Array.from(out[session.outputNames[0]].data);
}

async function convert(spec, sourceTone, targetTone) {
  const session = await load('conv');
  const feeds = {
    spec: new ort.Tensor('float32', dsp.transposeSpec(spec), [1, dsp.BINS, spec.frames]),
    spec_lengths: new ort.Tensor('int64', BigInt64Array.from([BigInt(spec.frames)]), [1]),
    src_g: new ort.Tensor('float32', sourceTone, [1, 256, 1]),
    tgt_g: new ort.Tensor('float32', targetTone, [1, 256, 1]),
  };
  const out = await exclusive(() => session.run(feeds));
  return out[session.outputNames[0]].data;
}

// แคชขนาดเล็กในหน่วยความจำ: ข้อความเดิม+เสียงเดิม ไม่ต้องคำนวณซ้ำ
function lru(limit) {
  const map = new Map();
  return {
    get(key) {
      const value = map.get(key);
      if (value !== undefined) {
        map.delete(key);
        map.set(key, value);
      }
      return value;
    },
    set(key, value) {
      map.delete(key);
      map.set(key, value);
      if (map.size > limit) map.delete(map.keys().next().value);
    },
  };
}

const ttsCache = lru(24);
const convCache = lru(12);

async function baseSpeech(base, text, scales) {
  const key = base + '|' + scales.map((s) => s.toFixed(3)).join(',') + '|' + text;
  let pcm = ttsCache.get(key);
  if (!pcm) {
    const ids = dsp.tokenize(text);
    if (ids.length < 3) return { key, pcm: new Float32Array(0) };
    pcm = await runTts(base, ids, scales);
    ttsCache.set(key, pcm);
  }
  return { key, pcm };
}

// เสียงมาตรฐาน (ไม่โคลน): โมเดล -> ตัดแต่ง -> ปรับระดับเสียง -> EQ -> คอมเพรส -> ปรับความดัง
async function builtinChunk(base, text, o) {
  const { pcm: raw } = await baseSpeech(base, text, [o.noiseScale, o.lengthScale, o.noiseW]);
  const x = dsp.tidy(raw, o.maxPause * o.pitchRatio);
  if (!x.length) return x;
  const out = dsp.resample(x, o.pitchRatio);
  dsp.applyEq(out, o.eq);
  if (o.dynamics) dsp.compress(out);
  dsp.normalize(out, -15);
  return out;
}

// เสียงฐานที่ผ่านตัวแปลงโทนเสียงแล้ว (ยังไม่ปรับแต่ง) เก็บแคชไว้ให้เสียงที่ใช้โทนเดียวกันใช้ร่วมกัน
async function convertedSpeech(voice, text, ui) {
  const speed = dsp.clamp(Number(ui.speed) || 1, 0.5, 2);
  const shift = dsp.clamp(voice.pitch * Math.pow(2, (Number(ui.semitones) || 0) / 12), 0.6, 1.7);
  const scales = [dsp.PROFILE.noiseScale, dsp.clamp(shift / speed, 0.5, 1.9), dsp.PROFILE.noiseW];
  const { key, pcm: raw } = await baseSpeech(voice.base, text, scales);
  const convKey = key + '|' + shift.toFixed(4) + '|' + voice.alpha.toFixed(2) + '|' + voice.hash;
  let converted = convCache.get(convKey);
  if (!converted) {
    const x = dsp.tidy(raw, (0.45 / speed) * shift);
    if (!x.length) return x;
    const rawSpec = dsp.spectrogram(x);
    const sourceTone = await embed(rawSpec.data, rawSpec.frames);
    // เลื่อนระดับเสียงก่อนแปลงโดยยังอ้างโทนของเสียงดิบ ตัวแปลงจะคงระดับเสียงที่เลื่อนไว้ในผลลัพธ์
    const input = Math.abs(shift - 1) < 0.005 ? rawSpec : dsp.spectrogram(dsp.resample(x, shift));
    let target = voice.tone;
    if (voice.alpha) {
      target = new Float32Array(256);
      for (let i = 0; i < 256; i++) target[i] = voice.tone[i] + voice.alpha * (voice.tone[i] - sourceTone[i]);
    }
    converted = await convert(input, sourceTone, target);
    convCache.set(convKey, converted);
  }
  return converted;
}

// เสียงโคลน: โมเดลฐาน -> (เลื่อนระดับเสียงชดเชย) -> ตัวแปลงโทนเสียง -> จับคู่โทน -> ปรับความดัง
async function cloneChunk(voice, text, ui) {
  const converted = await convertedSpeech(voice, text, ui);
  if (!converted.length) return converted;
  let out = Float32Array.from(converted);
  dsp.filter(out, dsp.biquad('highpass', 60, 0, 0.707));
  if (voice.eq) out = dsp.applyBandGains(out, voice.eq);
  const bright = Number(ui.brightness) || 0;
  if (bright) dsp.filter(out, dsp.biquad('highshelf', dsp.PROFILE.brightnessHz, bright));
  dsp.fadeEdges(out);
  dsp.normalize(out, -16);
  return out;
}

// สังเคราะห์ข้อความหนึ่งช่วง คืน PCM float32 ที่ 22050 Hz
function synthChunk(voice, text, ui) {
  if (voice.kind === 'clone') return cloneChunk(voice, text, ui);
  const match = voice.base === 'female' ? ui.match !== false : false;
  return builtinChunk(voice.base, text, dsp.options({ match, speed: ui.speed, semitones: ui.semitones, brightness: ui.brightness }));
}

function modelsFor(voice) {
  return voice.kind === 'clone' ? [voice.base, 'conv', 'refenc'] : [voice.base];
}

function status() {
  const loaded = {};
  for (const name of Object.keys(MODELS)) {
    if (loadInfo[name]) loaded[name] = loadInfo[name];
  }
  return {
    threads: THREADS,
    uptimeSeconds: Math.round((Date.now() - bootedAt) / 1000),
    loaded,
    memoryMb: Math.round(process.memoryUsage().rss / 1048576),
  };
}

module.exports = { MODELS, BUNDLE_DIR, SESSION_OPTIONS, load, warm, download, embed, convert, baseSpeech, convertedSpeech, synthChunk, modelsFor, status };
